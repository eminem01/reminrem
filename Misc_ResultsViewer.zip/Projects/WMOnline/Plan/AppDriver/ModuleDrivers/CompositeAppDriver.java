/******************************************************************************
Created by : ranganath
Created\Updated on : 2018/06/06 9:27:45 PM
Created using Cafenext Selenium Builder
******************************************************************************/

package ModuleDrivers;

import java.util.HashMap;
import java.util.Map;

import cbf.harness.ParameterAccess;
import cbf.model.ModuleDriver;
import cbfx.selenium.BaseWebAppDriver;

/**
 * Extends BaseWebAppDriver class and starts execution
**/
public class CompositeAppDriver extends BaseWebAppDriver {
	public CompositeAppDriver(Map params) {
		super(params);
	}

	/**
	* Initializes the modules specific to the application to be automated
	* @param resultLogger
		 TestResultLogger object with methods like passed, failed,
		 error etc available for reporting runtime results
	* @return Map of modules
	**/
	public Map<String, ModuleDriver> loadModuleDrivers(ParameterAccess paramAccess) {
		HashMap<String, ModuleDriver> moduleDrivers = new HashMap<String, ModuleDriver>();

		moduleDrivers.put("WMOnline", new WMOnlineDriver(paramAccess));
		return moduleDrivers;
	}

	public void recover(){
		super.recover();
	}
}
