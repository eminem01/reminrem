/******************************************************************************
Created by : ranganath
Created\Updated on : 2018/06/06 9:27:14 PM
Module part of 'WMOnline'
Module created using Cafenext Selenium Builder
******************************************************************************/
package ModuleDrivers;
import static cbf.engine.TestResultLogger.*;
import java.io.IOException;
import cbf.engine.TestResult.ResultType;
import cbf.harness.ParameterAccess;
import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.selenium.BaseWebModuleDriver;

/**
Extends BaseModuleDriver class and performs application specific operations
*/
public class WMOnlineDriver extends BaseWebModuleDriver {
	private ParameterAccess paramAccess;
	
	public WMOnlineDriver(ParameterAccess paramAccess) {
		this.paramAccess = paramAccess;
	}
	
	public void CCI_Valid(DataRow input, DataRow output) {
		//1. Verify whether Change_Contact_Information link exists
		uiDriver.checkElementPresent("CCI_Valid.lnkChange_Contact_Information", 15000);
		
		//2. Click on Change_Contact_Information Link
		uiDriver.click("CCI_Valid.lnkChange_Contact_Information");
		
		//3. Verify the text  Input in the sessionLog field
		if (uiDriver.verifyText("CCI_Valid.eltsessionLog", input.get("VerifyText@sessionLog"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//4. Verify the text  Input in the registered_email_id field
		if (uiDriver.verifyText("CCI_Valid.eltregistered_email_id", input.get("VerifyText@registered_email_id"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void Change_Contact_Information(DataRow input, DataRow output) {
		//1. Verify the text  Input in the BC field
		if (uiDriver.verifyText("Change_Contact_Information.eltBC", input.get("VerifyText@BC"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//2. Verify the text Input in the text field
		if (uiDriver.verifyText("Change_Contact_Information.edttext", input.get("VerifyText@text"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//3. Type Input in New_Mail field
		uiDriver.setValue("Change_Contact_Information.edtNew_Mail", input.get("Type@New_Mail"));
		
		//4. Type Input in Confirm_New_Mail field
		uiDriver.setValue("Change_Contact_Information.edtConfirm_New_Mail", input.get("Type@Confirm_New_Mail"));
		
		//5. Type Input in New_Mobile_Phone field
		uiDriver.setValue("Change_Contact_Information.edtNew_Mobile_Phone", input.get("Type@New_Mobile_Phone"));
		
		//6. Verify the text  Input in the Message field
		if (uiDriver.verifyText("Change_Contact_Information.eltMessage", input.get("VerifyText@Message"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void Change_Email_Only(DataRow input, DataRow output) {
		//1. Exists New_Email
		uiDriver.checkElementPresent("Change_Email_Only.edtNew_Email", 15000);
		
		//2. Type Input in New_Email field
		uiDriver.setValue("Change_Email_Only.edtNew_Email", input.get("type@New_Email"));
		
		//3. Type Input in Confirm_New_Email field
		uiDriver.setValue("Change_Email_Only.edtConfirm_New_Email", input.get("type@Confirm_New_Email"));
		
		//4. Type Input in New_Mobile_Phone field
		uiDriver.setValue("Change_Email_Only.edtNew_Mobile_Phone", input.get("type@New_Mobile_Phone"));
		
		//5. Click on Submit button
		uiDriver.click("Change_Email_Only.btnSubmit");
		
		//6. Verify the text Input in the text field
		if (uiDriver.verifyText("Change_Email_Only.edttext", input.get("VerifyText@text"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//7. Click on Change_Contact_Information Link
		uiDriver.click("Change_Email_Only.lnkChange_Contact_Information");
		
		//8. Verify the text  Input in the sessionLog field
		if (uiDriver.verifyText("Change_Email_Only.eltsessionLog", input.get("VerifyText@sessionLog"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//9. Verify the text  Input in the email field
		if (uiDriver.verifyText("Change_Email_Only.eltemail", input.get("VerifyText@email#2"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void Change_PhoneNumber_Only(DataRow input, DataRow output) {
		//1. Exists New_Email
		uiDriver.checkElementPresent("Change_PhoneNumber_Only.edtNew_Email", 15000);
		
		//2. Type Input in New_Email field
		uiDriver.setValue("Change_PhoneNumber_Only.edtNew_Email", input.get("type@New_Email"));
		
		//3. Type Input in Confirm_New_Email field
		uiDriver.setValue("Change_PhoneNumber_Only.edtConfirm_New_Email", input.get("type@Confirm_New_Email"));
		
		//4. Type Input in New_Mobile_Phone field
		uiDriver.setValue("Change_PhoneNumber_Only.edtNew_Mobile_Phone", input.get("type@New_Mobile_Phone"));
		
		//5. Click on Submit button
		uiDriver.click("Change_PhoneNumber_Only.btnSubmit");
		
		//6. Verify the text Input in the text field
		if (uiDriver.verifyText("Change_PhoneNumber_Only.edttext", input.get("VerifyText@text"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//7. Click on Change_Contact_Information Link
		uiDriver.click("Change_PhoneNumber_Only.lnkChange_Contact_Information");
		
		//8. Verify the text  Input in the sessionLog field
		if (uiDriver.verifyText("Change_PhoneNumber_Only.eltsessionLog", input.get("VerifyText@sessionLog"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//9. Verify the text  Input in the email field
		if (uiDriver.verifyText("Change_PhoneNumber_Only.eltemail", input.get("VerifyText@email#2"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void ChangePassword(DataRow input, DataRow output) {
		//1. Verify whether Change_Password link exists
		uiDriver.checkElementPresent("ChangePassword.lnkChange_Password", 15000);
		
		//2. Click on Change_Password Link
		uiDriver.click("ChangePassword.lnkChange_Password");
		
		//3. Verify the text  Input in the BC field
		if (uiDriver.verifyText("ChangePassword.eltBC", input.get("VerifyText@BC"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//4. Verify the text Input in the text field
		if (uiDriver.verifyText("ChangePassword.edttext", input.get("VerifyText@text"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//5. Type Input in Current_Password field
		uiDriver.setValue("ChangePassword.edtCurrent_Password", input.get("Type@Current_Password"));
		
		//6. Type Input in New_Password field
		uiDriver.setValue("ChangePassword.edtNew_Password", input.get("Type@New_Password"));
		
		//7. Type Input in Confirm_New_Password field
		uiDriver.setValue("ChangePassword.edtConfirm_New_Password", input.get("Type@Confirm_New_Password"));
		
		//8. Verify the text  Input in the ErrorMessage field
		if (uiDriver.verifyText("ChangePassword.eltErrorMessage", input.get("VerifyText@ErrorMessage"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void Login(DataRow input, DataRow output) {
		//1. Exists Username
		uiDriver.checkElementPresent("Login.edtUsername", 15000);
		
		//2. Type Input in Username field
		uiDriver.setValue("Login.edtUsername", input.get("type@Username"));
		
		//3. Type Input in Password field
		uiDriver.setValue("Login.edtPassword", input.get("type@Password"));
		
		//4. Type Input in Data_should_be field
		uiDriver.setValue("Login.edtData_should_be", input.get("Type@Data_should_be"));
		
		//5. Click on Sign_in button
		uiDriver.click("Login.btnSign_in");
		
	}
	
	public void Logout(DataRow input, DataRow output) {
		//1. Verify whether Sign_Out link exists
		uiDriver.checkElementPresent("Logout.lnkSign_Out", 15000);
		
		//2. Click on Sign_Out Link
		uiDriver.click("Logout.lnkSign_Out");
		
		//3. Close Browser #targettype# 
		uiDriver.closeBrowsers();
		
	}
	
	public void Nav_To_CCI(DataRow input, DataRow output) {
		//1. Verify whether Change_Contact_Information link exists
		uiDriver.checkElementPresent("Nav_To_CCI.lnkChange_Contact_Information", 15000);
		
		//2. Click on Change_Contact_Information Link
		uiDriver.click("Nav_To_CCI.lnkChange_Contact_Information");
		
	}
	
	public void NavtoProfileandPref(DataRow input, DataRow output) {
		//1. Verify whether My_service_Center link exists
		uiDriver.checkElementPresent("NavtoProfileandPref.lnkMy_service_Center", 15000);
		
		//2. Click on My_service_Center Link
		uiDriver.click("NavtoProfileandPref.lnkMy_service_Center");
		
		//3. Click on Profile_And_Preferences Link
		uiDriver.click("NavtoProfileandPref.lnkProfile_And_Preferences");
		
	}
	
	public void Verify_Email_Only(DataRow input, DataRow output) {
		//1. Verify the text  Input in the current_Email field
		if (uiDriver.verifyText("Verify_Email_Only.eltcurrent_Email", input.get("VerifyText@current_Email"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void Verify_Email_Phone(DataRow input, DataRow output) {
		//1. Verify the text  Input in the Current_Email field
		if (uiDriver.verifyText("Verify_Email_Phone.eltCurrent_Email", input.get("VerifyText@Current_Email"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void Verify_PhoneNumber_Only(DataRow input, DataRow output) {
		//1. Verify the text  Input in the current_mobile field
		if (uiDriver.verifyText("Verify_PhoneNumber_Only.eltcurrent_mobile", input.get("VerifyText@current_mobile"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void VerSessionLog_EmailNotifi0(DataRow input, DataRow output) {
		//1. Verify the text  Input in the sessionLog field
		if (uiDriver.verifyText("VerSessionLog_EmailNotifi0.eltsessionLog", input.get("VerifyText@sessionLog"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//2. Verify the text  Input in the registered_email_id field
		if (uiDriver.verifyText("VerSessionLog_EmailNotifi0.eltregistered_email_id", input.get("VerifyText@registered_email_id"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
	}
		public void AccountSummary(DataRow input, DataRow output) {
		//1. Verify whether Account_Summary link exists
		uiDriver.waitForBrowserStability(150);
		uiDriver.checkElementPresent("AccountSummary.lnkAccount_Summary", 15000);
		
		//2. Click on Account_Summary Link
		uiDriver.click("AccountSummary.lnkAccount_Summary");
		
	}
	
	public void AddAcnt_Negative_Validations(DataRow input, DataRow output) {
		//1. Type Input in Account_Number1 field
		uiDriver.setValue("AddAcnt_Negative_Validations.edtAccount_Number1", input.get("Type@Account_Number1"));
		
		//2. Type Input in Account_Label1 field
		uiDriver.setValue("AddAcnt_Negative_Validations.edtAccount_Label1", input.get("Type@Account_Label1"));
		
		//3. Type Input in Account_Number2 field
		uiDriver.setValue("AddAcnt_Negative_Validations.edtAccount_Number2", input.get("Type@Account_Number2"));
		
		//4. Type Input in Account_Label2 field
		uiDriver.setValue("AddAcnt_Negative_Validations.edtAccount_Label2", input.get("Type@Account_Label2"));
		
		//5. Click on ErrorMessage button
		uiDriver.click("AddAcnt_Negative_Validations.btnErrorMessage");
		
	}
	
	public void AutoAdd_Accounts(DataRow input, DataRow output) {
		//1. Select the Account  checkbox
		uiDriver.setValue("AutoAdd_Accounts.chkAccount", input.get("Select@Account"));
		
		//2. Verify whether Next button exists
		uiDriver.checkElementPresent("AutoAdd_Accounts.btnNext", 15000);
		
		//3. Click on Next button
		uiDriver.click("AutoAdd_Accounts.btnNext");
		
		//4. Verify Input Title for Review_and_Submit Page
		if (uiDriver.verify("AutoAdd_Accounts.pgeReview_and_Submit", input.get("Verify@Review_and_Submit"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//5. Click on Submit button
		uiDriver.click("AutoAdd_Accounts.btnSubmit");
		
		//6. Verify Input innertext for Status WebElement
		if (uiDriver.verify("AutoAdd_Accounts.eltStatus", input.get("Verify@Status#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//7. Verify Input innertext for Status WebElement
		if (uiDriver.verify("AutoAdd_Accounts.eltStatus", input.get("Verify@Status#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//8. Verify Input innertext for Email WebElement
		if (uiDriver.verify("AutoAdd_Accounts.eltEmail", input.get("Verify@Email"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//9. Verify Input innertext for EventId WebElement
		if (uiDriver.verify("AutoAdd_Accounts.eltEventId", input.get("Verify@EventId"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
	}
	
	public void Both_Manual_Auto_Add(DataRow input, DataRow output) {
		//1. Select the Account  checkbox
		uiDriver.setValue("Both_Manual_Auto_Add.chkAccount", input.get("Select@Account"));
		
		//2. Exists Account_Number
		uiDriver.checkElementPresent("Both_Manual_Auto_Add.edtAccount_Number", 15000);
		
		//3. Type Input in Account_Number field
		uiDriver.setValue("Both_Manual_Auto_Add.edtAccount_Number", input.get("type@Account_Number"));
		
		//4. Type Input in Account_label field
		uiDriver.setValue("Both_Manual_Auto_Add.edtAccount_label", input.get("type@Account_label"));
		
		//5. Click on Next button
		uiDriver.click("Both_Manual_Auto_Add.btnNext");
		
		//6. Verify Input Title for Review_and_Submit Page
		if (uiDriver.verify("Both_Manual_Auto_Add.pgeReview_and_Submit", input.get("Verify@Review_and_Submit"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//7. Click on Submit button
		uiDriver.click("Both_Manual_Auto_Add.btnSubmit");
		
		//8. Verify Input innertext for Status WebElement
		if (uiDriver.verify("Both_Manual_Auto_Add.eltStatus", input.get("Verify@Status#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//9. Verify Input innertext for Status WebElement
		if (uiDriver.verify("Both_Manual_Auto_Add.eltStatus", input.get("Verify@Status#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//10. Verify Input innertext for Email WebElement
		if (uiDriver.verify("Both_Manual_Auto_Add.eltEmail", input.get("Verify@Email"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//11. Verify Input innertext for EventId WebElement
		if (uiDriver.verify("Both_Manual_Auto_Add.eltEventId", input.get("Verify@EventId"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
	}
	
	public void Change_Account_Label(DataRow input, DataRow output) {
		//1. Verify whether Change_account_label link exists
		uiDriver.checkElementPresent("Change_Account_Label.lnkChange_account_label", 15000);
		
		//2. Click on Change_account_label Link
		uiDriver.click("Change_Account_Label.lnkChange_account_label");
		
		//3. Verify Input innertext for sessionLog WebElement
		if (uiDriver.verify("Change_Account_Label.eltsessionLog", input.get("Verify@sessionLog"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//4. Verify Input innertext for Miscinfo_Infoaccessed WebElement
		if (uiDriver.verify("Change_Account_Label.eltMiscinfo_Infoaccessed", input.get("Verify@Miscinfo_Infoaccessed"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//5. Verify Input innertext for Account_label WebElement
		if (uiDriver.verify("Change_Account_Label.eltAccount_label", input.get("Verify@Account_label"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//6. Type Input in Account_label field
		uiDriver.setValue("Change_Account_Label.edtAccount_label", input.get("type@Account_label"));
		
		//7. Click on Submit button
		uiDriver.click("Change_Account_Label.btnSubmit");
		
		//8. Verify Input innertext for Message WebElement
		if (uiDriver.verify("Change_Account_Label.eltMessage", input.get("Verify@Message#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//9. Verify Input innertext for Message WebElement
		if (uiDriver.verify("Change_Account_Label.eltMessage", input.get("Verify@Message#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//10. Verify Input innertext for Label WebElement
		if (uiDriver.verify("Change_Account_Label.eltLabel", input.get("Verify@Label#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//11. Verify Input innertext for Label WebElement
		if (uiDriver.verify("Change_Account_Label.eltLabel", input.get("Verify@Label#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
	}
	
	public void Change_Account_Label_Negative(DataRow input, DataRow output) {
		//1. Verify whether Change_account_label link exists
		uiDriver.checkElementPresent("Change_Account_Label_Negative.lnkChange_account_label", 15000);
		
		//2. Click on Change_account_label Link
		uiDriver.click("Change_Account_Label_Negative.lnkChange_account_label");
		
		//3. Type Input in Account_Label field
		uiDriver.setValue("Change_Account_Label_Negative.edtAccount_Label", input.get("Type@Account_Label"));
		
		//4. Click on ErrorMessage button
		uiDriver.click("Change_Account_Label_Negative.btnErrorMessage");
		
	}
	
	public void ClientNotificationQueue(DataRow input, DataRow output) {
		//1. Verify whether Action link exists
		uiDriver.checkElementPresent("ClientNotificationQueue.lnkAction", 15000);
		
		//2. Select Input from the Misc_Requests list
		uiDriver.setValue("ClientNotificationQueue.lstMisc_Requests", input.get("Select@Misc_Requests"));
		
		//3. Select the Account_created  checkbox
		uiDriver.setValue("ClientNotificationQueue.chkAccount_created", input.get("Select@Account_created"));
		
		//4. Verify Input Title for Are_You_sure Page
		if (uiDriver.verify("ClientNotificationQueue.pgeAre_You_sure", input.get("Verify@Are_You_sure"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//5. Click on ok button
		uiDriver.click("ClientNotificationQueue.btnok");
		
		//6. Verify Input Title for Clienty_Notification_Queue Page
		if (uiDriver.verify("ClientNotificationQueue.pgeClienty_Notification_Queue", input.get("Verify@Clienty_Notification_Queue"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//7. Click on ok button
		uiDriver.click("ClientNotificationQueue.btnok");
		
	}
	
	public void CompletedRequest(DataRow input, DataRow output) {
	}
	
	public void FANotificationQueue(DataRow input, DataRow output) {
		//1. Verify whether Help link exists
		uiDriver.checkElementPresent("FANotificationQueue.lnkHelp", 15000);
		
		//2. Select Input from the Misc_Requests list
		uiDriver.setValue("FANotificationQueue.lstMisc_Requests", input.get("Select@Misc_Requests"));
		
		//3. Select the Account_created  checkbox
		uiDriver.setValue("FANotificationQueue.chkAccount_created", input.get("Select@Account_created"));
		
		//4. Verify Input Title for Are_You_Sure Page
		if (uiDriver.verify("FANotificationQueue.pgeAre_You_Sure", input.get("Verify@Are_You_Sure"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//5. Click on ok button
		uiDriver.click("FANotificationQueue.btnok");
		
		//6. Verify Input Title for FA_Notification_Queue Page
		if (uiDriver.verify("FANotificationQueue.pgeFA_Notification_Queue", input.get("Verify@FA_Notification_Queue"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//7. Click on ok button
		uiDriver.click("FANotificationQueue.btnok");
		
	}
	
	public void LaunchSDA(DataRow input, DataRow output) {
		//1. Verify Input Title for SDALogin Page
		if (uiDriver.verify("LaunchSDA.pgeSDALogin", input.get("Verify@SDALogin"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//2. Exists Username
		uiDriver.checkElementPresent("LaunchSDA.edtUsername", 15000);
		
		//3. Type Input in Username field
		uiDriver.setValue("LaunchSDA.edtUsername", input.get("type@Username"));
		
		//4. Type Input in Password field
		uiDriver.setValue("LaunchSDA.edtPassword", input.get("type@Password"));
		
		//5. Click on Ok button
		uiDriver.click("LaunchSDA.btnOk");
		
	}
	


	
	public void ManualAdd_Accounts(DataRow input, DataRow output) {
		//1. Exists Account_Number
		uiDriver.checkElementPresent("ManualAdd_Accounts.edtAccount_Number", 15000);
		
		//2. Type Input in Account_Number field
		uiDriver.setValue("ManualAdd_Accounts.edtAccount_Number", input.get("type@Account_Number"));
		
		//3. Type Input in Account_label field
		uiDriver.setValue("ManualAdd_Accounts.edtAccount_label", input.get("type@Account_label"));
		
		//4. Click on Next button
		uiDriver.click("ManualAdd_Accounts.btnNext");
		
		//5. Verify Input Title for Review_and_Submit Page
		if (uiDriver.verify("ManualAdd_Accounts.pgeReview_and_Submit", input.get("Verify@Review_and_Submit"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//6. Click on Submit button
		uiDriver.click("ManualAdd_Accounts.btnSubmit");
		
		//7. Verify Input innertext for Status WebElement
		if (uiDriver.verify("ManualAdd_Accounts.eltStatus", input.get("Verify@Status#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//8. Verify Input innertext for Status WebElement
		if (uiDriver.verify("ManualAdd_Accounts.eltStatus", input.get("Verify@Status#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//9. Verify Input innertext for Email WebElement
		if (uiDriver.verify("ManualAdd_Accounts.eltEmail", input.get("Verify@Email"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//10. Verify Input innertext for EventId WebElement
		if (uiDriver.verify("ManualAdd_Accounts.eltEventId", input.get("Verify@EventId"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
	}
	
	public void Nav_Add_Accounts(DataRow input, DataRow output) {
		//1. Verify whether Add_accounts link exists
		uiDriver.checkElementPresent("Nav_Add_Accounts.lnkAdd_accounts", 15000);
		
		//2. Click on Add_accounts Link
		uiDriver.click("Nav_Add_Accounts.lnkAdd_accounts");
		
		//3. Verify Input innertext for sessionLog WebElement
		if (uiDriver.verify("Nav_Add_Accounts.eltsessionLog", input.get("Verify@sessionLog"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//4. Verify Input innertext for Miscinfo_Infoaccessed WebElement
		if (uiDriver.verify("Nav_Add_Accounts.eltMiscinfo_Infoaccessed", input.get("Verify@Miscinfo_Infoaccessed"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//5. Verify Input innertext for CapturePSAccounts WebElement
		if (uiDriver.verify("Nav_Add_Accounts.eltCapturePSAccounts", input.get("Verify@CapturePSAccounts#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//6. Verify Input innertext for CapturePSAccounts WebElement
		if (uiDriver.verify("Nav_Add_Accounts.eltCapturePSAccounts", input.get("Verify@CapturePSAccounts#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//7. Verify Input innertext for VerifyAddAccounts WebElement
		if (uiDriver.verify("Nav_Add_Accounts.eltVerifyAddAccounts", input.get("Verify@VerifyAddAccounts"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
	}
	
	public void Nav_Remove_Accounts(DataRow input, DataRow output) {
		//1. Verify whether Remove_accounts link exists
		uiDriver.checkElementPresent("Nav_Remove_Accounts.lnkRemove_accounts", 15000);
		
		//2. Click on Remove_accounts Link
		uiDriver.click("Nav_Remove_Accounts.lnkRemove_accounts");
		
		//3. Verify Input innertext for sessionLog WebElement
		if (uiDriver.verify("Nav_Remove_Accounts.eltsessionLog", input.get("Verify@sessionLog#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//4. Verify Input innertext for Miscinfo_Infoaccessed WebElement
		if (uiDriver.verify("Nav_Remove_Accounts.eltMiscinfo_Infoaccessed", input.get("Verify@Miscinfo_Infoaccessed"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//5. Verify Input innertext for sessionLog WebElement
		if (uiDriver.verify("Nav_Remove_Accounts.eltsessionLog", input.get("Verify@sessionLog#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
	}
	
	public void Remove_Confirmation(DataRow input, DataRow output) {
		//1. Verify whether next button exists
		uiDriver.checkElementPresent("Remove_Confirmation.btnnext", 15000);
		
		//2. Click on next button
		uiDriver.click("Remove_Confirmation.btnnext");
		
		//3. Verify Input Title for Review_and_Submit Page
		if (uiDriver.verify("Remove_Confirmation.pgeReview_and_Submit", input.get("Verify@Review_and_Submit"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//4. Click on Submit button
		uiDriver.click("Remove_Confirmation.btnSubmit");
		
		//5. Verify Input innertext for Status WebElement
		if (uiDriver.verify("Remove_Confirmation.eltStatus", input.get("Verify@Status#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//6. Verify Input innertext for Status WebElement
		if (uiDriver.verify("Remove_Confirmation.eltStatus", input.get("Verify@Status#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//7. Verify Input innertext for Message WebElement
		if (uiDriver.verify("Remove_Confirmation.eltMessage", input.get("Verify@Message#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//8. Verify Input innertext for Message WebElement
		if (uiDriver.verify("Remove_Confirmation.eltMessage", input.get("Verify@Message#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
	}
	
	public void Remove_MultipleAccount(DataRow input, DataRow output) {
		//1. Select Input from the SelectAccount list
		uiDriver.setValue("Remove_MultipleAccount.lstSelectAccount", input.get("Select@SelectAccount"));
		
		//2. Verify Input innertext for #target# WebElement
		if (uiDriver.verify("Remove_MultipleAccount.elt", input.get("Verify#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//3. Verify Input innertext for SelectAccount WebElement
		if (uiDriver.verify("Remove_MultipleAccount.eltSelectAccount", input.get("Verify@SelectAccount"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//4. Select Input from the #target# list
		uiDriver.setValue("Remove_MultipleAccount.lst", input.get("Select#2"));
		
	}
	
	public void Remove_OneAccount(DataRow input, DataRow output) {
		//1. Select Input from the SelectAccount list
		uiDriver.setValue("Remove_OneAccount.lstSelectAccount", input.get("Select@SelectAccount"));
		
		//2. Verify Input innertext for SelectAccount WebElement
		if (uiDriver.verify("Remove_OneAccount.eltSelectAccount", input.get("Verify@SelectAccount"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
	}
	
	public void RemoveAcnt_Negative_Valid0(DataRow input, DataRow output) {
		//1. Verify whether next button exists
		uiDriver.checkElementPresent("RemoveAcnt_Negative_Valid0.btnnext", 15000);
		
		//2. Click on next button
		uiDriver.click("RemoveAcnt_Negative_Valid0.btnnext");
		
		//3. Verify Input innertext for ErrorMessage WebElement
		if (uiDriver.verify("RemoveAcnt_Negative_Valid0.eltErrorMessage", input.get("Verify@ErrorMessage#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//4. Select Input from the All list
		uiDriver.setValue("RemoveAcnt_Negative_Valid0.lstAll", input.get("Select@All"));
		
		//5. Click on next button
		uiDriver.click("RemoveAcnt_Negative_Valid0.btnnext");
		
		//6. Verify Input innertext for ErrorMessage WebElement
		if (uiDriver.verify("RemoveAcnt_Negative_Valid0.eltErrorMessage", input.get("Verify@ErrorMessage#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
	}
	
	public void Validationqueue(DataRow input, DataRow output) {
		//1. Verify whether Access_Check radio group exists
		uiDriver.checkElementPresent("Validationqueue.rdgAccess_Check", 15000);
		
		//2. Click on Request_Id Link
		uiDriver.click("Validationqueue.lnkRequest_Id");
		
		//3. Verify Input Title for Account_Details Page
		if (uiDriver.verify("Validationqueue.pgeAccount_Details", input.get("Verify@Account_Details#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//4. Click on Validate Link
		uiDriver.click("Validationqueue.lnkValidate");
		
		//5. Click Access_Check
		uiDriver.click("Validationqueue.rdgAccess_Check");
		
		//6. Click Name_and_address_check
		uiDriver.click("Validationqueue.rdgName_and_address_check");
		
		//7. Click SSN_Check
		uiDriver.click("Validationqueue.rdgSSN_Check");
		
		//8. Click IE_check
		uiDriver.click("Validationqueue.rdgIE_check");
		
		//9. Click Suppression_Eligible
		uiDriver.click("Validationqueue.rdgSuppression_Eligible");
		
		//10. Click on Grant button
		uiDriver.click("Validationqueue.btnGrant");
		
		//11. Verify Input Title for Save_Validation Page
		if (uiDriver.verify("Validationqueue.pgeSave_Validation", input.get("Verify@Save_Validation#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//12. Click on Grant button
		uiDriver.click("Validationqueue.btnGrant");
		
		//13. Verify Input Title for Save_Validation Page
		if (uiDriver.verify("Validationqueue.pgeSave_Validation", input.get("Verify@Save_Validation#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//14. Click on Ok button
		uiDriver.click("Validationqueue.btnOk");
		
		//15. Verify Input Title for Account_Details Page
		if (uiDriver.verify("Validationqueue.pgeAccount_Details", input.get("Verify@Account_Details#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//16. Click on Close button
		uiDriver.click("Validationqueue.btnClose");
		
	}
	
	public void Verfify_AccountAdded(DataRow input, DataRow output) {
		//1. Verify whether Portfolio_Summary link exists
		uiDriver.checkElementPresent("Verfify_AccountAdded.lnkPortfolio_Summary", 15000);
		
		//2. Click on Portfolio_Summary Link
		uiDriver.click("Verfify_AccountAdded.lnkPortfolio_Summary");
		
		//3. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountAdded.eltPage", input.get("Verify@Page#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//4. Click on Account_Summary Link
		uiDriver.click("Verfify_AccountAdded.lnkAccount_Summary");
		
		//5. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountAdded.eltPage", input.get("Verify@Page#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//6. Click on Fixed_Income Link
		uiDriver.click("Verfify_AccountAdded.lnkFixed_Income");
		
		//7. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountAdded.eltPage", input.get("Verify@Page#3"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//8. Click on Realized_gain_loss Link
		uiDriver.click("Verfify_AccountAdded.lnkRealized_gain_loss");
		
		//9. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountAdded.eltPage", input.get("Verify@Page#4"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//10. Click on Income_Summary Link
		uiDriver.click("Verfify_AccountAdded.lnkIncome_Summary");
		
		//11. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountAdded.eltPage", input.get("Verify@Page#5"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//12. Click on Open_Orders Link
		uiDriver.click("Verfify_AccountAdded.lnkOpen_Orders");
		
		//13. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountAdded.eltPage", input.get("Verify@Page#6"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//14. Click on Trasaction_Detail Link
		uiDriver.click("Verfify_AccountAdded.lnkTrasaction_Detail");
		
		//15. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountAdded.eltPage", input.get("Verify@Page#7"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//16. Click on Online_Documents Link
		uiDriver.click("Verfify_AccountAdded.lnkOnline_Documents");
		
		//17. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountAdded.eltPage", input.get("Verify@Page#8"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//18. Click on Add_accounts Link
		uiDriver.click("Verfify_AccountAdded.lnkAdd_accounts");
		
		//19. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountAdded.eltPage", input.get("Verify@Page#9"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//20. Click on Remove_accounts Link
		uiDriver.click("Verfify_AccountAdded.lnkRemove_accounts");
		
		//21. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountAdded.eltPage", input.get("Verify@Page#10"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//22. Click on Change_account_label Link
		uiDriver.click("Verfify_AccountAdded.lnkChange_account_label");
		
		//23. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountAdded.eltPage", input.get("Verify@Page#11"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
	}
	
	public void Verfify_AccountRemoved(DataRow input, DataRow output) {
		//1. Verify whether Portfolio_Summary link exists
		uiDriver.checkElementPresent("Verfify_AccountRemoved.lnkPortfolio_Summary", 15000);
		
		//2. Click on Portfolio_Summary Link
		uiDriver.click("Verfify_AccountRemoved.lnkPortfolio_Summary");
		
		//3. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountRemoved.eltPage", input.get("Verify@Page#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//4. Click on Account_Summary Link
		uiDriver.click("Verfify_AccountRemoved.lnkAccount_Summary");
		
		//5. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountRemoved.eltPage", input.get("Verify@Page#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//6. Click on Fixed_Income Link
		uiDriver.click("Verfify_AccountRemoved.lnkFixed_Income");
		
		//7. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountRemoved.eltPage", input.get("Verify@Page#3"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//8. Click on Realized_gain_loss Link
		uiDriver.click("Verfify_AccountRemoved.lnkRealized_gain_loss");
		
		//9. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountRemoved.eltPage", input.get("Verify@Page#4"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//10. Click on Income_Summary Link
		uiDriver.click("Verfify_AccountRemoved.lnkIncome_Summary");
		
		//11. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountRemoved.eltPage", input.get("Verify@Page#5"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//12. Click on Open_Orders Link
		uiDriver.click("Verfify_AccountRemoved.lnkOpen_Orders");
		
		//13. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountRemoved.eltPage", input.get("Verify@Page#6"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//14. Click on Trasaction_Detail Link
		uiDriver.click("Verfify_AccountRemoved.lnkTrasaction_Detail");
		
		//15. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountRemoved.eltPage", input.get("Verify@Page#7"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//16. Click on Online_Documents Link
		uiDriver.click("Verfify_AccountRemoved.lnkOnline_Documents");
		
		//17. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountRemoved.eltPage", input.get("Verify@Page#8"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//18. Click on Add_accounts Link
		uiDriver.click("Verfify_AccountRemoved.lnkAdd_accounts");
		
		//19. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountRemoved.eltPage", input.get("Verify@Page#9"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//20. Click on Remove_accounts Link
		uiDriver.click("Verfify_AccountRemoved.lnkRemove_accounts");
		
		//21. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountRemoved.eltPage", input.get("Verify@Page#10"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//22. Click on Change_account_label Link
		uiDriver.click("Verfify_AccountRemoved.lnkChange_account_label");
		
		//23. Verify Input innertext for Page WebElement
		if (uiDriver.verify("Verfify_AccountRemoved.eltPage", input.get("Verify@Page#11"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
	}
	
		
	

	/**
	*Overriding toString() method of object class to print WMOnline
	*format string
	**/
	public String toString(){
		return "WMOnlineDriver";
	}
}
