/******************************************************************************
Created by : 
Created\Updated on : 8/18/2016 1:12:38 PM
Created using Cafenext Selenium Builder
 ******************************************************************************/

package ModuleDrivers;

//import Test_ModDriver;

import java.util.HashMap;
import java.util.Map;

import cbf.harness.ParameterAccess;
import cbf.model.ModuleDriver;
import cbfx.selenium.BaseWebAppDriver;

/**
 * Extends BaseWebAppDriver class and starts execution
 */
public class CompositeAppDriver extends BaseWebAppDriver {
	public CompositeAppDriver(Map params) {
		super(params);
	}

	/**
	* Initializes the modules specific to the application to be automated
	* @param resultLogger
		 TestResultLogger object with methods like passed, failed,
		 error etc available for reporting runtime results
	* @return Map of modules
	*/
	public Map<String, ModuleDriver> loadModuleDrivers(ParameterAccess paramAccess) {
		HashMap<String, ModuleDriver> moduleDrivers = new HashMap<String, ModuleDriver>();
		moduleDrivers.put("WMOnline", new WMOnlineDriver(paramAccess));
		return moduleDrivers;
	}

	public void recover(){
		super.recover();
	}
}

