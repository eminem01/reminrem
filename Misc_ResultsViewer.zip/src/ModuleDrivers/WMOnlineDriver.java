/******************************************************************************
Created by : ranganath
Created\Updated on : 2018/06/06 9:27:14 PM
Module part of 'WMOnline'
Module created using Cafenext Selenium Builder
******************************************************************************/
package ModuleDrivers;
import static cbf.engine.TestResultLogger.failed;
import static cbf.engine.TestResultLogger.passed;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//import com.gargoylesoftware.htmlunit.javascript.host.media.webkitAudioContext;

import cbf.harness.ParameterAccess;
import cbf.utils.DataRow;
import cbfx.selenium.BaseWebModuleDriver;

/**
Extends BaseModuleDriver class and performs application specific operations
*/
public class WMOnlineDriver extends BaseWebModuleDriver {
	private ParameterAccess paramAccess;
	String ReportDownloadAutoITPath = System.getProperty("user.dir")+"\\Projects\\PortfolioView\\ReportDownload\\ReportDownload.exe";
	String Reportpath = System.getProperty("user.dir")+"\\Projects\\Fixedincome\\";
	public WMOnlineDriver(ParameterAccess paramAccess) {
		this.paramAccess = paramAccess;
	}
	
	public void CCI_Valid(DataRow input, DataRow output) {
		//1. Verify whether Change_Contact_Information link exists
		uiDriver.checkElementPresent("CCI_Valid.lnkChange_Contact_Information", 15000);
		
		//2. Click on Change_Contact_Information Link
		uiDriver.click("CCI_Valid.lnkChange_Contact_Information");
		
		//3. Verify the text  Input in the sessionLog field
		if (uiDriver.verifyText("CCI_Valid.eltsessionLog", input.get("VerifyText@sessionLog"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		if (uiDriver.verifyText("Verify_Email_Only.eltcurrent_email_header", input.get("VerifyText@currentemail_header").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		//1. Verify the text  Input in the current_Email field
		if (uiDriver.verifyText("Verify_Email_Only.eltcurrent_Email", input.get("VerifyText@current_Email").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void Change_Contact_Information(DataRow input, DataRow output) {
		//1. Verify the text  Input in the BC field
		if (uiDriver.verifyText("Change_Contact_Information.eltchangecontactinfoheader", input.get("VerifyText@contactinfo").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//2. Verify the text Input in the text field
		if (uiDriver.verifyText("Change_Contact_Information.eltbreadcrumb", input.get("VerifyText@bc").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		//2. Verify the text Input in the text field
				if (uiDriver.verifyText("Change_Contact_Information.elttext1", input.get("VerifyText@text1").trim())) {
					passed("verifyText","verifyText should pass","verifyText passed");
				} else {
					failed("verifyText","verifyText should pass","verifyText failed");
				}
	    //2. Verify the text Input in the text field
				if (uiDriver.verifyText("Change_Contact_Information.elttext2", input.get("VerifyText@text2").trim())) {
					passed("verifyText","verifyText should pass","verifyText passed");
				} else {
					failed("verifyText","verifyText should pass","verifyText failed");
				}
				
				 //2. Verify the text Input in the text field
				if (uiDriver.verifyText("Change_Contact_Information.eltbullet1", input.get("VerifyText@Bullet1").trim())) {
					passed("verifyText","verifyText should pass","verifyText passed");
				} else {
					failed("verifyText","verifyText should pass","verifyText failed");
				}
				 //2. Verify the text Input in the text field
				if (uiDriver.verifyText("Change_Contact_Information.eltbullet2", input.get("VerifyText@Bullet2").trim().trim())) {
					passed("verifyText","verifyText should pass","verifyText passed");
				} else {
					failed("verifyText","verifyText should pass","verifyText failed");
				}
				 //2. Verify the text Input in the text field
				if (uiDriver.verifyText("Change_Contact_Information.eltbullet3", input.get("VerifyText@Bullet3").trim())) {
					passed("verifyText","verifyText should pass","verifyText passed");
				} else {
				   failed("verifyText","verifyText should pass","verifyText failed");
				}
		
				//1. Exists New_Email header
				uiDriver.checkElementPresent("Change_Contact_Information.edtNew_Email_Header", 15000);
				
				if (uiDriver.verifyText("Change_Contact_Information.edtNew_Email_Header", input.get("VerifyText@New_Email_Header").trim())) {
					passed("verifyText","verifyText should pass","verifyText passed");
				} else {
					failed("verifyText","verifyText should pass","verifyText failed");
				}
				
				//1. Exists New_Email
				uiDriver.checkElementPresent("Change_Contact_Information.edtNew_Email", 15000);
				
				//2. Type Input in New_Email field
				uiDriver.setValue("Change_Contact_Information.edtNew_Email", input.get("type@New_Email"));
				//1. Exists Confirm_New_Email header
				uiDriver.checkElementPresent("Change_Contact_Information.edtConfirm_New_Email", 15000);
				
				if (uiDriver.verifyText("Change_Contact_Information.edtConfirm_New_Email_Header", input.get("VerifyText@Confirm_Email_Header").trim())) {
					passed("verifyText","verifyText should pass","verifyText passed");
				} else {
					failed("verifyText","verifyText should pass","verifyText failed");
				}
				
				//3. Type Input in Confirm_New_Email field
				uiDriver.setValue("Change_Contact_Information.edtConfirm_New_Email", input.get("type@Confirm_New_Email"));
				
				uiDriver.checkElementPresent("Change_PhoneNumber_Only.edtNew_Mobile_Phone_Header", 15000);
				
				if (uiDriver.verifyText("Change_Contact_Information.edtNew_Mobile_Phone_Header", input.get("VerifyText@New_mobile_phone_Header").trim())) {
					passed("verifyText","verifyText should pass","verifyText passed");
				} else {
					failed("verifyText","verifyText should pass","verifyText failed");
				}
				uiDriver.checkElementPresent("Change_Contact_Information.edtNew_Mobile_Phone_1", 15000);
				uiDriver.setValue("Change_Contact_Information.edtNew_Mobile_Phone_1", input.get("type@New_Mobile_Phone_1"));
				
				uiDriver.checkElementPresent("Change_Contact_Information.edtNew_Mobile_Phone_2", 15000);
				uiDriver.setValue("Change_Contact_Information.edtNew_Mobile_Phone_2", input.get("type@New_Mobile_Phone_2"));
				
				uiDriver.checkElementPresent("Change_Contact_Information.edtNew_Mobile_Phone_3", 15000);
				uiDriver.setValue("Change_Contact_Information.edtNew_Mobile_Phone_3", input.get("type@New_Mobile_Phone_3"));
				//5. Click on Submit button
				uiDriver.checkElementPresent("Change_Contact_Information.btnSubmit", 15000);
				uiDriver.click("Change_Contact_Information.btnSubmit");
				//Verify the error message for NewMail
				if(!input.get("VerifyText@New_Email").equals("")){
					if (uiDriver.verifyText("Change_Contact_Information.elterror_New_Email", input.get("VerifyText@New_Email"))) {
						passed("verifyText","verifyText should pass","verifyText passed");
					} else {
						failed("verifyText","verifyText should pass","verifyText failed");
					}
					}
				//Verify the error message for ConfirmMail
				if(!input.get("VerifyText@Confirm_Email").equals("")){
					if (uiDriver.verifyText("Change_Contact_Information.elterror_Confirm_Email", input.get("VerifyText@Confirm_Email"))) {
						passed("verifyText","verifyText should pass","verifyText passed");
					} else {
						failed("verifyText","verifyText should pass","verifyText failed");
					}
					}
				//Verify the error message for Phone
				if(!input.get("VerifyText@Phn").equals("")){
					if (uiDriver.verifyText("Change_Contact_Information.elterror_Phn", input.get("VerifyText@Phn"))) {
						passed("verifyText","verifyText should pass","verifyText passed");
					} else {
						failed("verifyText","verifyText should pass","verifyText failed");
					}
					}
				//Verify the error message for Mail Mismatch
				if(!input.get("VerifyText@Mail_Mismatch").equals("")){
					if (uiDriver.verifyText("Change_Contact_Information.elterror_Confirm_Email_Mismatch", input.get("VerifyText@Mail_Mismatch"))) {
						passed("verifyText","verifyText should pass","verifyText passed");
					} else {
						failed("verifyText","verifyText should pass","verifyText failed");
					}
					}
				//Verify the error message for another Mail Mismatch
				if(!input.get("VerifyText@Mail_Mismatch1").equals("")){
					if (uiDriver.verifyText("Change_Contact_Information.elterror_Confirm_Email_Mismatch1", input.get("VerifyText@Mail_Mismatch1"))) {
						passed("verifyText","verifyText should pass","verifyText passed");
					} else {
						failed("verifyText","verifyText should pass","verifyText failed");
					}
					}
				
				//Verify the error message for blank confirm mail
				if(!input.get("VerifyText@Confirm_Email_Blank").equals("")){
					if (uiDriver.verifyText("Change_Contact_Information.elterror_Confirm_Email_Blank", input.get("VerifyText@Confirm_Email_Blank"))) {
						passed("verifyText","verifyText should pass","verifyText passed");
					} else {
						failed("verifyText","verifyText should pass","verifyText failed");
					}
					}
				//Verify the error message for new mail blank
				if(!input.get("VerifyText@New_Email_Blank").equals("")){
					if (uiDriver.verifyText("Change_Contact_Information.elterror_New_Email_Blank", input.get("VerifyText@New_Email_Blank"))) {
						passed("verifyText","verifyText should pass","verifyText passed");
					} else {
						failed("verifyText","verifyText should pass","verifyText failed");
					}
					}
				//Verify the error message for all blank mail
				if(!input.get("VerifyText@All_Blank").equals("")){
					if (uiDriver.verifyText("Change_Contact_Information.elterror_All_Blank", input.get("VerifyText@All_Blank"))) {
						passed("verifyText","verifyText should pass","verifyText passed");
					} else {
						failed("verifyText","verifyText should pass","verifyText failed");
					}
					}
				//6. Verify the text Input in the text field
				/*uiDriver.checkElementPresent("Change_Contact_Information.eltsuccess_popup", 65000);
				if (uiDriver.verifyText("Change_Contact_Information.eltsuccess_popup", input.get("VerifyText@ConfirmationPopup").trim())) {
					passed("verifyText","verifyText should pass","verifyText passed");
				} else {
					failed("verifyText","verifyText should pass","verifyText failed");
				}*/
				
				
				/*String [] dataArray=uiDriver.sessionLog("QADRC160");
				System.out.println("Validating session log from database");
				System.out.println("DB Array Size: "+dataArray.length);
				
				for (String dbValue: dataArray) {
					System.out.println(dbValue);
				}
				
				if (dataArray[0].equals("117") ) {
					passed("Change_Contact_Information","Session log should match","sesion log is matched");
				} else {
					failed("Change_Contact_Information","Session log should match","sesion log is not matched");
				}
				
				if (dataArray[2] == null) {
					passed("Change_Contact_Information","Session log should match","sesion log is matched");
				} else {
					failed("Change_Contact_Information","Session log should match","sesion log is not matched");
				}
				*/
				
	}
	
		
	

	public void Change_Email_Only(DataRow input, DataRow output) {
		//1. Exists New_Email header
		uiDriver.checkElementPresent("Change_Email_Only.edtNew_Email_Header", 15000);
		
		if (uiDriver.verifyText("Change_Email_Only.edtNew_Email_Header", input.get("VerifyText@New_Email_Header").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//1. Exists New_Email
		uiDriver.checkElementPresent("Change_Email_Only.edtNew_Email", 15000);
		
		//2. Type Input in New_Email field
		uiDriver.setValue("Change_Email_Only.edtNew_Email", input.get("type@New_Email"));
		//1. Exists Confirm_New_Email header
		uiDriver.checkElementPresent("Change_Email_Only.edtConfirm_New_Email", 15000);
		
		if (uiDriver.verifyText("Change_Email_Only.edtConfirm_New_Email_Header", input.get("VerifyText@Confirm_Email_Header").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//3. Type Input in Confirm_New_Email field
		uiDriver.setValue("Change_Email_Only.edtConfirm_New_Email", input.get("type@Confirm_New_Email"));
		
		
		
		//5. Click on Submit button
		uiDriver.checkElementPresent("Change_Email_Only.btnSubmit", 15000);
		uiDriver.click("Change_Email_Only.btnSubmit");
		
		
		//6. Verify the text Input in the text field
		if (uiDriver.verifyText("Change_Email_Only.eltsuccess_popup", input.get("VerifyText@ConfirmationPopup").trim())) {
			passed("Validate the ConfirmationPopuP title","Validate the ConfirmationPopup title should be present","Validate the ConfirmationPopup title is present :passed");
		} else {
			failed("Validate the ConfirmationPopup title","Validate the ConfirmationPopup title should be present","Validate the ConfirmationPopup title is'nt present :failed");
		}
		
		String [] dataArray=uiDriver.sessionLog("QADRC160");
		System.out.println("Validating session log from database");
		
		System.out.println(dataArray[0]);
		if (dataArray[0].equals("117") ) {
			passed("Change_Email_Only","Session log should match","sesion log is matched");
		} else {
			failed("Change_Email_Only","Session log should match","sesion log is not matched");
		}
		
		if (dataArray[2].equals("chk2375@gmail.com;chk2375@gmail.com") ) {
			passed("Change_Email_Only","Session log should match","sesion log is matched");
		} else {
			failed("Change_Email_Only","Session log should match","sesion log is not matched");
		}
		

		
	
	}
	
	public void Change_PhoneNumber_Only(DataRow input, DataRow output) {
		//1. Exists New_Email header
            uiDriver.checkElementPresent("Change_PhoneNumber_Only.edtNew_Email_Header", 15000);
				
			if (uiDriver.verifyText("Change_PhoneNumber_Only.edtNew_Email_Header", input.get("VerifyText@New_Email_Header").trim())) {
				passed("verifyText","verifyText should pass","verifyText passed");
			} else {
					failed("verifyText","verifyText should pass","verifyText failed");
			}
		//2. Type Input in New_Email field
		uiDriver.setValue("Change_PhoneNumber_Only.edtNew_Email", input.get("type@New_Email"));
		
		//1. Exists Confirm_New_Email header
				uiDriver.checkElementPresent("Change_PhoneNumber_Only.edtConfirm_New_Email", 15000);
				
				if (uiDriver.verifyText("Change_PhoneNumber_Only.edtConfirm_New_Email_Header", input.get("VerifyText@Confirm_Email_Header").trim())) {
					passed("verifyText","verifyText should pass","verifyText passed");
				} else {
					failed("verifyText","verifyText should pass","verifyText failed");
				}
		
		//3. Type Input in Confirm_New_Email field
		uiDriver.setValue("Change_PhoneNumber_Only.edtConfirm_New_Email", input.get("type@Confirm_New_Email"));
		
		//4. Type Input in New_Mobile_Phone field
		uiDriver.checkElementPresent("Change_PhoneNumber_Only.edtNew_Mobile_Phone_Header", 15000);
		
		if (uiDriver.verifyText("Change_PhoneNumber_Only.edtNew_Mobile_Phone_Header", input.get("VerifyText@New_mobile_phone_Header").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		uiDriver.checkElementPresent("Change_PhoneNumber_Only.edtNew_Mobile_Phone_1", 15000);
		uiDriver.setValue("Change_PhoneNumber_Only.edtNew_Mobile_Phone_1", input.get("type@New_Mobile_Phone_1"));
		
		uiDriver.checkElementPresent("Change_PhoneNumber_Only.edtNew_Mobile_Phone_2", 15000);
		uiDriver.setValue("Change_PhoneNumber_Only.edtNew_Mobile_Phone_2", input.get("type@New_Mobile_Phone_2"));
		
		uiDriver.checkElementPresent("Change_PhoneNumber_Only.edtNew_Mobile_Phone_3", 15000);
		uiDriver.setValue("Change_PhoneNumber_Only.edtNew_Mobile_Phone_3", input.get("type@New_Mobile_Phone_3"));
		//5. Click on Submit button
		uiDriver.checkElementPresent("Change_PhoneNumber_Only.btnSubmit", 15000);
		uiDriver.click("Change_PhoneNumber_Only.btnSubmit");
		
		//6. Verify the text Input in the text field
		if (uiDriver.verifyText("Change_PhoneNumber_Only.eltsuccess_popup", input.get("VerifyText@ConfirmationPopup").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//7. Click on Change_Contact_Information Link
		uiDriver.click("Change_PhoneNumber_Only.lnkChange_Contact_Information");
		
		//8. Verify the text  Input in the sessionLog field
		if (uiDriver.verifyText("Change_PhoneNumber_Only.eltsessionLog", input.get("VerifyText@sessionLog"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//9. Verify the text  Input in the email field
		if (uiDriver.verifyText("Change_PhoneNumber_Only.eltemail", input.get("VerifyText@email#2"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		String [] dataArray=uiDriver.sessionLog("QADRC160");
		System.out.println("Validating session log from database");
		
		System.out.println(dataArray[0]);
		if (dataArray[0].equals("117") ) {
			passed("Change_PhoneNumber_Only","Session log should match","sesion log is matched");
		} else {
			failed("Change_PhoneNumber_Only","Session log should match","sesion log is not matched");
		}
		
		if (dataArray[2].equals("chk2375@gmail.com") ) {
			passed("Change_PhoneNumber_Only","Session log should match","sesion log is matched");
		} else {
			failed("Change_PhoneNumber_Only","Session log should match","sesion log is not matched");
		}
		
	}
	
	public void ChangePassword(DataRow input, DataRow output) {
        uiDriver.checkElementPresent("ChangePassword.eltservicecenter", 15000);
		uiDriver.click("ChangePassword.eltservicecenter");
		
		 uiDriver.checkElementPresent("ChangePassword.lnkProfile_And_Preferences", 15000);
	     uiDriver.click("ChangePassword.lnkProfile_And_Preferences");
		//1. Verify whether Change_Password link exists
		uiDriver.checkElementPresent("ChangePassword.lnkChange_Password", 15000);
		
		//2. Click on Change_Password Link
		uiDriver.click("ChangePassword.lnkChange_Password");
		
		if (uiDriver.verifyText("ChangePassword.eltchangepassword", input.get("VerifyText@ChangePassword").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//3. Verify the text  Input in the BC field
		if (uiDriver.verifyText("ChangePassword.eltBC", input.get("VerifyText@BC").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//4. Verify the text Input in the text field
		if (uiDriver.verifyText("ChangePassword.eltchangepassword_1", input.get("VerifyText@eltchangepassword_1").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		if (uiDriver.verifyText("ChangePassword.eltchangepassword_2", input.get("VerifyText@eltchangepassword_2").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		if (uiDriver.verifyText("ChangePassword.eltchangepassword_4", input.get("VerifyText@eltchangepassword_3").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//5. Type Input in Current_Password field
		uiDriver.setValue("ChangePassword.eltcurrentpwd", input.get("Type@Current_Password"));
		
		//6. Type Input in New_Password field
		uiDriver.setValue("ChangePassword.eltnewpwd", input.get("Type@New_Password"));
		
		//7. Type Input in Confirm_New_Password field
		uiDriver.setValue("ChangePassword.edtConfirm_New_Password", input.get("Type@Confirm_New_Password"));
		
		//click on submit button
		uiDriver.checkElementPresent("ChangePassword.eltsubmit", 15000);
		uiDriver.click("ChangePassword.eltsubmit");
		
		//verify error message for Current Password
		if(!input.get("VerifyText@BlankCP").equals("")){
			if (uiDriver.verifyText("ChangePassword.eltErrorBlankCP", input.get("VerifyText@BlankCP"))) {
				passed("verifyText","verifyText should pass","verifyText passed");
			} else {
				failed("verifyText","verifyText should pass","verifyText failed");
			}
			}
		//verify error message for  New Password
		if(!input.get("VerifyText@BlankNP").equals("")){
			if (uiDriver.verifyText("ChangePassword.eltErrorBlankNP", input.get("VerifyText@BlankNP"))) {
				passed("verifyText","verifyText should pass","verifyText passed");
			} else {
				failed("verifyText","verifyText should pass","verifyText failed");
			}
			}
		//verify error message for Confirm Password
		if(!input.get("VerifyText@ConfirmNP").equals("")){
			if (uiDriver.verifyText("ChangePassword.eltErrorConfirmNP", input.get("VerifyText@ConfirmNP"))) {
				passed("verifyText","verifyText should pass","verifyText passed");
			} else {
				failed("verifyText","verifyText should pass","verifyText failed");
			}
			}
		
		 //Verify the text  Input in the ErrorMessage field
		/*uiDriver.checkElementPresent("ChangePassword.eltsucesspopup", 120);
		uiDriver.IsDisplayed_boolean("ChangePassword.eltsucesspopup", 45);
		if (uiDriver.verifyText("ChangePassword.eltsucesspopup", input.get("VerifyText@eltsucesspopup").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}*/
		
		/*String [] dataArray=uiDriver.sessionLog("QADRC160");
		System.out.println("Validating session log from database");*/
		
		/*System.out.println(dataArray[0]);
		if (dataArray[0].equals("103") ) {
			passed("ChangePassword","Session log should match","sesion log is matched");
		} else {
			failed("ChangePassword","Session log should match","sesion log is not matched");
		}
		
		if (dataArray[2]==null) {
			passed("ChangePassword","Session log should match","sesion log is matched");
		} else {
			failed("ChangePassword","Session log should match","sesion log is not matched");
		}
		
		if(!input.get("VerifyText@BlankNP").equals("")){
			if (uiDriver.verifyText("ChangePassword.eltErrorBlankNP", input.get("VerifyText@BlankNP"))) {
				passed("verifyText","verifyText should pass","verifyText passed");
			} else {
				failed("verifyText","verifyText should pass","verifyText failed");
			}
			}*/
	}
	
	public void Login(DataRow input, DataRow output) throws InterruptedException {
		System.out.println("in Url launch ");
		uiDriver.launchApplication(input.get("Navigate@URL"));	
		//2. Type Input in Username field
		uiDriver.checkElementPresent("Login.edtUsername", 30);
		uiDriver.setValue("Login.edtUsername", input.get("type@Username"));
		
		//3. Type Input in Password field
		uiDriver.checkElementPresent("Login.edtPassword", 30);
		uiDriver.setValue("Login.edtPassword", input.get("type@Password"));
		
		//5. Click on Sign_in button
		uiDriver.checkElementPresent("Login.btnSign_in", 20);
	
		uiDriver.javascriptClick("Login.btnSign_in");
		//uiDriver.waitForBrowserStability(300);
		
	}
	
	public void Logout(DataRow input, DataRow output) {
	    
		//1. Verify whether Sign_Out link exists
		uiDriver.checkElementPresent("Logout.lnkSign_Out", 45000);
		
		//2. Click on Sign_Out Links
		uiDriver.javascriptClick("Logout.lnkSign_Out");
		
		//3. Close Browser #targettype# 
		uiDriver.closeBrowsers();
		
	}
	
	public void Nav_To_CCI(DataRow input, DataRow output) {
		//1. Verify whether Change_Contact_Information link exists
		uiDriver.checkElementPresent("Nav_To_CCI.lnkChange_Contact_Information", 15000);
		
		//2. Click on Change_Contact_Information Link
		uiDriver.click("Nav_To_CCI.lnkChange_Contact_Information");
		
	}
	
	public void NavtoProfileandPref(DataRow input, DataRow output) {
		//1. Verify whether My_service_Center link exists
		uiDriver.checkElementPresentpro("NavtoProfileandPref.lnkMy_service_Center", 15000);
		
		//2. Click on My_service_Center Link
		uiDriver.click("NavtoProfileandPref.lnkMy_service_Center");
		
		//3. Click on Profile_And_Preferences Link
		uiDriver.checkElementPresentpro("NavtoProfileandPref.lnkProfile_And_Preferences", 15000);
		uiDriver.click("NavtoProfileandPref.lnkProfile_And_Preferences");
		
	}
	
	public void Verify_Email_Only(DataRow input, DataRow output) {
		//1. Verify the text  header in the current_Email field
		if (uiDriver.verifyText("Verify_Email_Only.eltcurrent_email_header", input.get("VerifyText@currentemail_header").trim().trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		//1. Verify the text  Input in the current_Email field
		if (uiDriver.verifyText("Verify_Email_Only.eltcurrent_Email", input.get("VerifyText@current_Email").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void Verify_Email_Phone(DataRow input, DataRow output) {
		//1. Verify the text  header in the current_mobile field
		if (uiDriver.verifyText("Verify_Email_Phone.eltcurrent_mobile_header", input.get("VerifyText@current_mobile_Header").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}

         //2. Verify the text  Input in the current_mobile field
           if (uiDriver.verifyText("Verify_Email_Phone.eltcurrent_mobile", input.get("VerifyText@current_mobile").trim())) {
	           passed("verifyText","verifyText should pass","verifyText passed");
           } else {
	      failed("verifyText","verifyText should pass","verifyText failed");
        }
         //1. Verify the text  header in the current_Email field
   		if (uiDriver.verifyText("Verify_Email_Phone.eltcurrent_email_header", input.get("VerifyText@currentemail_header").trim())) {
   			passed("verifyText","verifyText should pass","verifyText passed");
   		} else {
   			failed("verifyText","verifyText should pass","verifyText failed");
   		}
   		//1. Verify the text  Input in the current_Email field
   		if (uiDriver.verifyText("Verify_Email_Phone.eltcurrent_Email", input.get("VerifyText@current_Email").trim())) {
   			passed("verifyText","verifyText should pass","verifyText passed");
   		} else {
   			failed("verifyText","verifyText should pass","verifyText failed");
   		}
		
	}
	
	public void Verify_PhoneNumber_Only(DataRow input, DataRow output) {
		//1. Verify the text  header in the current_mobile field
				if (uiDriver.verifyText("Verify_PhoneNumber_Only.eltcurrent_mobile_header", input.get("VerifyText@current_mobile_Header").trim())) {
					passed("verifyText","verifyText should pass","verifyText passed");
				} else {
					failed("verifyText","verifyText should pass","verifyText failed");
				}
		
		//2. Verify the text  Input in the current_mobile field
		if (uiDriver.verifyText("Verify_PhoneNumber_Only.eltcurrent_mobile", input.get("VerifyText@current_mobile"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void VerSessionLog_EmailNotifi0(DataRow input, DataRow output) {
		//1. Verify the text  Input in the sessionLog field
		if (uiDriver.verifyText("VerSessionLog_EmailNotifi0.eltsessionLog", input.get("VerifyText@sessionLog"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//2. Verify the text  Input in the registered_email_id field
		if (uiDriver.verifyText("VerSessionLog_EmailNotifi0.eltregistered_email_id", input.get("VerifyText@registered_email_id"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void FixedIncome(DataRow input, DataRow output) throws InterruptedException, IOException {
		//1. verifyText("FixedIncome.pgetitle", input.get("VerifyText@title#1"))
		if (uiDriver.verifyText("FixedIncome.edtText", input.get("VerifyText@bc"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//2. verifyText("FixedIncome.pgeBreadcrumb", input.get("VerifyText@Breadcrumb"))
		if (uiDriver.verifyText("FixedIncome.eltfixedincome", input.get("VerifyText@tiltle"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		//4. checkElementPresent("FixedIncome.lstSelect_Account", 15000)
			uiDriver.checkElementPresent("FixedIncome.lstSelect_Account", 15000);
				
		//5. setValue("FixedIncome.lstSelect_Account", input.get("Select@Select_Account"))
			uiDriver.setValue("FixedIncome.lstSelect_Account", input.get("Select@Select_Account"));
				
		//6. click("FixedIncome.btnGO")
			uiDriver.checkElementPresent("FixedIncome.btnGO", 15000);
			uiDriver.click("FixedIncome.btnGO");
				
		RetriveColumndataandSort("FixedIncome.tblTableColumns","FixedIncome.tblData");
		
		
		//7. verifyText("FixedIncome.tblTitle", input.get("VerifyText@Title#2"))
		if (uiDriver.verifyText("FixedIncome.eltprint", input.get("VerifyText@printtitle"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		uiDriver.checkElementPresent("FixedIncome.eltprint", 15000);
		uiDriver.click("FixedIncome.eltprint");
		uiDriver.sendKey("tab");
		uiDriver.wait(30);
		uiDriver.sendKey("enter");
		
		uiDriver.checkElementPresent("FixedIncome.eltrefreshprices", 15000);
		uiDriver.click("FixedIncome.eltrefreshprices");
		
		uiDriver.checkElementPresent("FixedIncome.eltdownload", 15000);
		uiDriver.click("FixedIncome.eltdownload");
        
		//8. verifyText("FixedIncome.eltHeaders", input.get("VerifyText@Headers"))
		if (uiDriver.verifyText("FixedIncome.eltHeaders", input.get("VerifyText@Headers"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//9. verifyText("FixedIncome.eltSort", input.get("VerifyText@Sort"))
		if (uiDriver.verifyText("FixedIncome.eltSort", input.get("VerifyText@Sort"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//10. click("FixedIncome.btnRefresh_Prices")
		uiDriver.click("FixedIncome.btnRefresh_Prices");
		
		//11. verifyText("FixedIncome.edtPriced_as_of_June_01_2018", input.get("VerifyText@Priced_as_of_June_01_2018"))
		if (uiDriver.verifyText("FixedIncome.edtPriced_as_of_June_01_2018", input.get("VerifyText@Priced_as_of_June_01_2018"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}

	}
	public void FixedIncome_HPD(DataRow input, DataRow output) {
		
		uiDriver.checkElementPresent("FixedIncome_HPD.btnrefresfprices", 1500);
		uiDriver.click("FixedIncome_HPD.btnrefresfprices");
		
		RetriveColumndataandSort("FixedIncome_HPD.tblTableColumns","FixedIncome_HPD.tblData");
		//1. checkElementPresent("FixedIncome_HPD.lnkPrint", 15000)
		uiDriver.checkElementPresent("FixedIncome_HPD.lnkPrint", 15000);
		
		//2. click("FixedIncome_HPD.lnkPrint")
		uiDriver.click("FixedIncome_HPD.lnkPrint");
		
		//3. verifyText("FixedIncome_HPD.eltPrint", input.get("VerifyText@Print"))
		if (uiDriver.verifyText("FixedIncome_HPD.lnkPrint", input.get("VerifyText@Print"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//4. click("FixedIncome_HPD.lnkDownload")
		uiDriver.checkElementPresent("FixedIncome_HPD.lnkDownload", 15000);
		uiDriver.click("FixedIncome_HPD.lnkDownload");
		
		//5. verifyText("FixedIncome_HPD.eltDownload", input.get("VerifyText@Download"))
		if (uiDriver.verifyText("FixedIncome_HPD.lnkDownload", input.get("VerifyText@Download"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//6. click("FixedIncome_HPD.lnkHelp")
		uiDriver.click("FixedIncome_HPD.lnkHelp");
		
		if (uiDriver.verifyText("FixedIncome_HPD.lnkHelp", input.get("VerifyText@Help"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		uiDriver.click("FixedIncome_HPD.lnkQuestions");
		
	
		
		//7. verifyText("FixedIncome_HPD.eltQuestions", input.get("VerifyText@Questions#1"))
		if (uiDriver.verifyText("FixedIncome_HPD.eltQuestions", input.get("VerifyText@Questions#1"))) {
			passed("Fixed_Income","Fixed_Income should pass","Fixed_Income passed");
		} else {
			failed("Fixed_Income","Fixed_Income should pass","Fixed_Income failed");
		}
		
		uiDriver.click("FixedIncome_HPD.btnTermTab");
		
		//9. verifyText("FixedIncome_HPD.pgeTermTab", input.get("VerifyText@TermTab"))
		if (uiDriver.verifyText("FixedIncome_HPD.pgeTermTab", input.get("VerifyText@TermTab"))) {
			passed("TermTab","TermTab should pass","TermTab passed");
		} else {
			failed("TermTab","TermTab should pass","TermTab failed");
		}
		
	
		//11. click("FixedIncome_HPD.lnkGo_to_Fixed_Income")
		uiDriver.click("FixedIncome_HPD.lnkGo_to_Fixed_Income");
		
		//12. click("FixedIncome_HPD.btnSymbol")
		uiDriver.click("FixedIncome_HPD.btnSymbol");
		
		//13. verifyText("FixedIncome_HPD.pgeSymbol", input.get("VerifyText@Symbol#1"))
		if (uiDriver.verifyText("FixedIncome_HPD.pgeSymbol", input.get("VerifyText@Symbol#1"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//14. click("FixedIncome_HPD.lnkClick_on_Symbol")
		uiDriver.click("FixedIncome_HPD.lnkClick_on_Symbol");
		
		//15. verifyText("FixedIncome_HPD.eltsymbol", input.get("VerifyText@symbol#2"))
		if (uiDriver.verifyText("FixedIncome_HPD.eltsymbol", input.get("VerifyText@symbol#2"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//16. verifyText("FixedIncome_HPD.elttitle", input.get("VerifyText@title"))
		if (uiDriver.verifyText("FixedIncome_HPD.elttitle", input.get("VerifyText@title"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void FixedIncome_NoData(DataRow input, DataRow output) {
		if (uiDriver.verifyText("FixedIncome_NoData.edtText", input.get("VerifyText@Fixedincome").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		
		uiDriver.checkElementPresent("FixedIncome_NoData.lstSelect_Account", 15000);
		
		
		uiDriver.setValue("FixedIncome_NoData.lstSelect_Account", input.get("Select@Select_Account"));
		
	
		uiDriver.checkElementPresent("FixedIncome_NoData.btnGO", 15000);
		uiDriver.click("FixedIncome_NoData.btnGO");
		
		
		if (uiDriver.verifyText("FixedIncome_NoData.eltvalidatemsg", input.get("VerifyText@Validatemsg").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	
	public void Nav_Portfolio_FI(DataRow input, DataRow output) {
		
		uiDriver.waitForBrowserStability(300);
		//1. checkElementPresent("Nav_Portfolio_FI.lnkPortfolio_Detail", 15000)
		uiDriver.checkElementPresent("Nav_Portfolio_FI.lnkPortfolio_Detail", 15000);
		uiDriver.IsDisplayed_boolean("Nav_Portfolio_FI.lnkPortfolio_Detail", 50);
		
		//2. click("Nav_Portfolio_FI.lnkPortfolio_Detail")
		uiDriver.click("Nav_Portfolio_FI.lnkPortfolio_Detail");
		
		//3. click("Nav_Portfolio_FI.lnkPortfolio_Fixed_Income")
		uiDriver.checkElementPresent("Nav_Portfolio_FI.lnkPortfolio_Fixed_Income", 15000);
		uiDriver.javascriptClick("Nav_Portfolio_FI.lnkPortfolio_Fixed_Income");
		uiDriver.wait(8000);
		
	}
	
	public void NavtoFixedIncome(DataRow input, DataRow output) {
		//1. checkElementPresent("NavtoFixedIncome.lnkAccount_Summary", 15000)
		uiDriver.waitForBrowserStability(300);
		uiDriver.checkElementPresentpro("NavtoFixedIncome.lnkAccount_Summary", 15000);	
		//2. click("NavtoFixedIncome.lnkAccount_Summary")
		uiDriver.javascriptClick("NavtoFixedIncome.lnkAccount_Summary");
		
		//3. verifyText("NavtoFixedIncome.eltAccountDetailDisplayed", input.get("VerifyText@AccountDetailDisplayed"))
		if (uiDriver.verifyText("NavtoFixedIncome.eltAccountDetailDisplayed", input.get("VerifyText@AccountDetailDisplayed"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//4. click("NavtoFixedIncome.lnkFixed_Income")

		uiDriver.checkElementPresentpro("NavtoFixedIncome.lnkFixed_Income", 15000);	
		uiDriver.click("NavtoFixedIncome.lnkFixed_Income");
		
	}
	
	public void NavtoOpenOrders(DataRow input, DataRow output) {
		
		//1. checkElementPresent("NavtoOpenOrders.lnkAccount_Summary", 15000)
		uiDriver.checkElementPresentpro("NavtoOpenOrders.lnkAccount_Summary", 15000);
		uiDriver.IsDisplayed_boolean("NavtoOpenOrders.lnkAccount_Summary", 50);
		
		//2. click("NavtoOpenOrders.lnkAccount_Summary")
		uiDriver.javascriptClick("NavtoOpenOrders.lnkAccount_Summary");
		
		
		//3. verifyText("NavtoOpenOrders.eltAccountDetailDisplayed", input.get("VerifyText@AccountDetailDisplayed"))
		if (uiDriver.verifyText("NavtoOpenOrders.eltAccountDetailDisplayed", input.get("VerifyText@AccountDetailDisplayed"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//4. click("NavtoOpenOrders.lnkOpen_Orders")
		uiDriver.isDisabled("NavtoOpenOrders.lnkOpen_Orders");
		uiDriver.checkElementPresentpro("NavtoOpenOrders.lnkOpen_Orders", 15000);
		uiDriver.javascriptClick("NavtoOpenOrders.lnkOpen_Orders");
		
	}
	
	public void OpenOrders(DataRow input, DataRow output) {
		//1. verifyText("OpenOrders.pgetitle", input.get("VerifyText@title#1"))
		uiDriver.checkElementPresent("OpenOrders.edtText", 20);
		if (uiDriver.verifyText("OpenOrders.edtText", input.get("VerifyText@pagetitle"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//2. verifyText("OpenOrders.pgeBreadcrumb", input.get("VerifyText@Breadcrumb"))
		uiDriver.checkElementPresentpro("OpenOrders.eltbreadcrumb", 50);
		if (uiDriver.verifyText("OpenOrders.eltbreadcrumb", input.get("VerifyText@Breadcrumb"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//3. verifyText("OpenOrders.edtText", input.get("VerifyText@Text"))
		if (uiDriver.verifyText("OpenOrders.edttext1", input.get("VerifyText@Text1").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		if (uiDriver.verifyText("OpenOrders.edttext2", input.get("VerifyText@Text2").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		if (uiDriver.verifyText("OpenOrders.edttext1", input.get("VerifyText@Text3").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//4. checkElementPresent("OpenOrders.lstSelect_Account", 15000)
		uiDriver.checkElementPresent("OpenOrders.lstSelect_Account", 15000);
		
		//5. setValue("OpenOrders.lstSelect_Account", input.get("Select@Select_Account"))
		uiDriver.setValue("OpenOrders.lstSelect_Account", input.get("Select@Select_Account"));
		
		//6. click("OpenOrders.btnGO")
		uiDriver.checkElementPresent("OpenOrders.btnGO", 15000);
		uiDriver.javascriptClick("OpenOrders.btnGO");
		
		//7. verifyText("OpenOrders.tblTitle", input.get("VerifyText@Title#2"))
 		if (uiDriver.verifyText("OpenOrders.tblTitle", input.get("VerifyText@Tabletitle"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		RetriveColumndataandSort("OpenOrders.tblTableColumns","OpenOrders.tblData");
	
		
		//10. click("OpenOrders.btnRefresh_Prices")
		uiDriver.checkElementPresent("OpenOrders.btnRefresh_Prices", 15000);
		uiDriver.javascriptClick("OpenOrders.btnRefresh_Prices");
		
		
	
	}
	
	public void OpenOrders_HelpPrint(DataRow input, DataRow output) {
		//4. click("OpenOrders_HelpPrint.lnkHelp")
		uiDriver.checkElementPresentpro("OpenOrders_HelpPrint.lnkPrint", 60);
		//uiDriver.IsDisplayed_boolean("OpenOrders_HelpPrint.lnkPrint", 60);
		uiDriver.checkElementPresentpro("OpenOrders_HelpPrint.lnkHelp", 50);
		uiDriver.javascriptClick("OpenOrders_HelpPrint.lnkHelp");
		
		uiDriver.IsDisplayed_boolean("OpenOrders_HelpPrint.eltQuestions", 60);
		//5. verifyText("OpenOrders_HelpPrint.eltQuestions", input.get("VerifyText@Questions#1"))
		if (uiDriver.verifyText("OpenOrders_HelpPrint.eltQuestions", input.get("VerifyText@Questions#1"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		uiDriver.javascriptClick("OpenOrders_HelpPrint.btnTermTab");
		
		//7. verifyText("OpenOrders_HelpPrint.pgeTermTab", input.get("VerifyText@TermTab"))
		if (uiDriver.verifyText("OpenOrders_HelpPrint.pgeTermTab", input.get("VerifyText@TermTab").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}	
		
		//9. click("OpenOrders_HelpPrint.lnkGo_to_Open_Orders")
		uiDriver.javascriptClick("OpenOrders_HelpPrint.lnkGo_to_Open_Orders");
        uiDriver.setValue("OpenOrders.lstSelect_Account", input.get("Select@Select_Account"));
 		
		//6. click("OpenOrders.btnGO")
		uiDriver.checkElementPresent("OpenOrders.btnGO", 15000);
		uiDriver.javascriptClick("OpenOrders.btnGO");    
		
		//10. click("OpenOrders_HelpPrint.btnSymbol")
		uiDriver.javascriptClick("OpenOrders_HelpPrint.btnSymbol");
		
		//13. verifyText("OpenOrders_HelpPrint.eltsymbol", input.get("VerifyText@symbol"))
		if (uiDriver.verifyText("OpenOrders_HelpPrint.elttitle", input.get("VerifyText@title"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
			} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		   }
				
		
		
		uiDriver.javascriptClick("OpenOrders_HelpPrint.eltclose");
		//12. click("OpenOrders_HelpPrint.lnkClick_on_Symbol")
		uiDriver.click("OpenOrders_HelpPrint.lnkClick_on_Symbol");
		
		
		//14. verifyText("OpenOrders_HelpPrint.elttitle", input.get("VerifyText@title"))
		if (uiDriver.verifyText("OpenOrders_HelpPrint.elttitle", input.get("VerifyText@title"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void OpenOrders_NoData(DataRow input, DataRow output) {
		uiDriver.checkElementPresent("OpenOrders_NoData.edtText", 45);
		if (uiDriver.verifyText("OpenOrders_NoData.edtText", input.get("VerifyText@Openorders").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//1. checkElementPresent("OpenOrders_NoData.lstSelect_Account", 15000)
		uiDriver.checkElementPresent("OpenOrders_NoData.lstSelect_Account", 15000);
		
		//2. setValue("OpenOrders_NoData.lstSelect_Account", input.get("Select@Select_Account"))
		uiDriver.setValue("OpenOrders_NoData.lstSelect_Account", input.get("Select@Select_Account"));
		
		//3. click("OpenOrders_NoData.btnGO")
		uiDriver.checkElementPresent("OpenOrders_NoData.btnGO", 15000);
		uiDriver.click("OpenOrders_NoData.btnGO");
		
		//4. verifyText("OpenOrders_NoData.edtText", input.get("VerifyText@Text"))
		uiDriver.checkElementPresent("OpenOrders_NoData.eltvalidatemsg", 45);
		if (uiDriver.verifyText("OpenOrders_NoData.eltvalidatemsg", input.get("VerifyText@Validatemsg").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	
	
	public void Portfolio_FixedIncome(DataRow input, DataRow output) {
		//1. verifyText("Portfolio_FixedIncome.pgetitle", input.get("VerifyText@title#1"))
		if (uiDriver.verifyText("Portfolio_FixedIncome.eltbreadcrumb", input.get("VerifyText@Breadcrumb"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//2. verifyText("Portfolio_FixedIncome.pgeBreadcrumb", input.get("VerifyText@Breadcrumb"))
		uiDriver.checkElementPresent("Portfolio_FixedIncome.tblTitle", 15000);
		if (uiDriver.verifyText("Portfolio_FixedIncome.tblTitle", input.get("VerifyText@tabletiltle"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		RetriveColumndataandSort("Portfolio_FixedIncome.tblTableColumns","Portfolio_FixedIncome.tblData");
		
		//6. checkElementPresent("Portfolio_FixedIncome.btnRefresh_Prices", 15000)
		uiDriver.checkElementPresent("Portfolio_FixedIncome.btnRefresh_Prices", 15000);
		
		//7. click("Portfolio_FixedIncome.btnRefresh_Prices")
		uiDriver.javascriptClick("Portfolio_FixedIncome.btnRefresh_Prices");
		
		//8. verifyText("Portfolio_FixedIncome.edtPriced_as_of_June_01_2018", input.get("VerifyText@Priced_as_of_June_01_2018"))
		if (uiDriver.verifyText("Portfolio_FixedIncome.edtPriced_as_of_June_01_2018", input.get("VerifyText@Priced_as_of_June_01_2018"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void Portfolio_FixedIncome_HPD(DataRow input, DataRow output) {

		//1. checkElementPresent("Portfolio_FixedIncome_HPD.lnkPrint", 15000)
		uiDriver.checkElementPresent("Portfolio_FixedIncome_HPD.lnkPrint", 15000);
		
		//2. click("Portfolio_FixedIncome_HPD.lnkPrint")
		uiDriver.javascriptClick("Portfolio_FixedIncome_HPD.lnkPrint");
		
		uiDriver.sendKey("tab");
		uiDriver.wait(30);
		uiDriver.sendKey("enter");
		
		//3. verifyText("Portfolio_FixedIncome_HPD.eltPrint", input.get("VerifyText@Print"))
		if (uiDriver.verifyText("Portfolio_FixedIncome_HPD.eltPrint", input.get("VerifyText@Print"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText 	failed");
		}
		
		//4. click("Portfolio_FixedIncome_HPD.lnkDownload")
		uiDriver.checkElementPresent("Portfolio_FixedIncome_HPD.lnkDownload", 15000);
		uiDriver.javascriptClick("Portfolio_FixedIncome_HPD.lnkDownload");
		
		//5. verifyText("Portfolio_FixedIncome_HPD.eltDownload", input.get("VerifyText@Download"))
		
		if (uiDriver.verifyText("Portfolio_FixedIncome_HPD.lnkDownload", input.get("VerifyText@Download"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//6. click("Portfolio_FixedIncome_HPD.lnkHelp")
		uiDriver.checkElementPresent("Portfolio_FixedIncome_HPD.lnkHelp", 15000);
		uiDriver.javascriptClick("Portfolio_FixedIncome_HPD.lnkHelp");
		uiDriver.javascriptClick("Portfolio_FixedIncome_HPD.eltQuestions");
		
		//7. verifyText("Portfolio_FixedIncome_HPD.eltQuestions", input.get("VerifyText@Questions#1"))		
		uiDriver.checkElementPresent("Portfolio_FixedIncome_HPD.eltQuestions", 45000);
		if (uiDriver.verifyText("Portfolio_FixedIncome_HPD.eltQuestions", input.get("VerifyText@Questions#1"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		//10. click("Portfolio_FixedIncome_HPD.btnTermTab")
		uiDriver.javascriptClick("Portfolio_FixedIncome_HPD.btnTermTab");
		
		//9. verifyText("Portfolio_FixedIncome_HPD.pgeTermTab", input.get("VerifyText@TermTab"))
		if (uiDriver.verifyText("Portfolio_FixedIncome_HPD.btnTermTab", input.get("VerifyText@TermTab"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
		
		
		//11. click("Portfolio_FixedIncome_HPD.lnkGo_to_Portfolio_Fixed_Income")
		uiDriver.javascriptClick("Portfolio_FixedIncome_HPD.lnkGo_to_Portfolio_Fixed_Income");
		
		
	}
	
	

	
	
 

	public void Realized_Gain_Loss_HPD(DataRow input, DataRow output) {
		//1. checkElementPresent("Realized_Gain_Loss_HPD.lnkHelp", 15000)
		uiDriver.checkElementPresent("Realized_Gain_Loss_HPD.lnkHelp", 15000);
		
		//2. click("Realized_Gain_Loss_HPD.lnkHelp")
		uiDriver.click("Realized_Gain_Loss_HPD.lnkHelp");
		
		if (uiDriver.verifyText("Realized_Gain_Loss_HPD.eltQuestions", input.get("VerifyText@eltQuestions").trim())) {
			passed("Questions&answer","Questions&answe should pass","Questions&answe passed");
		} else {
			failed("Questions&answe","Questions&answe should pass","Questions&answe failed");
		}
		
		//3. click("Realized_Gain_Loss_HPD.btnTermTab")
		uiDriver.click("Realized_Gain_Loss_HPD.btnTermTab");
		
		if (uiDriver.verifyText("Realized_Gain_Loss_HPD.btnTermTab", input.get("VerifyText@btnTermTab").trim())) {
			passed("Questions&answer","Questions&answe should pass","Questions&answe passed");
		} else {
			failed("Questions&answe","Questions&answe should pass","Questions&answe failed");
		}
		
		
		//4. click("Realized_Gain_Loss_HPD.lnkGo_to_Realized_Gain_Loss")
		uiDriver.click("Realized_Gain_Loss_HPD.lnkGo_to_Realized_Gain_Loss");
		
		//5. click("Realized_Gain_Loss_HPD.lnkPrint")
		uiDriver.checkElementPresent("Realized_Gain_Loss_HPD.lnkPrint", 15000);
		if (uiDriver.verifyText("Realized_Gain_Loss_HPD.lnkPrint", input.get("VerifyText@lnkPrint").trim())) {
			passed("Print_tab","Print_tab should pass","Print_tab passed");
		} else {
			failed("Print_tab","Print_tab should pass","Print_tab failed");
		}
		
		uiDriver.checkElementPresent("Realized_Gain_Loss_HPD.lnkDownload", 15000);
		if (uiDriver.verifyText("Realized_Gain_Loss_HPD.lnkDownload", input.get("VerifyText@lnkDownload").trim())) {
			passed("Download_Tab","Download_Tab should pass","Download_Tab passed");
		} else {
			failed("Download_Tab","Download_Tab should pass","Download_Tab failed");
		}
		
	}
	
	public void RealizedGainLoss(DataRow input, DataRow output) {
		//1. checkElementPresent("RealizedGainLoss.lnkAccount_Summary", 15000)
		uiDriver.checkElementPresent("RealizedGainLoss.lnkAccount_Summary", 15000);
		
		//2. click("RealizedGainLoss.lnkAccount_Summary")
		uiDriver.click("RealizedGainLoss.lnkAccount_Summary");
		
		//3. click("RealizedGainLoss.lnkRealized_gain_loss")
		uiDriver.checkElementPresent("RealizedGainLoss.lnkRealized_gain_loss", 15000);
		uiDriver.javascriptClick("RealizedGainLoss.lnkRealized_gain_loss");
		
		//verification of session log
		String [] dataArray=uiDriver.sessionLog("QADRC10");
		System.out.println("Validating session log from database");
		
		System.out.println(dataArray[0]);
		if (dataArray[0].equals("54") ) {
			passed("RealizedGainLoss","Session log should match","sesion log is matched");
		} else {
			failed("RealizedGainLoss","Session log should match","sesion log is not matched");
		}
		
		if (dataArray[2].equals("null") ) {
			passed("RealizedGainLoss","Session log should match","sesion log is matched");
		} else {
			failed("RealizedGainLoss","Session log should match","sesion log is not matched");
		}
		
		//select an account number
		uiDriver.checkElementPresent("RealizedGainLoss.lstaccount", 15000);
		uiDriver.setValue("RealizedGainLoss.lstaccount", input.get("select@lstaccount"));
		
		if(input.get("click@rdgDate_Range").equalsIgnoreCase("true")){
		uiDriver.click("RealizedGainLoss.rdgDate_Range");}
		else{
			uiDriver.click("RealizedGainLoss.rdgcustom");	
		}
		
		
		uiDriver.checkElementPresent("RealizedGainLoss.lstF_MMM", 15000);
		uiDriver.setValue("RealizedGainLoss.lstF_MMM", input.get("Select@lstF_MMM"));
		
		uiDriver.checkElementPresent("RealizedGainLoss.edtF_DD", 15000);
	    uiDriver.setValue("RealizedGainLoss.edtF_DD", input.get("type@F_DD"));
				
				
		uiDriver.checkElementPresent("RealizedGainLoss.edtF_YYYY", 15000);
		uiDriver.setValue("RealizedGainLoss.edtF_YYYY", input.get("type@F_YYYY"));
		
		uiDriver.checkElementPresent("RealizedGainLoss.lstT_MMM", 15000);
		uiDriver.setValue("RealizedGainLoss.lstT_MMM", input.get("Select@lstT_MMM"));
		
		//10. setValue("RealizedGainLoss.edtT_DD", input.get("type@T_DD"))
		uiDriver.checkElementPresent("RealizedGainLoss.lnksecuritytab", 15000);
		uiDriver.setValue("RealizedGainLoss.edtT_DD", input.get("type@T_DD"));
		
		//11. setValue("RealizedGainLoss.edtT_YYYY", input.get("type@T_YYYY"))
		uiDriver.checkElementPresent("RealizedGainLoss.lnksecuritytab", 15000);
		uiDriver.setValue("RealizedGainLoss.edtT_YYYY", input.get("type@T_YYYY"));
		
	}
	
	public void RGL_By_Security(DataRow input, DataRow output) {
		uiDriver.checkElementPresent("RGL_By_Security.btnView", 15000);
		uiDriver.click("RGL_By_Security.btnView");
		
		
		//1. checkElementPresent("RGL_By_Security.btnBy_Security", 15000)
		uiDriver.checkElementPresent("RGL_By_Security.btnBy_Security", 15000);
		
		//2. click("RGL_By_Security.btnBy_Security")
		uiDriver.click("RGL_By_Security.btnBy_Security");
		
		RetriveColumndataandSort("RGL_By_Security.tblTableColumns","RGL_By_Security.tblData");
		
		//5. checkPage(input.get("VerifyPage@Symbol"))
		if (uiDriver.checkPage(input.get("VerifyPage@Symbol"))) {
			passed("checkPage","checkPage should pass","checkPage passed");
		} else {
			failed("checkPage","checkPage should pass","checkPage failed");
		}
		
		//6. click("RGL_By_Security.lnkClick_on_Symbol")
		uiDriver.click("RGL_By_Security.lnkClick_on_Symbol");
		
	}
	
	public void RGL_By_Term(DataRow input, DataRow output) {
		//1. checkElementPresent("RGL_By_Term.btnBy_Term", 15000)
		uiDriver.checkElementPresent("RGL_By_Term.btnBy_Term", 15000);
		
		//2. click("RGL_By_Term.btnBy_Term")
		uiDriver.click("RGL_By_Term.btnBy_Term");
		
		//3. click("RGL_By_Term.btnBy_TermClicked")
		//uiDriver.click("RGL_By_Term.btnBy_TermClicked");
		
	}
	
	public void RGL_Custom(DataRow input, DataRow output) {
		//1. checkElementPresent("RGL_Custom.btnView", 15000)
		uiDriver.checkElementPresent("RGL_Custom.btnView", 15000);
		
		//2. click("RGL_Custom.btnView")
		uiDriver.javascriptClick("RGL_Custom.btnView");
		
		if (uiDriver.verifyText("RGL_Custom.validatetext", input.get("VerifyText@validatetext").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
	}
	
	public void RGL_IDC_Validation(DataRow input, DataRow output) {
		//1. click("RGL_IDC_Validation.btnSymbol")
		uiDriver.click("RGL_IDC_Validation.btnSymbol");
		
		//2. checkPage(input.get("VerifyPage@Symbol"))
		if (uiDriver.verifyText("RGL_IDC_Validation.eltsymboltitle", input.get("VerifyText@Symbol").trim())) {
			passed("Symbol","Symbol should pass","Symbol passed");
		} else {
			failed("Symbol","Symbol should pass","Symbol failed");
		}
		if (uiDriver.verifyText("RGL_IDC_Validation.eltdate", input.get("VerifyText@Date").trim())) {
			passed("Symbol","Symbol should pass","Symbol passed");
		} else {
			failed("Symbol","Symbol should pass","Symbol failed");
		}
		
        uiDriver.checkElementPresent("RGL_IDC_Validation.btnclose", 15000);
 		
		//2. click("RGL_Custom.btnView")
		uiDriver.click("RGL_IDC_Validation.btnclose");
		
		
	}
	
	public void RGL_LongTerm_UnknownTerm(DataRow input, DataRow output) {
		uiDriver.checkElementPresent("RGL_LongTerm_UnknownTerm.eltminusshort", 15000);
		uiDriver.click("RGL_LongTerm_UnknownTerm.eltminusshort");
		uiDriver.checkElementPresent("RGL_LongTerm_UnknownTerm.eltminuslong", 15000);
		uiDriver.click("RGL_LongTerm_UnknownTerm.eltminuslong");
		uiDriver.checkElementPresent("RGL_LongTerm_UnknownTerm.eltminusunknown", 15000);
		uiDriver.click("RGL_LongTerm_UnknownTerm.eltminusunknown");
		if (uiDriver.verifyText("RGL_NoData.vallngtermtable", input.get("VerifyText@vallngtermtable"))) {
			passed("longterm_table","longterm_table should pass","longterm_table passed");
		} else {
			failed("longterm_table","longterm_table should pass","longterm_table failed");
		}
		
		RetriveColumndataandSort("RGL_Only_LongTerm.tblTableColumns","RGL_Only_LongTerm.tblData");
		if (uiDriver.verifyText("RGL_Only_ShortTerm.valunktermtable", input.get("VerifyText@valunktermtable"))) {
			passed("unknownterm_table","unknownterm_table should pass","unknownterm_table passed");
		} else {
			failed("unknownterm_table","unknownterm_table should pass","unknownterm_table failed");
		}
		
		RetriveColumndataandSort("RGL_Only_UnknownTerm.tblTableColumns","RGL_Only_UnknownTerm.tblData");
	}
	
	public void RGL_NoData(DataRow input, DataRow output) {
		//1. checkElementPresent("RGL_NoData.lnkAccount_Summary", 15000)
		uiDriver.checkElementPresent("RGL_NoData.lnkAccount_Summary", 15000);
		
		//2. click("RGL_NoData.lnkAccount_Summary")
		uiDriver.javascriptClick("RGL_NoData.lnkAccount_Summary");
		
		//3. click("RGL_NoData.lnkRealized_gain_loss")
		uiDriver.checkElementPresent("RGL_NoData.lnkRealized_gain_loss", 15000);
		uiDriver.javascriptClick("RGL_NoData.lnkRealized_gain_loss");
		
		//4. setValue("RGL_NoData.lstaccount", input.get("Select@account"))
		uiDriver.checkElementPresent("RGL_NoData.lstaccount", 15000);
		uiDriver.setValue("RGL_NoData.lstaccount", input.get("Select@account"));
		
		//5. click("RGL_NoData.btnView")
		uiDriver.checkElementPresent("RGL_NoData.btnView", 15000);
		uiDriver.click("RGL_NoData.btnView");
		
		if (uiDriver.verifyText("RGL_NoData.edttext", input.get("VerifyText@appmsg"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void RGL_Only_LongTerm(DataRow input, DataRow output) {
		
		if (uiDriver.verifyText("RGL_NoData.vallngtermtable", input.get("VerifyText@vallngtermtable"))) {
			passed("longterm_table","longterm_table should pass","longterm_table passed");
		} else {
			failed("longterm_table","longterm_table should pass","longterm_table failed");
		}
		
		RetriveColumndataandSort("RGL_Only_LongTerm.tblTableColumns","RGL_Only_LongTerm.tblData");
		
	}
	
	public void RGL_Only_ShortTerm(DataRow input, DataRow output) {
		if (uiDriver.verifyText("RGL_Only_ShortTerm.valshorttermtable", input.get("VerifyText@valshorttermtable"))) {
			passed("ShortTerm","ShortTerm should pass","ShortTerm passed");
		} else {
			failed("ShortTerm","ShortTerm should pass","ShortTerm failed");
		}
		
		RetriveColumndataandSort("RGL_Only_ShortTerm.tblTableColumns","RGL_Only_ShortTerm.tblData");
		
	}
	
	public void RGL_Only_UnknownTerm(DataRow input, DataRow output) {
		if (uiDriver.verifyText("RGL_Only_ShortTerm.valunktermtable", input.get("VerifyText@valunktermtable"))) {
			passed("unknownterm_table","unknownterm_table should pass","unknownterm_table passed");
		} else {
			failed("unknownterm_table","unknownterm_table should pass","unknownterm_table failed");
		}
		
		RetriveColumndataandSort("RGL_Only_UnknownTerm.tblTableColumns","RGL_Only_UnknownTerm.tblData");
		
	}

	
	public void RGL_Short_Long_UnknownTerms(DataRow input, DataRow output) {
		uiDriver.checkElementPresent("RGL_Short_Long_UnknownTerms.eltminusshort", 15000);
		uiDriver.click("RGL_Short_Long_UnknownTerms.eltminusshort");
		uiDriver.checkElementPresent("RGL_Short_Long_UnknownTerms.eltminuslong", 15000);
		uiDriver.click("RGL_Short_Long_UnknownTerms.eltminuslong");
		uiDriver.checkElementPresent("RGL_Short_Long_UnknownTerms.eltminusunknown", 15000);
		uiDriver.click("RGL_Short_Long_UnknownTerms.eltminusunknown");
		if (uiDriver.verifyText("RGL_Only_ShortTerm.valshorttermtable", input.get("VerifyText@valshorttermtable"))) {
			passed("ShortTerm","ShortTerm should pass","ShortTerm passed");
		} else {
			failed("ShortTerm","ShortTerm should pass","ShortTerm failed");
		}
		
		RetriveColumndataandSort("RGL_Only_ShortTerm.tblTableColumns","RGL_Only_ShortTerm.tblData");
		
		if (uiDriver.verifyText("RGL_NoData.vallngtermtable", input.get("VerifyText@vallngtermtable"))) {
			passed("longterm_table","longterm_table should pass","longterm_table passed");
		} else {
			failed("longterm_table","longterm_table should pass","longterm_table failed");
		}
		
		RetriveColumndataandSort("RGL_Only_LongTerm.tblTableColumns","RGL_Only_LongTerm.tblData");
		if (uiDriver.verifyText("RGL_Only_ShortTerm.valunktermtable", input.get("VerifyText@valunktermtable"))) {
			passed("unknownterm_table","unknownterm_table should pass","unknownterm_table passed");
		} else {
			failed("unknownterm_table","unknownterm_table should pass","unknownterm_table failed");
		}
		
		RetriveColumndataandSort("RGL_Only_UnknownTerm.tblTableColumns","RGL_Only_UnknownTerm.tblData");
	}
	
	public void RGL_ShortTerm_LongTerm(DataRow input, DataRow output) {
		uiDriver.checkElementPresent("RGL_ShortTerm_LongTerm.eltminusshort", 15000);
		uiDriver.click("RGL_ShortTerm_LongTerm.eltminusshort");
		uiDriver.checkElementPresent("RGL_ShortTerm_LongTerm.eltminuslong", 15000);
		uiDriver.click("RGL_ShortTerm_LongTerm.eltminuslong");
		uiDriver.checkElementPresent("RGL_ShortTerm_LongTerm.eltminusunknown", 15000);
		uiDriver.click("RGL_ShortTerm_LongTerm.eltminusunknown");
		if (uiDriver.verifyText("RGL_Only_ShortTerm.valshorttermtable", input.get("VerifyText@valshorttermtable"))) {
			passed("ShortTerm","ShortTerm should pass","ShortTerm passed");
		} else {
			failed("ShortTerm","ShortTerm should pass","ShortTerm failed");
		}
		
		RetriveColumndataandSort("RGL_Only_ShortTerm.tblTableColumns","RGL_Only_ShortTerm.tblData");
		
		if (uiDriver.verifyText("RGL_NoData.vallngtermtable", input.get("VerifyText@vallngtermtable"))) {
			passed("longterm_table","longterm_table should pass","longterm_table passed");
		} else {
			failed("longterm_table","longterm_table should pass","longterm_table failed");
		}
		
		RetriveColumndataandSort("RGL_Only_LongTerm.tblTableColumns","RGL_Only_LongTerm.tblData");
		
		
	}
	
	public void RGL_UnknownTerm_ShortTerm(DataRow input, DataRow output) {
		uiDriver.checkElementPresent("RGL_UnknownTerm_ShortTerm.eltminusshort", 15000);
		uiDriver.click("RGL_UnknownTerm_ShortTerm.eltminusshort");
		uiDriver.checkElementPresent("RGL_UnknownTerm_ShortTerm.eltminuslong", 15000);
		uiDriver.click("RGL_UnknownTerm_ShortTerm.eltminuslong");
		uiDriver.checkElementPresent("RGL_UnknownTerm_ShortTerm.eltminusunknown", 15000);
		uiDriver.click("RGL_UnknownTerm_ShortTerm.eltminusunknown");
		if (uiDriver.verifyText("RGL_Only_ShortTerm.valshorttermtable", input.get("VerifyText@valshorttermtable"))) {
			passed("ShortTerm","ShortTerm should pass","ShortTerm passed");
		} else {
			failed("ShortTerm","ShortTerm should pass","ShortTerm failed");
		}
		
		RetriveColumndataandSort("RGL_Only_ShortTerm.tblTableColumns","RGL_Only_ShortTerm.tblData");
		
		if (uiDriver.verifyText("RGL_Only_ShortTerm.valunktermtable", input.get("VerifyText@valunktermtable"))) {
			passed("unknownterm_table","unknownterm_table should pass","unknownterm_table passed");
		} else {
			failed("unknownterm_table","unknownterm_table should pass","unknownterm_table failed");
		}
		
		RetriveColumndataandSort("RGL_Only_UnknownTerm.tblTableColumns","RGL_Only_UnknownTerm.tblData");
		
		
		
	}
	
	public void RGL_Year(DataRow input, DataRow output) {
		if (uiDriver.verifyText("RGL_Year.validatetext", input.get("VerifyText@validatetext").trim())) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		
	}
	
	public void RGLValidations(DataRow input, DataRow output) {
		if (uiDriver.verifyText("RGLValidations.eltRGL_Val_Account_Label", input.get("VerifyText@eltRGL_Val_Account_Label").trim())) {
			passed("RGL_Val_Account_Label","RGL_Val_Account_Label should pass","RGL_Val_Account_Label passed");
		} else {
			failed("RGL_Val_Account_Label","RGL_Val_Account_Label should pass","RGL_Val_Account_Label failed");
		}
		
		
		if (uiDriver.verifyText("RGLValidations.eltT_Description_Detail", input.get("VerifyText@eltT_Description_Detail").trim())) {
			passed("Description_Detail","Description_Detail should pass","Description_Detail passed");
		} else {
			failed("Description_Detail","Description_Detail should pass","Description_Detail failed");
		}
		
		
		uiDriver.checkElementPresent("RGLValidations.lnkshortterm", 15000);
		uiDriver.click("RGL_NoData.lnkshortterm");
		
		if (uiDriver.verifyText("RGLValidations.valshortterm", input.get("VerifyText@valshortterm").trim())) {
			passed("shortterm","shortterm should pass","shortterm passed");
		} else {
			failed("shortterm","shortterm should pass","shortterm failed");
		}
		
		uiDriver.checkElementPresent("RGLValidations.btnshrtclose", 15000);
		uiDriver.click("RGL_NoData.btnshrtclose");
		

		uiDriver.checkElementPresent("RGLValidations.lnklongterm", 15000);
		uiDriver.click("RGL_NoData.lnklongterm");
		
		if (uiDriver.verifyText("RGLValidations.vallongterm", input.get("VerifyText@vallongterm").trim())) {
			passed("longterm","longterm should pass","longterm passed");
		} else {
			failed("longterm","longterm should pass","longterm failed");
		}
		
		uiDriver.checkElementPresent("RGLValidations.btnlngclose", 15000);
		uiDriver.click("RGL_NoData.btnlngclose");
		
		
		uiDriver.checkElementPresent("RGLValidations.lnkunkterm", 15000);
		uiDriver.click("RGL_NoData.lnkunkterm");
		
		if (uiDriver.verifyText("RGLValidations.valunkerm", input.get("VerifyText@valunkerm").trim())) {
			passed("unknown term","unknown term should pass","unknown term passed");
		} else {
			failed("unknown term","unknown term should pass","unknown term failed");
		}
		
		uiDriver.checkElementPresent("RGLValidations.btnlngclose", 15000);
		uiDriver.click("RGL_NoData.btnlngclose");
		
		if (uiDriver.verifyText("RGLValidations.lnkallterm", input.get("VerifyText@lnkallterm").trim())) {
			passed("allterm","allterm term should pass","allterm term passed");
		} else {
			failed("allterm term","allterm term should pass","allterm term failed");
		}
	}
	
	public void AccountSummary(DataRow input, DataRow output) {
		//1. Verify whether Account_Summary link exists
		//uiDriver.waitForBrowserStability(150);
		uiDriver.checkElementPresent("AccountSummary.lnkAccount_Summary",30000);
		
		//3. Click on Account_Summary Link

		uiDriver.javascriptClick("AccountSummary.lnkAccount_Summary");
	
	}

	public void Change_Account_Label_Negative(DataRow input, DataRow output) {
		//1. Verify whether Change_account_label link exists
		uiDriver.checkElementPresent("Change_Account_Label_Negative.lnkChange_account_label", 15000);
		
		//2. Click on Change_account_label Link
		uiDriver.javascriptClick("Change_Account_Label_Negative.lnkChange_account_label");
		uiDriver.checkElementPresent("Change_Account_Label_Negative.edtAccount_Label", 15000);
		
		uiDriver.javascriptClick("Change_Account_Label_Negative.edtAccount_Label");
		//3. Type Input in Account_Label field
		uiDriver.setValue("Change_Account_Label_Negative.edtAccount_Label", input.get("Type@Account_Label"));
		
		
		//4. Click on ErrorMessage button
		uiDriver.javascriptClick("Change_Account_Label_Negative.btnErrorMessage");
		uiDriver.checkElementPresent("Change_Account_Label_Negative.btnErrorMessage", 15000);
		
	
		if (uiDriver.verifyText("Change_Account_Label_Negative.ErrorMessage", input.get("VerifyText@AccountError"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
	}
	
	
	public void Change_Account_Label(DataRow input, DataRow output) {
		//1. Verify whether Change_account_label link exists
		uiDriver.checkElementPresent("Change_Account_Label.lnkChange_account_label", 15000);

		//2. Click on Change_account_label Link
		uiDriver.javascriptClick("Change_Account_Label.lnkChange_account_label");
		
		/*
		String [] dataArray=uiDriver.sessionLog("QADRC10");
		System.out.println("Validating session log from database");
		
		System.out.println(dataArray[0]);
		if (dataArray[0].equals("104") ) {
			passed("Change_Contact_Information","Session log should match","sesion log is matched");
		} else {
			failed("Change_Contact_Information","Session log should match","sesion log is not matched");
		}
		
		if (dataArray[2].equals("null") ) {
			passed("Change_Contact_Information","Session log should match","sesion log is matched");
		} else {
			failed("Change_Contact_Information","Session log should match","sesion log is not matched");
		}
		*/
		
		
		uiDriver.checkElementPresent("Change_Account_Label.eltAccount_label", 15000);
		uiDriver.javascriptClick("Change_Account_Label.eltAccount_label");
		
		//5. Verify Input innertext for Account_label WebElement
		/*if (uiDriver.verifyText("Change_Account_Label.eltAccount_label", input.get("Verify@Account_label"))) {
			passed("verify","verify should pass","verify passed");
			
		} else {
			failed("verify","verify should pass","verify failed");
		}
		*/
		//6. Type Input in Account_label field
		uiDriver.setValue("Change_Account_Label.eltAccount_label", input.get("type@Account_label"));
		
		//7. Click on Submit button
		uiDriver.javascriptClick("Change_Account_Label.btnSubmit");
		uiDriver.checkElementPresent("Change_Account_Label.eltMessage", 15000);
		//8. Verify Input innertext for Message WebElement
		if (uiDriver.verifyText("Change_Account_Label.ErrorMessage1", input.get("Verify@Message#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//9. Verify Input innertext for Message WebElement
		/*if (uiDriver.verifyText("Change_Account_Label.eltMessage", input.get("Verify@Message#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}*/
		
		//10. Verify Input innertext for Label WebElement
		String xpath = uiDriver.getLocator("Change_Account_Label.eltLabel")+input.get("type@Account_label")+"']";
		System.out.println(xpath);
		if (uiDriver.checkElementPresentpro(xpath, 20)) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		/*//11. Verify Input innertext for Label WebElement
		if (uiDriver.verifyText("Change_Account_Label.eltLabel", input.get("Verify@Label#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}*/
		
	}
	
	
	public void Nav_Add_Accounts(DataRow input, DataRow output) {
		//1. Verify whether Add_accounts link exists
		uiDriver.Sync("Nav_Add_Accounts.lnkAdd_accounts");
		uiDriver.checkElementPresentpro("Nav_Add_Accounts.lnkAdd_accounts", 20);
		
		//2. Click on Add_accounts Link
		uiDriver.javascriptClick("Nav_Add_Accounts.lnkAdd_accounts");
		
		//3. Verify Input innertext for sessionLog WebElement
		/*String [] dataArray=uiDriver.sessionLog("QADRC160");
		System.out.println("Validating session log from database");
		
		System.out.println(dataArray[0]);
		if (dataArray[0].equals("103") ) {
			passed("Nav_Add_Accounts","Session log should match","sesion log is matched");
		} else {
			failed("Nav_Add_Accounts","Session log should match","sesion log is not matched");
		}
		//4. Verify Input innertext for Miscinfo_Infoaccessed WebElement
		if (dataArray[2].equals("null") ) {
			passed("Nav_Add_Accounts","Session log should match","sesion log is matched");
		} else {
			failed("Nav_Add_Accounts","Session log should match","sesion log is not matched");
		}*/
	
		
		//7. Verify Input innertext for VerifyAddAccounts WebElement
		uiDriver.checkElementPresentpro("Nav_Add_Accounts.eltVerifyAddAccounts", 30);
		String ADDpage=uiDriver.getControl("Nav_Add_Accounts.eltVerifyAddAccounts").getText().trim();
		System.out.println(ADDpage);
		if (ADDpage.contains(input.get("Verify@VerifyAddAccounts").trim())) {
			passed("Verify AddAccounts","verify eltVerifyAddAccounts should pass","verify eltVerifyAddAccounts passed");
		} else {
			failed("Verify AddAccounts","verify eltVerifyAddAccounts should pass","verify eltVerifyAddAccounts failed");
		}
		
	}
	
	public void AddAcnt_Negative_Validations(DataRow input, DataRow output) {
		//1. Type Input in Account_Number1 field
		uiDriver.Sync("AddAcnt_Negative_Validations.AddMoreRows");
		if(!input.get("Type@Account_Number1").equals("NA")){
		uiDriver.checkElementPresentpro("AddAcnt_Negative_Validations.edtAccount_Number1", 10);
		uiDriver.setValue("AddAcnt_Negative_Validations.edtAccount_Number1", input.get("Type@Account_Number1"));
		}
		//2. Type Input in Account_Label1 field
		if(!input.get("Type@Account_Label1").equals("NA")){
		uiDriver.checkElementPresentpro("AddAcnt_Negative_Validations.edtAccount_Label1", 10000);
		uiDriver.setValue("AddAcnt_Negative_Validations.edtAccount_Label1", input.get("Type@Account_Label1"));
		}
		//3. Type Input in Account_Number2 field
		if(!input.get("Type@Account_Number2").equals("NA")){
		uiDriver.checkElementPresentpro("AddAcnt_Negative_Validations.edtAccount_Number2", 10000);
		uiDriver.setValue("AddAcnt_Negative_Validations.edtAccount_Number2", input.get("Type@Account_Number2"));
		}
		//4. Type Input in Account_Label2 field
		if(!input.get("Type@Account_Label2").equals("NA")){
			if(uiDriver.checkElementPresentpro("AddAcnt_Negative_Validations.edtAccount_Label2", 10000))
			{
				uiDriver.setValue("AddAcnt_Negative_Validations.edtAccount_Label2", input.get("Type@Account_Label2"));
			}
			else
			{
				uiDriver.javascriptClick("AddAcnt_Negative_Validations.AddMoreRows");
			}
		}
		//5. Click on ErrorMessage button
		uiDriver.checkElementPresentpro("AddAcnt_Negative_Validations.btnErrorMessage", 15000);
		uiDriver.javascriptClick("AddAcnt_Negative_Validations.btnErrorMessage");
		
		
		if(input.get("Text@Submit").equals("Submit")){
			uiDriver.javascriptClick("AddAcnt_Negative_Validations.BtnReviewandSubmit");
			if(!input.get("VerifyText@ErrorMessageRestriction").equals("")){
				
				uiDriver.verifyText("AddAcnt_Negative_Validations.ErrorMessageRestriction", input.get("VerifyText@ErrorMessageRestriction"));
			}
			
		}
		else{
		//8. Verify Input innertext for Message WebElement
			if(!input.get("VerifyText@ErrorMessege1").equals("")){
				uiDriver.verifyText("AddAcnt_Negative_Validations.ErrorMessage1", input.get("VerifyText@ErrorMessege1"));
				
			}
			
			if(!input.get("VerifyText@ErrorMessege2").equals("")){
				uiDriver.verifyText("AddAcnt_Negative_Validations.ErrorMessage2", input.get("VerifyText@ErrorMessege2"));
			}
			
			if(!input.get("VerifyText@ErrorMessege3").equals("")){
				uiDriver.verifyText("AddAcnt_Negative_Validations.ErrorMessage3", input.get("VerifyText@ErrorMessege3"));
			}
			
			if(!input.get("VerifyText@ErrorMessege4").equals("")){
				uiDriver.verifyText("AddAcnt_Negative_Validations.ErrorMessage4", input.get("VerifyText@ErrorMessege4"));
			}
			if(!input.get("VerifyText@ErrorMessege5").equals("")){
				uiDriver.verifyText("AddAcnt_Negative_Validations.ErrorMessage5", input.get("VerifyText@ErrorMessege5"));
			}
			
			if(!input.get("VerifyText@ErrorMessege6").equals("")){
				uiDriver.verifyText("AddAcnt_Negative_Validations.ErrorMessage6", input.get("VerifyText@ErrorMessege6"));
			}
			
			if(!input.get("VerifyText@ErrorMessege7").equals("")){
				uiDriver.verifyText("AddAcnt_Negative_Validations.ErrorMessage7", input.get("VerifyText@ErrorMessege7"));
			}
			
			if(!input.get("VerifyText@ErrorMessege8").equals("")){
				uiDriver.verifyText("AddAcnt_Negative_Validations.ErrorMessage8", input.get("VerifyText@ErrorMessege8"));
			}
			
			if(!input.get("VerifyText@ErrorMessege9").equals("")){
				uiDriver.verifyText("AddAcnt_Negative_Validations.ErrorMessage9", input.get("VerifyText@ErrorMessege9"));
			}
			
			if(!input.get("VerifyText@ErrorMessege10").equals("")){
				uiDriver.verifyText("AddAcnt_Negative_Validations.ErrorMessage10", input.get("VerifyText@ErrorMessege10"));
			}
			
			if(!input.get("VerifyText@bottomErrorMessage1").equals("")){
			String xpath = uiDriver.getLocator("AddAcnt_Negative_Validations.bottomErrorMessage1")+input.get("VerifyText@bottomErrorMessage1")+"')]";
			System.out.println(xpath);
			if (uiDriver.checkElementPresentpro(xpath, 20)) {
				passed("verify","verify should pass","verify passed");
			} else {
				failed("verify","verify should pass","verify failed");
			}
			}
			
			if(!input.get("VerifyText@bottomErrorMessage2").equals("")){
				String xpath = uiDriver.getLocator("AddAcnt_Negative_Validations.bottomErrorMessage2")+input.get("VerifyText@bottomErrorMessage2")+"')]";
				System.out.println(xpath);
				if (uiDriver.checkElementPresentpro(xpath, 20)) {
					passed("verify","verify should pass","verify passed");
				} else {
					failed("verify","verify should pass","verify failed");
				}
			}
			
			if(!input.get("VerifyText@bottomErrorMessage3").equals("")){
				String xpath = uiDriver.getLocator("AddAcnt_Negative_Validations.bottomErrorMessage3")+input.get("VerifyText@bottomErrorMessage3")+"')]";
				System.out.println(xpath);
				if (uiDriver.checkElementPresentpro(xpath, 20)) {
					passed("verify","verify should pass","verify passed");
				} else {
					failed("verify","verify should pass","verify failed");
				}
			}
			if(!input.get("VerifyText@bottomErrorMessage4").equals("")){
				String xpath = uiDriver.getLocator("AddAcnt_Negative_Validations.bottomErrorMessage4")+input.get("VerifyText@bottomErrorMessage4")+"')]";
				System.out.println(xpath);
				if (uiDriver.checkElementPresentpro(xpath, 20)) {
					passed("verify","verify should pass","verify passed");
				} else {
					failed("verify","verify should pass","verify failed");
				}
			}
		
		}
	}
	
	
	public void Nav_Remove_Accounts(DataRow input, DataRow output) {
		//1. Verify whether Remove_accounts link exists
		uiDriver.checkElementPresent("Nav_Remove_Accounts.lnkRemove_accounts", 15000);
		
		//2. Click on Remove_accounts Link
		uiDriver.javascriptClick("Nav_Remove_Accounts.lnkRemove_accounts");
		
		
		/*String [] dataArray=uiDriver.sessionLog("QADRC160");
		System.out.println("Validating session log from database");
		//3. Verify Input innertext for sessionLog WebElement
		System.out.println(dataArray[0]);
		if (dataArray[0].equals("147") ) {
			passed("Nav_Remove_Accounts","Session log should match","sesion log is matched");
		} else {
			failed("Nav_Remove_Accounts","Session log should match","sesion log is not matched");
		}
		//4. Verify Input innertext for Miscinfo_Infoaccessed WebElement
		if (dataArray[2].equals("null") ) {
			passed("Nav_Remove_Accounts","Session log should match","sesion log is matched");
		} else {
			failed("Nav_Remove_Accounts","Session log should match","sesion log is not matched");
		}*/
		
	
		
	}
	
	
	public void RemoveAcnt_Negative_Valid0(DataRow input, DataRow output) {
		//1. Verify whether next button exists
		uiDriver.checkElementPresent("RemoveAcnt_Negative_Valid0.btnnext", 15000);
		
		//2. Click on next button
		uiDriver.javascriptClick("RemoveAcnt_Negative_Valid0.btnnext");
		
		//3. Verify Input inner-text for ErrorMessage WebElement
	   String val= uiDriver.getControl("RemoveAcnt_Negative_Valid0.eltErrorMessage1").getText();
	   if(val.equalsIgnoreCase(input.get("Verify@ErrorMessage#1"))){
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
	   
	   uiDriver.clickOnMultipleCheckBox("RemoveAcnt_Negative_Valid0.lstAll");
	
		
		//5. Click on next button
		uiDriver.javascriptClick("RemoveAcnt_Negative_Valid0.btnnext");
		
		//6. Verify Input innertext for ErrorMessage WebElement
		String val2= uiDriver.getControl("RemoveAcnt_Negative_Valid0.eltErrorMessage2").getText();
		System.out.print(val2);
		   if(val2.equalsIgnoreCase(input.get("Verify@ErrorMessage#2"))){
				passed("verify","verify should pass","verify passed");
			} else {
				failed("verify","verify should pass","verify failed");
			}		
		
	}
	
	
	public void Remove_OneAccount(DataRow input, DataRow output) {
		//1. Select Input from the SelectAccount list
		uiDriver.ClickOnGivenCheckbox("Remove_OneAccount.lstSelectAccount",input.get("Select@SelectAccount"));
			
		//2. Verify Input innertext for SelectAccount WebElement
		
		
		String Select_account = uiDriver.getLocator("Remove_OneAccount.eltSelectAccount");
		Select_account = Select_account.replace("ChkBoxText", input.get("Select@SelectAccount"));	
		System.out.println(Select_account);
		String text= uiDriver.getWebElement(Select_account).getText();
		   if(text.equals(input.get("Verify@SelectAccount"))){
				passed("verify","verify should pass","verify passed");
			} else {
				failed("verify","verify should pass","verify failed");
			}			
	}
	
	public void Remove_Confirmation(DataRow input, DataRow output) {
		//1. Verify whether next button exists
		uiDriver.checkElementPresent("Remove_Confirmation.btnnext", 15000);
		
		//2. Click on next button
		uiDriver.click("Remove_Confirmation.btnnext");
		
		//3. Verify Input Title for Review_and_Submit Page
		if (uiDriver.verifyText("Remove_Confirmation.pgeReview_and_Submit", input.get("Verify@Review_and_Submit"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//4. Click on Submit button
		/*uiDriver.click("Remove_Confirmation.btnSubmit");
		
		
		//5. Verify Input innertext for Status WebElement
		if (uiDriver.verifyText("Remove_Confirmation.eltStatus", input.get("Verify@Status#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//6. Verify Input innertext for Status WebElement
		if (uiDriver.verifyText("Remove_Confirmation.eltStatus", input.get("Verify@Status#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//7. Verify Input innertext for Message WebElement
		if (uiDriver.verifyText("Remove_Confirmation.eltMessage", input.get("Verify@Message#1"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		
		//8. Verify Input innertext for Message WebElement
		if (uiDriver.verifyText("Remove_Confirmation.eltMessage", input.get("Verify@Message#2"))) {
			passed("verify","verify should pass","verify passed");
		} else {
			failed("verify","verify should pass","verify failed");
		}
		*/
	}
	//function to do sorting on particular column
	
	
	public void Verfify_AccountRemoved(DataRow input, DataRow output) throws InterruptedException {
		//1. Verify whether Portfolio_Summary link exists
		uiDriver.checkElementPresent("Verfify_AccountRemoved.lnkPortfolio_Summary", 15000);
		
		//2. Click on Portfolio_Summary Link
		uiDriver.javascriptClick("Verfify_AccountRemoved.lnkPortfolio_Summary");
		
		String xpath= uiDriver.getLocator("Verfify_AccountRemoved.eltPage1");
		xpath= xpath.replace("ChkBoxText", input.get("Verify@Page#1"));
		//3. Verify Input innertext for Page WebElement
		uiDriver.ApplicationSync();
		if (uiDriver.checkElementPresentpro(xpath, 15)) {
			failed("verify account in lnkPortfolio_Summary","verify account should not present","verify account is present");
		} else {
			passed("verify account in lnkPortfolio_Summary","verify account should not present","verify account is not present");
		}
		uiDriver.checkElementPresent("Verfify_AccountRemoved.lnkAccount_Summary", 15000);
		uiDriver.javascriptClick("Verfify_AccountRemoved.lnkAccount_Summary");
		
		//5. Verify Input innertext for Page WebElement
		List<String> list= uiDriver.getDropDownOptions("Verfify_AccountRemoved.eltPage2");
		if(uiDriver.CheckTextInOption(list,input.get("Verify@Page#2"))){
			failed("verify account in lnkAccount_Summary","verify account should not present","verify account is present");	
			
		}
		else{
			passed("verify account in lnkAccount_Summary","verify account should not present","verify account is not present");	
			
		}
		
		//6. Click on Fixed_Income Link
		uiDriver.checkElementPresent("Verfify_AccountRemoved.lnkFixed_Income", 15000);
		uiDriver.javascriptClick("Verfify_AccountRemoved.lnkFixed_Income");
		
		//7. Verify Input innertext for Page WebElement
		List<String> list3= uiDriver.getDropDownOptions("Verfify_AccountRemoved.eltPage3");
		if(uiDriver.CheckTextInOption(list3,input.get("Verify@Page#3"))){
			failed("verify account in lnkFixed_Income","verify account should not present","verify account is present");	
		}
		else{
			passed("verify account in lnkFixed_Income","verify account should not present","verify account is not present");
		}
		
		//8. Click on Realized_gain_loss Link
		uiDriver.checkElementPresent("Verfify_AccountRemoved.lnkRealized_gain_loss",15000);
		uiDriver.javascriptClick("Verfify_AccountRemoved.lnkRealized_gain_loss");
		
		List<String> list4= uiDriver.getDropDownOptions("Verfify_AccountRemoved.eltPage4");
		if(uiDriver.CheckTextInOption(list4,input.get("Verify@Page#4"))){
			failed("verify account in lnkRealized_gain_loss","verify account should not present","verify account is present");		
		}
		else{
			
			passed("verify account in lnkRealized_gain_loss","verify account should not present","verify account is not present");	
		}
		
		//10. Click on Income_Summary Link
		uiDriver.checkElementPresent("Verfify_AccountRemoved.lnkIncome_Summary",15000);
		uiDriver.javascriptClick("Verfify_AccountRemoved.lnkIncome_Summary");
		
		//11. Verify Input innertext for Page WebElement
		List<String> list5= uiDriver.getDropDownOptions("Verfify_AccountRemoved.eltPage5");
		if(uiDriver.CheckTextInOption(list5,input.get("Verify@Page#5"))){
			failed("verify account in lnkIncome_Summary","verify account should not present","verify account is present");
				
		}
		else{
			passed("verify account in lnkIncome_Summary","verify account should not present","verify account is not present");
				
		}
		
		//12. Click on Open_Orders Link
		uiDriver.checkElementPresent("Verfify_AccountRemoved.lnkOpen_Orders",15000);
		uiDriver.javascriptClick("Verfify_AccountRemoved.lnkOpen_Orders");
		
		//13. Verify Input innertext for Page WebElement
		//uiDriver.checkElementPresent("Verfify_AccountRemoved.eltPage6",15000);
		List<String> list6= uiDriver.getDropDownOptions("Verfify_AccountRemoved.eltPage6");
		if(uiDriver.CheckTextInOption(list6,input.get("Verify@Page#6"))){
			failed("verify account in lnkOpen_Orders","verify account should not present","verify account is present");
			
		}
		else{
			passed("verify account in lnkOpen_Orders","verify account should not present","verify account is not present");	
		}
		
		//14. Click on Trasaction_Detail Link
		uiDriver.checkElementPresent("Verfify_AccountRemoved.lnkTrasaction_Detail",15000);
		uiDriver.javascriptClick("Verfify_AccountRemoved.lnkTrasaction_Detail");
		
		//15. Verify Input innertext for Page WebElement
		uiDriver.checkElementPresent("Verfify_AccountRemoved.eltPage7",15000);
		List<String> list7= uiDriver.getDropDownOptions("Verfify_AccountRemoved.eltPage7");
		if(uiDriver.CheckTextInOption(list7,input.get("Verify@Page#7"))){
			
			failed("verify account in lnkOpen_Orders","verify account should not present","verify account is present");
		}
		else{
			passed("verify account in lnkOpen_Orders","verify account should not present","verify account is not present");	
		}
		
		//16. Click on Online_Documents Link
		uiDriver.checkElementPresent("Verfify_AccountRemoved.lnkOnline_Documents",15000);
		uiDriver.javascriptClick("Verfify_AccountRemoved.lnkOnline_Documents");
		
		//17. Verify Input innertext for Page WebElement
		uiDriver.checkElementPresent("Verfify_AccountRemoved.eltPage8",15000);
		List<String> list8= uiDriver.getDropDownOptions("Verfify_AccountRemoved.eltPage8");
		if(uiDriver.CheckTextInOption(list8,input.get("Verify@Page#8"))){
			failed("verify account in lnkOnline_Documents","verify account should not present","verify account is present");
			
		}
		else{
			passed("verify account in lnkOnline_Documents","verify account should not present","verify account is not present");	
		}
	
		//18. Click on Add_accounts Link
		uiDriver.checkElementPresent("Verfify_AccountRemoved.lnkAdd_accounts",15000);
		uiDriver.javascriptClick("Verfify_AccountRemoved.lnkAdd_accounts");
		
		//19. Verify Input innertext for Page WebElement
		String xpath2= uiDriver.getLocator("Verfify_AccountRemoved.eltPage9");
		xpath= xpath2.replace("ChkBoxText", input.get("Verify@Page#9"));
		//3. Verify Input innertext for Page WebElement
		if (uiDriver.checkElementPresentpro(xpath, 15)) {
			failed("verify account in lnkAdd_accounts","verify account should not present","verify account is present");
		} else {
			passed("verify account in lnkAdd_accounts","verify account should not present","verify account is not present");
		}
		//20. Click on Remove_accounts Link
		uiDriver.checkElementPresent("Verfify_AccountRemoved.lnkRemove_accounts",15000);
		uiDriver.javascriptClick("Verfify_AccountRemoved.lnkRemove_accounts");
		
		//21. Verify Input innertext for Page WebElement
		String xpath3= uiDriver.getLocator("Verfify_AccountRemoved.eltPage10");
		xpath= xpath3.replace("ChkBoxText", input.get("Verify@Page#10"));
		//3. Verify Input innertext for Page WebElement
		if (uiDriver.checkElementPresentpro(xpath, 15)) {
			failed("verify account in lnkRemove_accounts","verify account should not present","verify account is present");
		} else {
			passed("verify account in lnkRemove_accounts","verify account should not present","verify account is not present");
		}
		
		//22. Click on Change_account_label Link
		uiDriver.checkElementPresent("Verfify_AccountRemoved.lnkChange_account_label",15000);
		uiDriver.javascriptClick("Verfify_AccountRemoved.lnkChange_account_label");
		
		//23. Verify Input innertext for Page WebElement
		String xpath4= uiDriver.getLocator("Verfify_AccountRemoved.eltPage11");
		
		xpath= xpath4.replace("ChkBoxText", input.get("Verify@Page#11"));
		if (uiDriver.checkElementPresentpro(xpath, 15)) {
			failed("verify account in lnkChange_account_label","verify account should not present","verify account is present");
		} else {
			passed("verify account in lnkChange_account_label","verify account should not present","verify account is not present");
		}
		
	}
	
	public void Remove_MultipleAccount(DataRow input, DataRow output) {
		//1. Select Input from the SelectAccount list
		uiDriver.ClickOnGivenCheckbox("Remove_MultipleAccount.lstSelectAccount",input.get("Select@SelectAccount1"));
					
		//2. Verify Input innertext for SelectAccount WebElement
		String Select_account = uiDriver.getLocator("Remove_OneAccount.eltSelectAccount");
		Select_account = Select_account.replace("ChkBoxText", input.get("Select@SelectAccount1"));	
		System.out.println(Select_account);
		String text= uiDriver.getWebElement(Select_account).getText();
		if(text.equals(input.get("Verify@SelectAccount1"))){
				passed("verify","verify should pass","verify passed");
		} else {
				failed("verify","verify should pass","verify failed");
		}	
		//3. Select Input2 from the SelectAccount list
		uiDriver.ClickOnGivenCheckbox("Remove_MultipleAccount.lstSelectAccount",input.get("Select@SelectAccount2"));
		
		//4. Verify Input innertext for SelectAccount WebElement
		String Select_account2 = uiDriver.getLocator("Remove_OneAccount.eltSelectAccount");
		Select_account2 = Select_account2.replace("ChkBoxText", input.get("Select@SelectAccount2"));	
		System.out.println(Select_account2);
		String text2= uiDriver.getWebElement(Select_account2).getText();
		if(text2.equals(input.get("Verify@SelectAccount2"))){
				passed("verify","verify should pass","verify passed");
		} else {
				failed("verify","verify should pass","verify failed");
		}		
		
	}

	public void ManualAdd_Accounts(DataRow input, DataRow output) {
		//1. Exists Account_Number
		//uiDriver.scrollToView("ManualAdd_Accounts.edtAccount_Number");
		uiDriver.Sync("ManualAdd_Accounts.edtAccount_Number");
		uiDriver.checkElementPresentpro("ManualAdd_Accounts.edtAccount_Number", 15);
		//2. Type Input in Account_Number field
		uiDriver.setValue("ManualAdd_Accounts.edtAccount_Number", input.get("type@Account_Number"));
		
		uiDriver.checkElementPresentpro("ManualAdd_Accounts.edtAccount_label", 15);
		//3. Type Input in Account_label field
		uiDriver.setValue("ManualAdd_Accounts.edtAccount_label", input.get("type@Account_label"));
		
		//4. Click on Next button
		uiDriver.javascriptClick("ManualAdd_Accounts.btnNext");
		
		//5. Verify Input Title for Review_and_Submit Page
		if (uiDriver.verifyText("ManualAdd_Accounts.pgeReview_and_Submit", input.get("Verify@Review_and_Submit"))) {
			passed("verify pgeReview_and_Submit","verify pgeReview_and_Submit should pass","verify pgeReview_and_Submit passed");
		} else {
			failed("verify pgeReview_and_Submit","verify pgeReview_and_Submit should pass","verify pgeReview_and_Submit failed");
		}
		
		//6. Click on Submit button
		uiDriver.checkElementPresentpro("ManualAdd_Accounts.btnSubmit", 10);
		uiDriver.click("ManualAdd_Accounts.btnSubmit");
		
		//7. Verify Input innertext for Status WebElement
		
		String xpath = uiDriver.getLocator("ManualAdd_Accounts.eltStatus");
		xpath = xpath.replace("ChkBoxText", input.get("type@Account_Number"));	
		String text= uiDriver.getWebElement(xpath).getText();
		if(text.equals(input.get("Verify@Status#1"))){
				passed("verify Account_Number","verify Account_Number should pass","verify Account_Number passed");
		} else {
				failed("verify Account_Number","verify  Account_Number should pass","verify Account_Number failed");
		}
		
		
		
	}
	
	
	
	public void Validationqueue(DataRow input, DataRow output) throws InterruptedException {
		//1. Verify whether Access_Check radio group exists
		uiDriver.checkElementPresent("Validationqueue.btnReset", 10);
		uiDriver.javascriptClick("Validationqueue.btnReset");
		//uiDriver.AppSync();
		uiDriver.checkElementPresentpro("Validationqueue.lstSelectAccount", 10);
		
		//2. Click on Request_Id Link
		if(!input.get("Type@AddedAccount").equals("NA"))
		uiDriver.setValue("Validationqueue.lstSelectAccount",input.get("Type@AddedAccount"));
		
		if(!input.get("Type@userID").equals("NA"))
		uiDriver.setValue("Validationqueue.lstSelectUserId",input.get("Type@userID"));
		
		if(!input.get("Type@SSN").equals("NA"))
		uiDriver.setValue("Validationqueue.lstSelectSSN",input.get("Type@SSN"));
		
		if(!input.get("Type@Email").equals("NA"))
		uiDriver.setValue("Validationqueue.lstSelectEmail",input.get("Type@Email"));
		
		//uiDriver.AppSync();
		uiDriver.checkElementPresentpro("Validationqueue.btnSearch", 10); 
		uiDriver.javascriptClick("Validationqueue.btnSearch");
		//uiDriver.AppSync();
		uiDriver.checkElementPresent("Validationqueue.lnkRequest_Id", 10);
		Reportpath=uiDriver.getText(uiDriver.getLocator("Validationqueue.lnkRequest_Id"));
		//uiDriver.AppSync();
		uiDriver.javascriptClick("Validationqueue.lnkRequest_Id");
		System.out.println("WMOnlineDriver...........");
		//3. Verify Input Title for Account_Details Page
		
		
		uiDriver.checkElementPresentpro("Validationqueue.eltAccountRows", 10);
		String path=uiDriver.getLocator("Validationqueue.eltAccountRows");
		List <String> accounts=new ArrayList();
		List<WebElement> tr_Collection = uiDriver.getWebElements(path+"/tr");
		for(int j=1;j<=tr_Collection.size();j++){
              	String data= uiDriver.getWebElement(path+"/tr["+j+"]/td[4]").getText().trim(); 
              	accounts.add(data);
             } 
		
		int index=0; 
		if(accounts.contains(input.get("Verify@Account_Details#1").trim())){
				passed("verify","verify should pass","verify passed");
			} else {
				failed("verify","verify should pass","verify failed");
			}
		
		
		//4. Click on Validate Link
	
		index=accounts.indexOf(input.get("Verify@Account_Details#1").trim());
		index= index+1;
		
		String ValidateLink=path+"/tr["+index+"]//a";
		uiDriver.getWebElement(ValidateLink).click();
		
		
		
		//5. Click Access_Check
		uiDriver.checkElementPresent("Validationqueue.rdgAccess_Check", 10);
		uiDriver.javascriptClick("Validationqueue.rdgAccess_Check");
		
		//6. Click Name_and_address_check
		uiDriver.checkElementPresent("Validationqueue.rdgName_and_address_check", 10);
		uiDriver.javascriptClick("Validationqueue.rdgName_and_address_check");
		
		//7. Click SSN_Check
		uiDriver.checkElementPresent("Validationqueue.rdgSSN_Check", 10);
		uiDriver.javascriptClick("Validationqueue.rdgSSN_Check");
		
		//8. Click IE_check
		uiDriver.checkElementPresent("Validationqueue.rdgIE_check", 10);
		uiDriver.javascriptClick("Validationqueue.rdgIE_check");
		
		//9. Click Suppression_Eligible
		uiDriver.checkElementPresent("Validationqueue.rdgSuppression_Eligible", 10);
		uiDriver.javascriptClick("Validationqueue.rdgSuppression_Eligible");
		
		//10. Click on Grant button
		uiDriver.checkElementPresent("Validationqueue.btnGrant", 10);
		uiDriver.javascriptClick("Validationqueue.btnGrant");
		
		//11. Verify Input Title for Save_Validation Page
		uiDriver.checkElementPresent("Validationqueue.pgeSave_Validation", 10);
		String val= uiDriver.getControl("Validationqueue.pgeSave_Validation").getText().trim();
		System.out.print(val);
		   if(val.equalsIgnoreCase(input.get("Verify@Save_Validation#1").trim())){
				passed("verify","verify should pass","verify passed");
			} else {
				failed("verify","verify should pass","verify failed");
			}
		
		
		//12. Click on Grant button
		uiDriver.checkElementPresent("Validationqueue.btnGrant2", 10);
		uiDriver.javascriptClick("Validationqueue.btnGrant2");
		
		//13. Verify Input Title for Save_Validation Page
		uiDriver.checkElementPresent("Validationqueue.pgeSave_Validation2", 10);
		String val3= uiDriver.getControl("Validationqueue.pgeSave_Validation2").getText();
		System.out.print(val3);
		   if(val3.equalsIgnoreCase(input.get("Verify@Save_Validation#2"))){
				passed("verify","verify should pass","verify passed");
			} else {
				failed("verify","verify should pass","verify failed");
			}
		
		//14. Click on Ok button
		uiDriver.checkElementPresent("Validationqueue.btnOk", 10);
		uiDriver.javascriptClick("Validationqueue.btnOk");
		
		//15. Verify Input Title for Account_Details Page
		//16. Click on Close button
		   uiDriver.checkElementPresent("Validationqueue.btnClose", 10);
		uiDriver.javascriptClick("Validationqueue.btnClose");
		
	}
	
	public void FANotificationQueue(DataRow input, DataRow output) throws InterruptedException {
		
	
		uiDriver.checkElementPresent("FANotificationQueue.eltFA_Notification_Queue", 15);
		uiDriver.javascriptClick("FANotificationQueue.eltFA_Notification_Queue");
		
		
		//1. Verify whether Help link exists
		
		uiDriver.checkElementPresentpro("FANotificationQueue.lnkHelp", 15);
				
		uiDriver.checkElementPresent("FANotificationQueue.btnReset", 10);
		uiDriver.javascriptClick("FANotificationQueue.btnReset");
		uiDriver.AppSync();
		uiDriver.checkElementPresent("FANotificationQueue.lstSelectAccount", 10);
		
		
		uiDriver.setValue("FANotificationQueue.lstSelectAccount",input.get("Select@Account_created"));
		uiDriver.AppSync();
		uiDriver.checkElementPresent("FANotificationQueue.btnSearch", 10); 
		uiDriver.javascriptClick("FANotificationQueue.btnSearch");
		uiDriver.AppSync();
				
		//2. setValueIfDataPresent("FANotificationQueue.chkAccount_created", input.get("Select@Account_created"))
		String xpath= uiDriver.getLocator("FANotificationQueue.chkAccount_created");
		xpath= xpath.replace("ChkBoxText", Reportpath);
		uiDriver.checkElementPresentpro(xpath, 15);
		uiDriver.ClickOnGivenCheckbox("FANotificationQueue.chkAccount_created",Reportpath);
			
		//3. setValueIfDataPresent("FANotificationQueue.lstMisc_Requests", input.get("Select@Misc_Requests"))
		uiDriver.checkElementPresentpro("FANotificationQueue.lstMisc_Requests", 15);
		uiDriver.javascriptClick("FANotificationQueue.lstMisc_Requests");
		
		//4. Verify("FANotificationQueue.pgeAre_You_Sure", input.get("Verify@Are_You_Sure"))
		uiDriver.checkElementPresentpro("FANotificationQueue.pgeAre_You_Sure", 15);
		String val= uiDriver.getControl("ClientNotificationQueue.pgeAre_You_Sure").getText();
		System.out.print(val);
		   if(val.equalsIgnoreCase(input.get("Verify@Are_You_Sure"))){
				passed("Verify Are_You_sure","verify Are_You_sure should present","Verify@Are_You_sure is present");
			} else {
				failed("Verify Are_You_sure","VerifyAre_You_sure should present","Verify@Are_You_sure is not present");
			}
				
		//6. click("FANotificationQueue.btnok")
		uiDriver.javascriptClick("FANotificationQueue.btnok");
				
		//8. click("FANotificationQueue.btnok")
		uiDriver.javascriptClick("FANotificationQueue.btnok");
		
	}
	
	public void ClientNotificationQueue(DataRow input, DataRow output) throws InterruptedException {
		
		uiDriver.checkElementPresent("ClientNotificationQueue.eltClient_Notification_Queue", 15);
		uiDriver.javascriptClick("ClientNotificationQueue.eltClient_Notification_Queue");
		
		
		//1. Verify whether Help link exists
		
		uiDriver.checkElementPresentpro("ClientNotificationQueue.lnkAction", 15);
				
		uiDriver.checkElementPresent("ClientNotificationQueue.btnReset", 10);
		uiDriver.javascriptClick("ClientNotificationQueue.btnReset");
		uiDriver.AppSync();
		uiDriver.checkElementPresent("ClientNotificationQueue.lstSelectAccount", 10);
		
		//2. Click on Request_Id Link
		uiDriver.setValue("ClientNotificationQueue.lstSelectAccount",input.get("Select@Account_created"));
		uiDriver.AppSync();
		uiDriver.checkElementPresent("ClientNotificationQueue.btnSearch", 10); 
		uiDriver.javascriptClick("ClientNotificationQueue.btnSearch");
		uiDriver.AppSync();
				
		//2. setValueIfDataPresent("FANotificationQueue.chkAccount_created", input.get("Select@Account_created"))
		String xpath= uiDriver.getLocator("ClientNotificationQueue.chkAccount_created");
		xpath= xpath.replace("ChkBoxText", Reportpath);
		uiDriver.checkElementPresentpro(xpath, 15);
		uiDriver.ClickOnGivenCheckbox("ClientNotificationQueue.chkAccount_created",Reportpath);
			
		//3. setValueIfDataPresent("FANotificationQueue.lstMisc_Requests", input.get("Select@Misc_Requests"))
		uiDriver.checkElementPresentpro("ClientNotificationQueue.lstMisc_Requests", 15);
		uiDriver.javascriptClick("ClientNotificationQueue.lstMisc_Requests");
		
		//4. Verify("FANotificationQueue.pgeAre_You_Sure", input.get("Verify@Are_You_Sure"))
		uiDriver.checkElementPresentpro("ClientNotificationQueue.pgeAre_You_Sure", 15);
		String val= uiDriver.getControl("ClientNotificationQueue.pgeAre_You_Sure").getText();
		System.out.print(val);
		   if(val.equalsIgnoreCase(input.get("Verify@Are_You_sure"))){
				passed("Verify Are_You_sure","verify Are_You_sure should present","Verify@Are_You_sure is present");
			} else {
				failed("Verify Are_You_sure","VerifyAre_You_sure should present","Verify@Are_You_sure is not present");
			}
		
				
		//6. click("FANotificationQueue.btnok")
		uiDriver.checkElementPresentpro("ClientNotificationQueue.btnok", 15);
		uiDriver.javascriptClick("ClientNotificationQueue.btnok");
				
		//8. click("FANotificationQueue.btnok")
		uiDriver.checkElementPresentpro("ClientNotificationQueue.btnok", 15);
		uiDriver.javascriptClick("ClientNotificationQueue.btnok");
	}
	
	public void CompletedRequest(DataRow input, DataRow output) throws InterruptedException {
		//1. setValueIfDataPresent("CompletedRequest.eltCompleted_Requests", input.get("Select@Completed_Requests"))
		Reportpath="905522";
		uiDriver.click("CompletedRequest.lnkCompletedRequest");
		uiDriver.checkElementPresentpro("CompletedRequest.lnkCompletedRequest", 40);
		
		uiDriver.checkElementPresent("CompletedRequest.btnReset", 10);
		uiDriver.javascriptClick("CompletedRequest.btnReset");
		uiDriver.AppSync();
		uiDriver.checkElementPresent("CompletedRequest.lstSelectAccount", 10);
		
		//2. Click on Request_Id Link
		uiDriver.setValue("CompletedRequest.lstSelectAccount",input.get("Select@Account_created"));
		uiDriver.AppSync();
		uiDriver.checkElementPresent("CompletedRequest.btnSearch", 10); 
		uiDriver.javascriptClick("CompletedRequest.btnSearch");
		uiDriver.AppSync();
		
		String xpath= uiDriver.getLocator("CompletedRequest.eltCompleted_Requests");
		xpath= xpath.replace("ChkBoxText", Reportpath);
		//3. Verify Input innertext for Page WebElement
		if (uiDriver.checkElementPresentpro(xpath, 15)) {
			passed("verify account in CompletedRequest","verify account should not present","verify account is not present");	
		} else {
			failed("verify account in CompletedRequest","verify account should not present","verify account is present");
		}
		
	}

	public void Verfify_AccountAdded(DataRow input, DataRow output) {
		uiDriver.checkElementPresent("Verfify_AccountAdded.lnkPortfolio_Summary", 15000);
		
		//2. Click on Portfolio_Summary Link
		uiDriver.javascriptClick("Verfify_AccountAdded.lnkPortfolio_Summary");
		
		String xpath= uiDriver.getLocator("Verfify_AccountAdded.eltPage1");
		xpath= xpath.replace("ChkBoxText", input.get("Verify@Page#1"));
		//3. Verify Input innertext for Page WebElement
		if (uiDriver.checkElementPresentpro(xpath, 15)) {
			passed("verify account in lnkPortfolio_Summary","verify account should not present","verify account is not present");	
		} else {
			failed("verify account in lnkPortfolio_Summary","verify account should not present","verify account is present");
		}
		uiDriver.checkElementPresent("Verfify_AccountAdded.lnkAccount_Summary", 15000);
		uiDriver.javascriptClick("Verfify_AccountAdded.lnkAccount_Summary");
		
		//5. Verify Input innertext for Page WebElement
		List<String> list= uiDriver.getDropDownOptions("Verfify_AccountAdded.eltPage2");
		if(uiDriver.CheckTextInOption(list,input.get("Verify@Page#2"))){
			passed("verify account in lnkAccount_Summary","verify account should not present","verify account is not present");	
		}
		else{
			
			failed("verify account in lnkAccount_Summary","verify account should not present","verify account is present");	
		}
		
		//6. Click on Fixed_Income Link
		uiDriver.checkElementPresent("Verfify_AccountAdded.lnkFixed_Income", 15000);
		uiDriver.javascriptClick("Verfify_AccountAdded.lnkFixed_Income");
		
		//7. Verify Input innertext for Page WebElement
		List<String> list3= uiDriver.getDropDownOptions("Verfify_AccountAdded.eltPage3");
		if(uiDriver.CheckTextInOption(list3,input.get("Verify@Page#3"))){
			passed("verify account in lnkFixed_Income","verify account should not present","verify account is not present");
		}
		else{
			failed("verify account in lnkFixed_Income","verify account should not present","verify account is present");	
		}
		
		//8. Click on Realized_gain_loss Link
		uiDriver.checkElementPresent("Verfify_AccountAdded.lnkRealized_gain_loss",15000);
		uiDriver.javascriptClick("Verfify_AccountAdded.lnkRealized_gain_loss");
		
		List<String> list4= uiDriver.getDropDownOptions("Verfify_AccountAdded.eltPage4");
		if(uiDriver.CheckTextInOption(list4,input.get("Verify@Page#4"))){
			passed("verify account in lnkRealized_gain_loss","verify account should not present","verify account is not present");	
		}
		else{
			
			failed("verify account in lnkRealized_gain_loss","verify account should not present","verify account is present");	
		}
		
		//10. Click on Income_Summary Link
		uiDriver.checkElementPresent("Verfify_AccountAdded.lnkIncome_Summary",15000);
		uiDriver.javascriptClick("Verfify_AccountAdded.lnkIncome_Summary");
		
		//11. Verify Input innertext for Page WebElement
		List<String> list5= uiDriver.getDropDownOptions("Verfify_AccountAdded.eltPage5");
		if(uiDriver.CheckTextInOption(list5,input.get("Verify@Page#5"))){
			passed("verify account in lnkIncome_Summary","verify account should not present","verify account is not present");	
		}
		else{
			
			failed("verify account in lnkIncome_Summary","verify account should not present","verify account is present");	
		}
		
		//12. Click on Open_Orders Link
		uiDriver.checkElementPresent("Verfify_AccountAdded.lnkOpen_Orders",15000);
		uiDriver.javascriptClick("Verfify_AccountAdded.lnkOpen_Orders");
		
		//13. Verify Input innertext for Page WebElement
		//uiDriver.checkElementPresent("Verfify_AccountAdded.eltPage6",15000);
		List<String> list6= uiDriver.getDropDownOptions("Verfify_AccountAdded.eltPage6");
		if(uiDriver.CheckTextInOption(list6,input.get("Verify@Page#6"))){
			passed("verify account in lnkOpen_Orders","verify account should not present","verify account is not present");	
		}
		else{
			failed("verify account in lnkOpen_Orders","verify account should not present","verify account is present");
		}
		
		//14. Click on Trasaction_Detail Link
		uiDriver.checkElementPresent("Verfify_AccountAdded.lnkTrasaction_Detail",15000);
		uiDriver.javascriptClick("Verfify_AccountAdded.lnkTrasaction_Detail");
		
		//15. Verify Input innertext for Page WebElement
		uiDriver.checkElementPresent("Verfify_AccountAdded.eltPage7",15000);
		List<String> list7= uiDriver.getDropDownOptions("Verfify_AccountAdded.eltPage7");
		if(uiDriver.CheckTextInOption(list7,input.get("Verify@Page#7"))){
			passed("verify account in lnkOpen_Orders","verify account should not present","verify account is not present");	
		}
		else{
			failed("verify account in lnkOpen_Orders","verify account should not present","verify account is present");
		}
		
		//16. Click on Online_Documents Link
		uiDriver.checkElementPresent("Verfify_AccountAdded.lnkOnline_Documents",15000);
		uiDriver.javascriptClick("Verfify_AccountAdded.lnkOnline_Documents");
		
		//17. Verify Input innertext for Page WebElement
		uiDriver.checkElementPresent("Verfify_AccountAdded.eltPage8",15000);
		List<String> list8= uiDriver.getDropDownOptions("Verfify_AccountAdded.eltPage8");
		if(uiDriver.CheckTextInOption(list8,input.get("Verify@Page#8"))){
			passed("verify account in lnkOnline_Documents","verify account should not present","verify account is not present");	
		}
		else{
			failed("verify account in lnkOnline_Documents","verify account should not present","verify account is present");
		}
	
		//18. Click on Add_accounts Link
		uiDriver.checkElementPresent("Verfify_AccountAdded.lnkAdd_accounts",15000);
		uiDriver.javascriptClick("Verfify_AccountAdded.lnkAdd_accounts");
		
		//19. Verify Input innertext for Page WebElement
		String xpath2= uiDriver.getLocator("Verfify_AccountAdded.eltPage9");
		xpath= xpath2.replace("ChkBoxText", input.get("Verify@Page#9"));
		//3. Verify Input innertext for Page WebElement
		if (uiDriver.checkElementPresentpro(xpath, 15)) {
			passed("verify account in lnkAdd_accounts","verify account should not present","verify account is not present");
			
		} else {
			failed("verify account in lnkAdd_accounts","verify account should not present","verify account is present");
		}
		//20. Click on Remove_accounts Link
		uiDriver.checkElementPresent("Verfify_AccountAdded.lnkRemove_accounts",15000);
		uiDriver.javascriptClick("Verfify_AccountAdded.lnkRemove_accounts");
		
		//21. Verify Input innertext for Page WebElement
		String xpath3= uiDriver.getLocator("Verfify_AccountAdded.eltPage10");
		xpath= xpath3.replace("ChkBoxText", input.get("Verify@Page#10"));
		//3. Verify Input innertext for Page WebElement
		if (uiDriver.checkElementPresentpro(xpath, 15)) {
			passed("verify account in lnkRemove_accounts","verify account should not present","verify account is not present");
			
		} else {
			failed("verify account in lnkRemove_accounts","verify account should not present","verify account is present");
		}
		
		//22. Click on Change_account_label Link
		uiDriver.checkElementPresent("Verfify_AccountAdded.lnkChange_account_label",15000);
		uiDriver.javascriptClick("Verfify_AccountAdded.lnkChange_account_label");
		
		//23. Verify Input innertext for Page WebElement
		String xpath4= uiDriver.getLocator("Verfify_AccountAdded.eltPage11");
		
		xpath= xpath4.replace("ChkBoxText", input.get("Verify@Page#11"));
		if (uiDriver.checkElementPresentpro(xpath, 15)) {
			passed("verify account in lnkChange_account_label","verify account should not present","verify account is not present");
		} else {
			failed("verify account in lnkChange_account_label","verify account should not present","verify account is present");
			
		}
		
	}
	
	
	public void TransactionDetail(DataRow input, DataRow output) throws InterruptedException {
		//1. checkElementPresent("TransactionDetail.lnkAccount_Summary", 15000)
		
		//uiDriver.wait(5000);
		uiDriver.IsDisplayed_boolean("TransactionDetail.lnkAccount_Summary", 30);
		uiDriver.checkElementPresentpro("TransactionDetail.lnkAccount_Summary", 20);
		
		//2. click("TransactionDetail.lnkAccount_Summary")
		
		uiDriver.javascriptClick("TransactionDetail.lnkAccount_Summary");
		
		//3. Verify("TransactionDetail.eltAccountDetailDisplayed", input.get("Verify@AccountDetailDisplayed"))
		uiDriver.Application_sync();
		uiDriver.checkElementPresentpro("TransactionDetail.eltAccountDetailDisplayed", 50);
		 String ActDetail= uiDriver.getControl("TransactionDetail.eltAccountDetailDisplayed").getText();
		 if(ActDetail.equalsIgnoreCase(input.get("Verify@AccountDetailDisplayed"))){
				passed("Verify AccountDetailDisplayed ","Verify Account Detail should Displayed","Verify Account Detail Displayed");
			} else {
				failed("Verify AccountDetailDisplayed ","Verify Account Detail should Displayed","Verify Account Detail is not Displayed");
		}
		//4. click("TransactionDetail.lnkTrasaction_Detail")
		 
		uiDriver.checkElementPresentpro("TransactionDetail.lnkTrasaction_Detail", 50);
		uiDriver.javascriptClick("TransactionDetail.lnkTrasaction_Detail");
		uiDriver.AppSync();
		//5. Verify("TransactionDetail.eltTrasactionDetailDisplayed", input.get("Verify@TrasactionDetailDisplayed"))
		uiDriver.checkElementPresentpro("TransactionDetail.eltTrasactionDetailDisplayed", 50);
		 String TransDetail= uiDriver.getControl("TransactionDetail.eltTrasactionDetailDisplayed").getText();
		 System.out.println(TransDetail);
		 if(TransDetail.equalsIgnoreCase(input.get("Verify@TrasactionDetailDisplayed"))){
				passed("Verify TrasactionDetailDisplayed ","Verify Trasaction Detail should Displayed","Verify Trasaction Detail Displayed");
			} else {
				failed("Verify TrasactionDetailDisplayed ","Verify Trasaction Detail should Displayed","Verify Trasaction Detail is not Displayed");
		}
		 
		 uiDriver.checkElementPresentpro("TransactionDetail.lnkBreadCrum", 15);
		 String BreadCrum= uiDriver.getControl("TransactionDetail.lnkBreadCrum").getText();
		 if(BreadCrum.equalsIgnoreCase(input.get("Verify@BreadCrum"))){
				passed("Verify lnkBreadCrum ","Verify lnkBreadCrum should Displayed","Verify lnkBreadCrum Displayed");
			} else {
				failed("Verify lnkBreadCrum ","Verify lnkBreadCrum should Displayed","Verify lnkBreadCrum is not Displayed");
		 }
		 
		 
		//6. setValue("TransactionDetail.lstTransaction_Type", input.get("Select@Transaction_Type"))
		 if(!(input.get("Select@Transaction_Type").equals("NA"))){
				uiDriver.checkElementPresentpro("TransactionDetail.lstTransaction_Type", 15);
				uiDriver.setValue("TransactionDetail.lstTransaction_Type", input.get("Select@Transaction_Type"));	 
		 }
		//7. click("TransactionDetail.rdgDate_Range")		 
		 if(!(input.get("Select@rdgDate_Range").equals("NA")))
		 {
			String Month_defined="";
			String define1=input.get("Select@rdgDate_Range").trim();
			
			if(define1.equals("Defined")){
				Month_defined="D";
			}
			if(define1.equals("Custom")){
				Month_defined="C";
			}
			String define = uiDriver.getLocator("TransactionDetail.rdgDate_Range");
			define = define.replace("ChkBoxText", Month_defined);	
			System.out.println(define);
			uiDriver.getWebElement(define).click();
		 }
		 
		
		
		//8. setValue("TransactionDetail.lstDefined", input.get("Select@Defined"))
		
		if(!(input.get("Select@Defined").equals("NA"))){
			uiDriver.checkElementPresentpro("TransactionDetail.lstDefined", 15);
			uiDriver.setValue("TransactionDetail.lstDefined", input.get("Select@Defined"));	 
		}
	
		//9. setValue("TransactionDetail.lstF_MMM", input.get("Select@F_MMM"))
		if(!(input.get("Select@F_MMM").equals("NA"))){
			uiDriver.checkElementPresentpro("TransactionDetail.lstF_MMM", 15);
			uiDriver.setValue("TransactionDetail.lstF_MMM", input.get("Select@F_MMM")); 
		}
		
		
		//10. setValue("TransactionDetail.edtF_DD", input.get("type@F_DD"))
		if(!(input.get("type@F_DD").equals("NA"))){
			uiDriver.checkElementPresentpro("TransactionDetail.edtF_DD", 15);
			uiDriver.setValue("TransactionDetail.edtF_DD", input.get("type@F_DD")); 
		}
		
		
		//11. setValue("TransactionDetail.edtF_YYYY", input.get("type@F_YYYY"))
		if(!(input.get("type@F_YYYY").equals("NA"))){
		uiDriver.checkElementPresentpro("TransactionDetail.edtF_YYYY", 15);
		uiDriver.setValue("TransactionDetail.edtF_YYYY", input.get("type@F_YYYY"));
		}
		
		//12. setValue("TransactionDetail.lstT_MMM", input.get("Select@T_MMM"))
		if(!(input.get("Select@T_MMM").equals("NA"))){
			uiDriver.checkElementPresentpro("TransactionDetail.lstT_MMM", 15);
			uiDriver.setValue("TransactionDetail.lstT_MMM", input.get("Select@T_MMM"));
		}
		
		//13. setValue("TransactionDetail.edtT_DD", input.get("type@T_DD"))
		if(!(input.get("type@T_DD").equals("NA"))){
			uiDriver.checkElementPresentpro("TransactionDetail.edtT_DD", 15);
			uiDriver.setValue("TransactionDetail.edtT_DD", input.get("type@T_DD"));
		}
		
		
		//14. setValue("TransactionDetail.edtT_YYYY", input.get("type@T_YYYY"))
		if(!(input.get("type@T_YYYY").equals("NA"))){
			uiDriver.checkElementPresentpro("TransactionDetail.edtT_YYYY", 15);
			uiDriver.setValue("TransactionDetail.edtT_YYYY", input.get("type@T_YYYY"));
		}
		
		//15. setValue("TransactionDetail.lstSelect_Account", input.get("Select@Select_Account"))
		if(!(input.get("Select@Select_Account").equals("NA"))){
			uiDriver.checkElementPresentpro("TransactionDetail.lstSelect_Account", 15);
			uiDriver.setValue("TransactionDetail.lstSelect_Account", input.get("Select@Select_Account"));	 
		 }

		
		//18. Verify("TransactionDetail.eltVerifyMsg", input.get("Verify@VerifyMsg"))
		 uiDriver.checkElementPresentpro("TransactionDetail.eltVerifyMsg", 15);
		 String TextAboveView= uiDriver.getControl("TransactionDetail.eltVerifyMsg").getText();
		 System.out.println(TextAboveView);
		 if(TextAboveView.equalsIgnoreCase(input.get("Verify@VerifyMsg"))){
			 passed("eltVerifyMsg","eltVerifyMsg should present","eltVerifyMsg present");
			} else {
				failed("eltVerifyMsg","eltVerifyMsg should present","eltVerifyMsg present");
			 }
	}
	
	public void TD_Defined(DataRow input, DataRow output) {
		//1. checkElementPresent("TD_Defined.btnView", 15000
		uiDriver.Sync("TD_Defined.btnView");
		uiDriver.IsDisplayed_boolean("TD_Defined.btnView", 15);
		uiDriver.checkElementPresentpro("TD_Defined.btnView", 15);
		
		//2. click("TD_Defined.btnView")
		uiDriver.javascriptClick("TD_Defined.btnView");
		
		//3. Verify("TD_Defined.eltpge_afterview", input.get("Verify@pge_afterview"))

		uiDriver.checkElementPresentpro("TD_Defined.eltpge_afterview", 15);
		

		String TextAboveView= uiDriver.getControl("TD_Defined.eltpge_afterview").getText();
		 System.out.println(TextAboveView);
		 
		 if(TextAboveView.equalsIgnoreCase(input.get("Verify@pge_afterview"))){
			 passed("eltVerifyMsg","eltVerifyMsg should present","eltVerifyMsg present");
			} else {
				failed("eltVerifyMsg","eltVerifyMsg should present","eltVerifyMsg not present");
			 }
	}
	
	public void Checks(DataRow input, DataRow output) {
		
		//1. setValue("Checks.lstSelected_from_date", input.get("Select@Selected_from_date"))
		//uiDriver.wait(5000);
				 String Check_header=null;
		uiDriver.checkElementPresentpro("Checks.lstSelected_from_date", 150);
		String check_date= uiDriver.getControl("Checks.lstSelected_from_date").getText();
		 System.out.println(check_date);
		 if(check_date.equalsIgnoreCase(input.get("Verify@Selected_from_date"))){
			 passed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date present");
			} else {
				failed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date not present");
			 }
		 //2. Verify for selected account
		 uiDriver.checkElementPresentpro("Checks.LblSelected_Account", 15);
			String check_account= uiDriver.getControl("Checks.LblSelected_Account").getText();
			 System.out.println(check_account);
			 if(check_account.contains(input.get("Verify@Selected_Account"))){
				 passed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account present");
				} else {
					failed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account not present");
		}
		
		
		//3. Verify("Checks.lstTD_Description_Less", input.get("Verify@TD_Description_Less"))
		String check_Description= uiDriver.getControl("Checks.lstTD_Description_Less").getText();
		System.out.println(check_Description);
		if (check_Description.equalsIgnoreCase(input.get("Verify@TD_Description_Less"))) {
			passed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less present");
		} else {
			failed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less not present");
		}
		
		//4. Verify("Checks.tblColumn_Grid", input.get("Verify@Column_Grid"))
		 if(uiDriver.checkIfElementPresent("Checks.tblColumn_Grid", 10))
			{
			 Check_header = uiDriver.getLocator("Checks.tblColumn_Grid");
			}else{
				Check_header = uiDriver.getLocator("Checks.tblColumn_GridNoData");
			}
		 
				
		for(int i=1;i<=6;i++){
		
			String Check_headers = Check_header+i+"]";	
			System.out.println(Check_headers);
			String text= uiDriver.getWebElement(Check_headers).getText();
			System.out.println(text);
		if(i==1){
			if(text.equals(input.get("Verify@Column_Check_number"))){
				passed("verify check number","verify check number should present","verify check number present");
		} else {
				failed("verify check number","verify check number should present","verify check number not present");
		}
		}
		if(i==2){
			if(text.equals(input.get("Verify@Column_Data_written"))){
				passed("verify Column_Data_written","verify Column_Data_written should present","verify Column_Data_written present");
		} else {
				failed("verify Column_Data_written","verify Column_Data_written should present","verify Column_Data_written not present");
		}
		}
		if(i==3){
			if(text.equals(input.get("Verify@Column_data_cleared"))){
				passed("verify Column_data_cleared","verify Column_data_cleared should present","verify Column_data_cleared  present");
		} else {
				failed("verify Column_data_cleared","verify Column_data_cleared should present","verify Column_data_cleared not present");
		}
		}
		if(i==4){
			if(text.equals(input.get("Verify@Column_Expense_category"))){
				passed("verify Column_Expense_category","verify Column_Expense_category should present","verify present");
		} else {
				failed("verify Column_Expense_category","verify Column_Expense_category should present","verify not present");
		}
		}
		if(i==5){
			if(text.equals(input.get("Verify@Column_Payee"))){
				passed("verify Column_Payee","verify Column_Payee should present","verify Column_Payee present");
		} else {
				failed("verify Column_Payee","verify Column_Payee should present","verify Column_Payee not present");
		}
		}
		if(i==6){
			if(text.equals(input.get("Verify@Column_amount"))){
				passed("verify Column_amount","verify Column_amount should present","verify present");
		} else {
				failed("verify Column_amount","verify Column_amount should present","verify not present");
		}
		}
		}
		
		//5. setValue("Checks.lstTD_Description", input.get("Select@TD_Description"))
		//uiDriver.checkElementPresentpro("Checks.lstTD_Description", 15);
		//uiDriver.setValue("Checks.lstTD_Description", input.get("Select@TD_Description"));
	
		//6. click("Checks.imgTD_Checks_PDF")
		uiDriver.checkElementPresentpro("Checks.imgTD_Checks_PDF", 15);
		//uiDriver.click("Checks.imgTD_Checks_PDF");
		
		//uiDriver.closeWindow(2);
		
    	
		RetriveColumndataandSort("Checks.tblTableColumns","Checks.tblData");
		
	}
	public void CashDeposits_and_Withdrawals(DataRow input, DataRow output) {
		//1. setValue("CashDeposits_and_Withdrawals.lstSelected_from_Date", input.get("Select@Selected_from_Date"))
		
		uiDriver.checkElementPresentpro("CashDeposits_and_Withdrawals.lstSelected_from_date", 150);
		String check_date= uiDriver.getControl("CashDeposits_and_Withdrawals.lstSelected_from_date").getText();
		System.out.println(check_date);
		if(check_date.equalsIgnoreCase(input.get("Verify@Selected_from_Date"))){
			 passed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date present");
			} else {
				failed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date not present");
			 }
		//2. Verify for selected account
		 uiDriver.checkElementPresentpro("CashDeposits_and_Withdrawals.LblSelected_Account", 15);
			String check_account= uiDriver.getControl("CashDeposits_and_Withdrawals.LblSelected_Account").getText();
			 System.out.println(check_account);
			 if(check_account.contains(input.get("Verify@Selected_Account"))){
				 passed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account present");
				} else {
					failed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account not present");
		}
		
		//3. Verify("Checks.lstTD_Description_Less", input.get("Verify@TD_Description_Less"))
			String check_Description= uiDriver.getControl("CashDeposits_and_Withdrawals.lstTD_Description_Less").getText();
			System.out.println(check_Description);
			if (check_Description.equalsIgnoreCase(input.get("Verify@TD_Description_Less"))) {
					passed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less present");
			} else {
					failed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less not present");
			}
		
		//4. Verify("CashDeposits_and_Withdrawals.tblColumn_Grid", input.get("Verify@Column_Grid"))
			for(int i=1;i<=4;i++){
				String Check_header = uiDriver.getLocator("CashDeposits_and_Withdrawals.tblColumn_Grid");
				Check_header = Check_header+i+"]";	
				System.out.println(Check_header);
				String text= uiDriver.getWebElement(Check_header).getText();
				System.out.println(text);
				if(i==1){
					if(text.equals(input.get("Verify@Column_Date"))){
						passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
				} else {
						failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
				}
				}
				if(i==2){
					if(text.equals(input.get("Verify@Column_Activity_Type"))){
						passed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type present");
				} else {
						failed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type not present");
				}
				}
				if(i==3){
					if(text.equals(input.get("Verify@Column_Description"))){
						passed("verify Column_Description","verify Column_Description should present","verify Column_Description  present");
				} else {
						failed("verify Column_Description","verify Column_Description should present","verify Column_Description not present");
				}
				}
				if(i==4){
					if(text.equals(input.get("Verify@Column_Amount"))){
						passed("verify Column_Amount","verify Column_Amount should present","verify present");
				} else {
						failed("verify Column_Amount","verify Column_Amount should present","verify not present");
				}
				}
				}
			uiDriver.checkElementPresentpro("CashDeposits_and_Withdrawals.lstSelected_from_date", 150);
			RetriveColumndataandSort("CashDeposits_and_Withdrawals.tblTableColumns","CashDeposits_and_Withdrawals.tblData");
		
	}
	

	public void Money_Market_Activity(DataRow input, DataRow output) {
		//1. setValue("Money_Market_Activity.lstGiven_from_date", input.get("Select@Given_from_date"))
		//1. setValue("CashDeposits_and_Withdrawals.lstSelected_from_Date", input.get("Select@Selected_from_Date"))
								uiDriver.checkElementPresentpro("Money_Market_Activity.lstSelected_from_date", 150);
				String check_date= uiDriver.getControl("Money_Market_Activity.lstSelected_from_date").getText();
				System.out.println(check_date);
				if(check_date.equalsIgnoreCase(input.get("Verify@Selected_from_Date"))){
					 passed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date present");
					} else {
						failed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date not present");
					 }
				//2. Verify for selected account
				 uiDriver.checkElementPresentpro("Money_Market_Activity.LblSelected_Account", 15);
					String check_account= uiDriver.getControl("Money_Market_Activity.LblSelected_Account").getText();
					 System.out.println(check_account);
					 if(check_account.contains(input.get("Verify@Selected_Account"))){
						 passed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account present");
						} else {
							failed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account not present");
				}
				
				//3. Verify("Checks.lstTD_Description_Less", input.get("Verify@TD_Description_Less"))
					String check_Description= uiDriver.getControl("Money_Market_Activity.lstTD_Description_Less").getText();
					System.out.println(check_Description);
					if (check_Description.equalsIgnoreCase(input.get("Verify@TD_Description_Less"))) {
							passed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less present");
					} else {
							failed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less not present");
					}
				
				//4. Verify("CashDeposits_and_Withdrawals.tblColumn_Grid", input.get("Verify@Column_Grid"))
					for(int i=1;i<=6;i++){
						String Check_header = uiDriver.getLocator("Money_Market_Activity.tblColumn_Grid");
						Check_header = Check_header+i+"]";	
						System.out.println(Check_header);
						String text= uiDriver.getWebElement(Check_header).getText();
						System.out.println(text);
						if(i==1){
							if(text.equals(input.get("Verify@Column_Date"))){
								passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
						} else {
								failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
						}
						}
						if(i==2){
							if(text.equals(input.get("Verify@Column_Activity_Type"))){
								passed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type present");
						} else {
								failed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type not present");
						}
						}
						if(i==3)
						{
							if(text.equals(input.get("Verify@Column_Symbol"))){
								passed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol  present");
						} else {
								failed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol not present");
						}
						}
						if(i==4){
							if(text.equals(input.get("Verify@Column_Description"))){
								passed("verify Column_Description","verify Column_Description should present","verify Column_Description  present");
						} else {
								failed("verify Column_Description","verify Column_Description should present","verify Column_Description not present");
						}
						}
						if(i==5){
							if(text.equals(input.get("Verify@Column_Quantity"))){
								passed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity present");
						} else {
								failed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity not present");
						}
						}
						
						if(i==6){
							if(text.equals(input.get("Verify@Column_Amount"))){
								passed("verify Column_Amount","verify Column_Amount should present","verify Column_Amount present");
						} else {
								failed("verify Column_Amount","verify Column_Amount should present","verify  Column_Amount not present");
						}
						}
						}
					RetriveColumndataandSort("Money_Market_Activity.tblTableColumns","Money_Market_Activity.tblData");	
					if(!input.get("Click@Symbol").equals(""))
					{
						
					String link=uiDriver.getLocator("Money_Market_Activity.eltIDCSymbol");
					
					String link2=link.replace("link", input.get("Click@Symbol"));
					uiDriver.ClickXpath(link2+"/../img");
					//System.out.println(uiDriver.getAttribute("AllTransactionsByDate.linkPopUp", "href"));
					uiDriver.checkElementPresentpro("Money_Market_Activity.linkPopUp", 30);
					uiDriver.sendKeysEnter("Money_Market_Activity.linkPopUp");
					int cp=uiDriver.NoOfWindows();
			 		System.out.println(cp);
			 		String parentwindow= uiDriver.getWindowHandle();
					uiDriver.switchToWindowByID(parentwindow);
			 		//12. Verify("AllTransactionsByDate.elttitle", input.get("Verify@title"))
					/*String MarketInfo=uiDriver.getControl("Money_Market_Activity.lblMarketInfo").getText().trim();
					if (MarketInfo.equals(input.get("Verify@MarketInfo").trim())) {
						passed("Verify MarketInfo","Verify MarketInfo should Present","Verify  MarketInfo Present");
					} else {	
						failed("Verify MarketInfo","Verify MarketInfo should Present","Verify MarketInfo not Present");
					}*/
					uiDriver.switchToWindowParentWindow(parentwindow);
					}
		}
		
	public void Purchases_and_Sales(DataRow input, DataRow output) {
		
		uiDriver.checkElementPresentpro("Purchases_and_Sales.lstSelected_from_date", 150);
		String check_date= uiDriver.getControl("Purchases_and_Sales.lstSelected_from_date").getText();
		System.out.println(check_date);
		if(check_date.equalsIgnoreCase(input.get("Verify@Selected_from_Date"))){
			 passed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date present");
			} else {
				failed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date not present");
			 }
		//2. Verify for selected account
		 uiDriver.checkElementPresentpro("Purchases_and_Sales.LblSelected_Account", 15);
			String check_account= uiDriver.getControl("Purchases_and_Sales.LblSelected_Account").getText();
			 System.out.println(check_account);
			 if(check_account.contains(input.get("Verify@Selected_Account"))){
				 passed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account present");
				} else {
					failed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account not present");
		}
		
		//3. Verify("Checks.lstTD_Description_Less", input.get("Verify@TD_Description_Less"))
			String check_Description= uiDriver.getControl("Purchases_and_Sales.lstTD_Description_Less").getText();
			System.out.println(check_Description);
			if (check_Description.equalsIgnoreCase(input.get("Verify@TD_Description_Less"))) {
					passed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less present");
			} else {
					failed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less not present");
			}
		
		//4. Verify("CashDeposits_and_Withdrawals.tblColumn_Grid", input.get("Verify@Column_Grid"))
			for(int i=1;i<=7;i++){
				String Check_header = uiDriver.getLocator("Purchases_and_Sales.tblColumn_Grid");
				Check_header = Check_header+i+"]";	
				System.out.println(Check_header);
				String text= uiDriver.getWebElement(Check_header).getText();
				System.out.println(text);
				if(i==1){
					if(text.equals(input.get("Verify@Column_Date"))){
						passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
				} else {
						failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
				}
				}
				if(i==2){
					if(text.equals(input.get("Verify@Column_Activity_Type"))){
						passed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type present");
				} else {
						failed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type not present");
				}
				}
				if(i==3)
				{
					if(text.equals(input.get("Verify@Column_Symbol"))){
						passed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol  present");
				} else {
						failed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol not present");
				}
				}
				if(i==4){
					if(text.equals(input.get("Verify@Column_Description"))){
						passed("verify Column_Description","verify Column_Description should present","verify Column_Description  present");
				} else {
						failed("verify Column_Description","verify Column_Description should present","verify Column_Description not present");
				}
				}
				if(i==5){
					if(text.equals(input.get("Verify@Column_Quantity"))){
						passed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity present");
				} else {
						failed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity not present");
				}
				}
				if(i==6){
					if(text.equals(input.get("Verify@Column_Price"))){
						passed("verify Column_Price","verify Column_Price should present","verify Column_Price present");
				} else {
						failed("verify Column_Price","verify Column_Price should present","verify  Column_Price not present");
				}
				}
				if(i==7){
					if(text.equals(input.get("Verify@Column_NetAmount"))){
						passed("verify Column_Amount","verify Column_Amount should present","verify Column_Amount present");
				} else {
						failed("verify Column_Amount","verify Column_Amount should present","verify  Column_Amount not present");
				}
				}
				}
		RetriveColumndataandSort("Purchases_and_Sales.tblTableColumns","Purchases_and_Sales.tblData");
	
			
		//7. click("AllTransactionsByDate.btnIDCSymbol")
		if(!input.get("Click@Symbol").equals("NA"))
		{
			
			String link=uiDriver.getLocator("Purchases_and_Sales.eltIDCSymbol");
		
		String link2=link.replace("link", input.get("Click@Symbol"));
		uiDriver.ClickXpath(link2+"/../img");
		//System.out.println(uiDriver.getAttribute("AllTransactionsByDate.linkPopUp", "href"));
		uiDriver.checkElementPresentpro("Purchases_and_Sales.linkPopUp", 30);
		uiDriver.sendKeysEnter("Purchases_and_Sales.linkPopUp");
		int cp=uiDriver.NoOfWindows();
 		System.out.println(cp);
 		String parentwindow= uiDriver.getWindowHandle();
		uiDriver.switchToWindowByID(parentwindow);
 		//12. Verify("AllTransactionsByDate.elttitle", input.get("Verify@title"))
		/*String MarketInfo=uiDriver.getControl("Purchases_and_Sales.lblMarketInfo").getText().trim();
		if (MarketInfo.equals(input.get("Verify@MarketInfo").trim())) {
			passed("Verify MarketInfo","Verify MarketInfo should Present","Verify  MarketInfo Present");
		} else {	
			failed("Verify MarketInfo","Verify MarketInfo should Present","Verify MarketInfo not Present");
		}*/
		uiDriver.switchToWindowParentWindow(parentwindow);
		}
		
		
	}
	public void VisaPlatinum_DebitCard_Cleared(DataRow input, DataRow output) {
		uiDriver.ApplicationSync1();
		String Check_header = null;
		uiDriver.checkElementPresentpro("VisaPlatinum_DebitCard_Cleared.lstSelected_from_date", 15);
		String check_date= uiDriver.getControl("VisaPlatinum_DebitCard_Cleared.lstSelected_from_date").getText();
		System.out.println(check_date);
		if(check_date.equalsIgnoreCase(input.get("Verify@Selected_from_Date"))){
			 passed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date present");
			} else {
				failed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date not present");
			 }
		//2. Verify for selected account
		 uiDriver.checkElementPresentpro("VisaPlatinum_DebitCard_Cleared.LblSelected_Account", 15);
			String check_account= uiDriver.getControl("VisaPlatinum_DebitCard_Cleared.LblSelected_Account").getText();
			 System.out.println(check_account);
			 if(check_account.contains(input.get("Verify@Selected_Account"))){
				 passed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account present");
				} else {
					failed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account not present");
		}
		
		//3. Verify("Checks.lstTD_Description_Less", input.get("Verify@TD_Description_Less"))
			String check_Description= uiDriver.getControl("VisaPlatinum_DebitCard_Cleared.lstTD_Description_Less").getText();
			System.out.println(check_Description);
			if (check_Description.equalsIgnoreCase(input.get("Verify@TD_Description_Less"))) {
					passed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less present");
			} else {
					failed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less not present");
			}
			
			if(uiDriver.checkIfElementPresent("VisaPlatinum_DebitCard_Cleared.tblDataRow", 10))
			{
				Check_header = uiDriver.getLocator("VisaPlatinum_DebitCard_Cleared.tblColumn_Grid");
			}else{
				Check_header = uiDriver.getLocator("VisaPlatinum_DebitCard_Cleared.tblColumn_GridNoData");
			}
			for(int i=1;i<=4;i++){
				String Check_headers = Check_header+i+"]";	
				System.out.println(Check_headers);
				String text= uiDriver.getWebElement(Check_headers).getText();
				System.out.println(text);
				if(i==1){
					if(text.equals(input.get("Verify@Column_DateCleared"))){
						passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
				} else {
						failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
				}
				}
				if(i==2){
					if(text.equals(input.get("Verify@Column_Date"))){
						passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
				} else {
						failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
				}
				}
				
				if(i==3){
					if(text.equals(input.get("Verify@Column_Description"))){
						passed("verify Column_Description","verify Column_Description should present","verify Column_Description  present");
				} else {
						failed("verify Column_Description","verify Column_Description should present","verify Column_Description not present");
				}
				}
				
				if(i==4){
					if(text.equals(input.get("Verify@Column_Amount"))){
						passed("verify Column_Amount","verify Column_Amount should present","verify Column_Amount present");
				} else {
						failed("verify Column_Amount","verify Column_Amount should present","verify  Column_Amount not present");
				}
				}
				}
			if(uiDriver.checkIfElementPresent("VisaPlatinum_DebitCard_Cleared.tblDataRow", 10))
			{
				RetriveColumndataandSort("VisaPlatinum_DebitCard_Cleared.tblTableColumns","VisaPlatinum_DebitCard_Cleared.tblData");
			}else{
				passed("verify No Data found for sorting","verify No Data should found for sorting","verify No Data found for sorting");
			}
	
			
	}
	

	public void VisaPlatinum_DebitCard_Pending(DataRow input, DataRow output) {
		uiDriver.ApplicationSync1();
		
		String Check_header = null;
		 if(!(input.get("Select@Transaction_Type").equals("NA"))){
				uiDriver.checkElementPresentpro("TransactionDetail.lstTransaction_Type", 15);
				uiDriver.setValue("TransactionDetail.lstTransaction_Type", input.get("Select@Transaction_Type"));	 
		 }
		//7. click("TransactionDetail.rdgDate_Range")		 
		 if(!(input.get("Select@rdgDate_Range").equals("NA")))
		 {
			String Month_defined="";
			String define1=input.get("Select@rdgDate_Range").trim();
			
			if(define1.equals("Defined")){
				Month_defined="D";
			}
			if(define1.equals("Custom")){
				Month_defined="C";
			}
			String define = uiDriver.getLocator("TransactionDetail.rdgDate_Range");
			define = define.replace("ChkBoxText", Month_defined);	
			System.out.println(define);
			uiDriver.getWebElement(define).click();
		 }
		 
		
		
		//8. setValue("TransactionDetail.lstDefined", input.get("Select@Defined"))
		
		if(!(input.get("Select@Defined").equals("NA"))){
			uiDriver.checkElementPresentpro("TransactionDetail.lstDefined", 15);
			uiDriver.setValue("TransactionDetail.lstDefined", input.get("Select@Defined"));	 
		}
		
		uiDriver.setValue("VisaPlatinum_DebitCard_Pending.lstSelect_Account", input.get("Select@Account"));
		
		uiDriver.checkElementPresentpro("VisaPlatinum_DebitCard_Pending.btnView", 10);
		uiDriver.javascriptClick("VisaPlatinum_DebitCard_Pending.btnView");
		uiDriver.checkElementPresentpro("VisaPlatinum_DebitCard_Pending.lstSelected_from_date", 15);
		String check_date= uiDriver.getControl("VisaPlatinum_DebitCard_Pending.lstSelected_from_date").getText();
		System.out.println(check_date);
		if(check_date.contains(input.get("Verify@Selected_from_Date"))){
			 passed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date present");
			} else {
				failed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date not present");
			 }
		uiDriver.checkElementPresentpro("VisaPlatinum_DebitCard_Pending.LblSelected_Account", 15);
		String check_account= uiDriver.getControl("VisaPlatinum_DebitCard_Pending.LblSelected_Account").getText();
		 System.out.println(check_account);
		 if(check_account.contains(input.get("Verify@Selected_Account"))){
			 passed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account present");
			} else {
				failed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account not present");
	
			}
		 
		 if(uiDriver.checkIfElementPresent("VisaPlatinum_DebitCard_Pending.tblDataRow", 10))
			{
				Check_header = uiDriver.getLocator("VisaPlatinum_DebitCard_Pending.tblColumn_Grid");
			}else{
				Check_header = uiDriver.getLocator("VisaPlatinum_DebitCard_Pending.tblColumn_GridNoData");
			}
		 
		 
		 for(int i=1;i<=4;i++){
				String Check_headers = Check_header+i+"]";	
				System.out.println(Check_headers);
				String text= uiDriver.getWebElement(Check_headers).getText();
				System.out.println(text);
				if(i==1){
					if(text.equals(input.get("Verify@Column_DateCleared"))){
						passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
				} else {
						failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
				}
				}
				if(i==2){
					if(text.equals(input.get("Verify@Column_Date"))){
						passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
				} else {
						failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
				}
				}
				
				if(i==3){
					if(text.equals(input.get("Verify@Column_Description"))){
						passed("verify Column_Description","verify Column_Description should present","verify Column_Description  present");
				} else {
						failed("verify Column_Description","verify Column_Description should present","verify Column_Description not present");
				}
				}
				
				if(i==4){
					if(text.equals(input.get("Verify@Column_Amount"))){
						passed("verify Column_Amount","verify Column_Amount should present","verify Column_Amount present");
				} else {
						failed("verify Column_Amount","verify Column_Amount should present","verify  Column_Amount not present");
				}
				}
				}
			if(uiDriver.checkIfElementPresent("VisaPlatinum_DebitCard_Pending.tblDataRow", 10))
			{
				RetriveColumndataandSort("VisaPlatinum_DebitCard_Pending.tblTableColumns","VisaPlatinum_DebitCard_Pending.tblData");
			}else{
				passed("verify No Data found for sorting","verify No Data should found for sorting","verify No Data found for sorting");
			}
	}
	
	public void Visa_Platinum_DebitCard_Both(DataRow input, DataRow output) {
		uiDriver.ApplicationSync1();
		
		String Check_header = null;
		 if(!(input.get("Select@Transaction_Type").equals("NA"))){
				uiDriver.checkElementPresentpro("TransactionDetail.lstTransaction_Type", 15);
				uiDriver.setValue("TransactionDetail.lstTransaction_Type", input.get("Select@Transaction_Type"));	 
		 }
		//7. click("TransactionDetail.rdgDate_Range")		 
		 if(!(input.get("Select@rdgDate_Range").equals("NA")))
		 {
			String Month_defined="";
			String define1=input.get("Select@rdgDate_Range").trim();
			
			if(define1.equals("Defined")){
				Month_defined="D";
			}
			if(define1.equals("Custom")){
				Month_defined="C";
			}
			String define = uiDriver.getLocator("TransactionDetail.rdgDate_Range");
			define = define.replace("ChkBoxText", Month_defined);	
			System.out.println(define);
			uiDriver.getWebElement(define).click();
		 }
		 
		
		
		//8. setValue("TransactionDetail.lstDefined", input.get("Select@Defined"))
		
		if(!(input.get("Select@Defined").equals("NA"))){
			uiDriver.checkElementPresentpro("TransactionDetail.lstDefined", 15);
			uiDriver.setValue("TransactionDetail.lstDefined", input.get("Select@Defined"));	 
		}
		
		uiDriver.setValue("Visa_Platinum_DebitCard_Both.lstSelect_Account", input.get("Select@Account"));
		
		uiDriver.checkElementPresentpro("Visa_Platinum_DebitCard_Both.btnView", 10);
		uiDriver.javascriptClick("Visa_Platinum_DebitCard_Both.btnView");
		uiDriver.checkElementPresentpro("Visa_Platinum_DebitCard_Both.lstSelected_from_date", 15);
		String check_date= uiDriver.getControl("Visa_Platinum_DebitCard_Both.lstSelected_from_date").getText();
		System.out.println(check_date);
		if(check_date.contains(input.get("Verify@Selected_from_Date"))){
			 passed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date present");
			} else {
				failed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date not present");
			 }
		uiDriver.checkElementPresentpro("Visa_Platinum_DebitCard_Both.LblSelected_Account", 15);
		String check_account= uiDriver.getControl("Visa_Platinum_DebitCard_Both.LblSelected_Account").getText();
		 System.out.println(check_account);
		 if(check_account.contains(input.get("Verify@Selected_Account"))){
			 passed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account present");
			} else {
				failed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account not present");
	
			}
		if(uiDriver.checkIfElementPresent("Visa_Platinum_DebitCard_Both.clearedExist", 30)){
			if(uiDriver.checkIfElementPresent("VisaPlatinum_DebitCard_Cleared.tblDataRow", 10))
			{
				Check_header = uiDriver.getLocator("VisaPlatinum_DebitCard_Cleared.tblColumn_Grid");
			}else{
				Check_header = uiDriver.getLocator("VisaPlatinum_DebitCard_Cleared.tblColumn_GridNoData");
			}
			for(int i=1;i<=4;i++){
				String Check_headers = Check_header+i+"]";	
				System.out.println(Check_headers);
				String text= uiDriver.getWebElement(Check_headers).getText();
				System.out.println(text);
				if(i==1){
					if(text.equals(input.get("Verify@Column_DateCleared"))){
						passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
				} else {
						failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
				}
				}
				if(i==2){
					if(text.equals(input.get("Verify@Column_Date"))){
						passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
				} else {
						failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
				}
				}
				
				if(i==3){
					if(text.equals(input.get("Verify@Column_Description"))){
						passed("verify Column_Description","verify Column_Description should present","verify Column_Description  present");
				} else {
						failed("verify Column_Description","verify Column_Description should present","verify Column_Description not present");
				}
				}
				
				if(i==4){
					if(text.equals(input.get("Verify@Column_Amount"))){
						passed("verify Column_Amount","verify Column_Amount should present","verify Column_Amount present");
				} else {
						failed("verify Column_Amount","verify Column_Amount should present","verify  Column_Amount not present");
				}
				}
				}
			if(uiDriver.checkIfElementPresent("VisaPlatinum_DebitCard_Cleared.tblDataRow", 10))
			{
				RetriveColumndataandSort("VisaPlatinum_DebitCard_Cleared.tblTableColumns","VisaPlatinum_DebitCard_Cleared.tblData");
			}else{
				passed("verify No Data found for sorting","verify No Data should found for sorting","verify No Data found for sorting");
			}	
		}else{
			passed("verify Cleared Cloumn is not Present","verify  Cleared Cloumn should  Present","verify Cleared Cloumn is not Present");
			
		}
		if(uiDriver.checkIfElementPresent("Visa_Platinum_DebitCard_Both.pendingExist", 30)){
			 if(uiDriver.checkIfElementPresent("VisaPlatinum_DebitCard_Pending.tblDataRow", 10))
				{
					Check_header = uiDriver.getLocator("VisaPlatinum_DebitCard_Pending.tblColumn_Grid");
				}else{
					Check_header = uiDriver.getLocator("VisaPlatinum_DebitCard_Pending.tblColumn_GridNoData");
				}
			 
			 
			 for(int i=1;i<=4;i++){
					String Check_headers = Check_header+i+"]";	
					System.out.println(Check_headers);
					String text= uiDriver.getWebElement(Check_headers).getText();
					System.out.println(text);
					if(i==1){
						if(text.equals(input.get("Verify@Column_DateCleared"))){
							passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
					} else {
							failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
					}
					}
					if(i==2){
						if(text.equals(input.get("Verify@Column_Date"))){
							passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
					} else {
							failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
					}
					}
					
					if(i==3){
						if(text.equals(input.get("Verify@Column_Description"))){
							passed("verify Column_Description","verify Column_Description should present","verify Column_Description  present");
					} else {
							failed("verify Column_Description","verify Column_Description should present","verify Column_Description not present");
					}
					}
					
					if(i==4){
						if(text.equals(input.get("Verify@Column_Amount"))){
							passed("verify Column_Amount","verify Column_Amount should present","verify Column_Amount present");
					} else {
							failed("verify Column_Amount","verify Column_Amount should present","verify  Column_Amount not present");
					}
					}
					}
				if(uiDriver.checkIfElementPresent("VisaPlatinum_DebitCard_Pending.tblDataRow", 10))
				{
					RetriveColumndataandSort("VisaPlatinum_DebitCard_Pending.tblTableColumns","VisaPlatinum_DebitCard_Pending.tblData");
				}else{
					passed("verify No Data found for sorting","verify No Data should found for sorting","verify No Data found for sorting");
				}
		}
		else{
			passed("verify Pending Cloumn is not Present","verify  Pending Cloumn should Present","verify Pending Cloumn is not Present");
			
		}
	}
	public void AllTransactionsByDate(DataRow input, DataRow output) throws AWTException {
		
		uiDriver.ApplicationSync1();
		uiDriver.checkElementPresentpro("AllTransactionsByDate.lstSelected_from_date", 150);
		String check_date= uiDriver.getControl("AllTransactionsByDate.lstSelected_from_date").getText();
		System.out.println(check_date);
		if(check_date.equalsIgnoreCase(input.get("Verify@Selected_from_Date"))){
			 passed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date present");
			} else {
				failed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date not present");
			 }
		//2. Verify for selected account
		 uiDriver.checkElementPresentpro("AllTransactionsByDate.LblSelected_Account", 15);
			String check_account= uiDriver.getControl("AllTransactionsByDate.LblSelected_Account").getText();
			 System.out.println(check_account);
			 if(check_account.contains(input.get("Verify@Selected_Account"))){
				 passed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account present");
				} else {
					failed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account not present");
		}
		
		//3. Verify("Checks.lstTD_Description_Less", input.get("Verify@TD_Description_Less"))
			String check_Description= uiDriver.getControl("AllTransactionsByDate.lstTD_Description_Less").getText();
			System.out.println(check_Description);
			if (check_Description.equalsIgnoreCase(input.get("Verify@TD_Description_Less"))) {
					passed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less present");
			} else {
					failed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less not present");
			}
		
		//4. Verify("CashDeposits_and_Withdrawals.tblColumn_Grid", input.get("Verify@Column_Grid"))
			for(int i=1;i<=7;i++){
				String Check_header = uiDriver.getLocator("AllTransactionsByDate.tblColumn_Grid");
				Check_header = Check_header+i+"]";	
				System.out.println(Check_header);
				String text= uiDriver.getWebElement(Check_header).getText();
				System.out.println(text);
				if(i==1){
					if(text.equals(input.get("Verify@Column_Date"))){
						passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
				} else {
						failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
				}
				}
				if(i==2){
					if(text.equals(input.get("Verify@Column_Activity_Type"))){
						passed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type present");
				} else {
						failed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type not present");
				}
				}
				if(i==3)
				{
					if(text.equals(input.get("Verify@Column_Symbol"))){
						passed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol  present");
				} else {
						failed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol not present");
				}
				}
				if(i==4){
					if(text.equals(input.get("Verify@Column_Description"))){
						passed("verify Column_Description","verify Column_Description should present","verify Column_Description  present");
				} else {
						failed("verify Column_Description","verify Column_Description should present","verify Column_Description not present");
				}
				}
				if(i==5){
					if(text.equals(input.get("Verify@Column_Quantity"))){
						passed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity present");
				} else {
						failed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity not present");
				}
				}
				if(i==6){
					if(text.equals(input.get("Verify@Column_Price"))){
						passed("verify Column_Price","verify Column_Price should present","verify Column_Price present");
				} else {
						failed("verify Column_Price","verify Column_Price should present","verify  Column_Price not present");
				}
				}
				if(i==7){
					if(text.equals(input.get("Verify@Column_Amount"))){
						passed("verify Column_Amount","verify Column_Amount should present","verify Column_Amount present");
				} else {
						failed("verify Column_Amount","verify Column_Amount should present","verify  Column_Amount not present");
				}
				}
				}
		RetriveColumndataandSort("AllTransactionsByDate.tblTableColumns","AllTransactionsByDate.tblData");
	
			
		//7. click("AllTransactionsByDate.btnIDCSymbol")
		if(!input.get("Click@Symbol").equals("NA"))
		{
			
			String link=uiDriver.getLocator("AllTransactionsByDate.eltIDCSymbol");
		
		String link2=link.replace("link", input.get("Click@Symbol"));
		uiDriver.ClickXpath(link2+"/../img");
		//System.out.println(uiDriver.getAttribute("AllTransactionsByDate.linkPopUp", "href"));
		uiDriver.sendKeysEnter ("AllTransactionsByDate.linkPopUp");
		
		/**
		uiDriver.wait(3000);//neccesary wait
 		Robot robot = new Robot();
 		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);	
		robot.keyPress(KeyEvent.VK_ENTER);	
 		robot.keyRelease(KeyEvent.VK_ENTER);
 		*/
 		int cp=uiDriver.NoOfWindows();
 		System.out.println(cp);
 		String parentwindow= uiDriver.getWindowHandle();
		uiDriver.switchToWindowByID(parentwindow);
 		//12. Verify("AllTransactionsByDate.elttitle", input.get("Verify@title"))
		String MarketInfo=uiDriver.getControl("AllTransactionsByDate.lblMarketInfo").getText().trim();
		if (MarketInfo.equals(input.get("Verify@MarketInfo").trim())) {
			passed("Verify MarketInfo","Verify MarketInfo should Present","Verify  MarketInfo Present");
		} else {	
			failed("Verify MarketInfo","Verify MarketInfo should Present","Verify MarketInfo not Present");
		}
		uiDriver.switchToWindowParentWindow(parentwindow);
		}
	
		
	}
	public void OtherTransactionDetails(DataRow input, DataRow output) {
		uiDriver.ApplicationSync1();
		uiDriver.checkElementPresentpro("OtherTransactionDetails.lstSelected_from_date", 150);
		String check_date= uiDriver.getControl("OtherTransactionDetails.lstSelected_from_date").getText();
		System.out.println(check_date);
		if(check_date.equalsIgnoreCase(input.get("Verify@Selected_from_Date"))){
			 passed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date present");
			} else {
				failed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date not present");
			 }
		
		//2. Verify for selected account
		 uiDriver.checkElementPresentpro("OtherTransactionDetails.LblSelected_Account", 15);
			String check_account= uiDriver.getControl("OtherTransactionDetails.LblSelected_Account").getText();
			 System.out.println(check_account);
			 if(check_account.contains(input.get("Verify@Selected_Account"))){
				 passed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account present");
				} else {
					failed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account not present");
		}
			//3. Verify("Checks.lstTD_Description_Less", input.get("Verify@TD_Description_Less"))
				String check_Description= uiDriver.getControl("OtherTransactionDetails.lstTD_Description_Less").getText();
				System.out.println(check_Description);
				if (check_Description.equalsIgnoreCase(input.get("Verify@TD_Description_Less"))) {
						passed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less present");
				} else {
						failed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less not present");
				}
				
				for(int i=1;i<=5;i++){
					String Check_header = uiDriver.getLocator("OtherTransactionDetails.tblColumn_Grid");
					Check_header = Check_header+i+"]";	
					System.out.println(Check_header);
					String text= uiDriver.getWebElement(Check_header).getText();
					System.out.println(text);
					if(i==1){
						if(text.equals(input.get("Verify@Column_Date"))){
							passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
					} else {
							failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
					}
					}
					if(i==2){
						if(text.equals(input.get("Verify@Column_Activity_Type"))){
							passed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type present");
					} else {
							failed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type not present");
					}
					}
					
					if(i==3){
						if(text.equals(input.get("Verify@Column_Description"))){
							passed("verify Column_Description","verify Column_Description should present","verify Column_Description  present");
					} else {
							failed("verify Column_Description","verify Column_Description should present","verify Column_Description not present");
					}
					}
					if(i==4){
						if(text.equals(input.get("Verify@Column_Quantity"))){
							passed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity present");
					} else {
							failed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity not present");
					}
					}
					
					if(i==5){
						if(text.equals(input.get("Verify@Column_Amount"))){
							passed("verify Column_Amount","verify Column_Amount should present","verify Column_Amount present");
					} else {
							failed("verify Column_Amount","verify Column_Amount should present","verify  Column_Amount not present");
					}
					}
					}
			RetriveColumndataandSort("OtherTransactionDetails.tblTableColumns","OtherTransactionDetails.tblData");
		
				
	}
	
	public void Security_Transactions_In_Out(DataRow input, DataRow output) {
		uiDriver.ApplicationSync1();
		uiDriver.checkElementPresentpro("Security_Transactions_In_Out.lstSelected_from_date", 150);
		String check_date= uiDriver.getControl("Security_Transactions_In_Out.lstSelected_from_date").getText();
		System.out.println(check_date);
		if(check_date.equalsIgnoreCase(input.get("Verify@Selected_from_Date"))){
			 passed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date present");
			} else {
				failed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date not present");
			 }
		
		//2. Verify for selected account
		 uiDriver.checkElementPresentpro("Security_Transactions_In_Out.LblSelected_Account", 15);
			String check_account= uiDriver.getControl("Security_Transactions_In_Out.LblSelected_Account").getText();
			 System.out.println(check_account);
			 if(check_account.contains(input.get("Verify@Selected_Account"))){
				 passed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account present");
				} else {
					failed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account not present");
		}
			//3. Verify("Checks.lstTD_Description_Less", input.get("Verify@TD_Description_Less"))
				String check_Description= uiDriver.getControl("Security_Transactions_In_Out.lstTD_Description_Less").getText();
				System.out.println(check_Description);
				if (check_Description.equalsIgnoreCase(input.get("Verify@TD_Description_Less"))) {
						passed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less present");
				} else {
						failed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less not present");
				}
				for(int i=1;i<=5;i++){
					String Check_header = uiDriver.getLocator("Security_Transactions_In_Out.tblColumn_Grid");
					Check_header = Check_header+i+"]";	
					System.out.println(Check_header);
					String text= uiDriver.getWebElement(Check_header).getText();
					System.out.println(text);
					if(i==1){
						if(text.equals(input.get("Verify@Column_Date"))){
							passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
					} else {
							failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
					}
					}
					if(i==2){
						if(text.equals(input.get("Verify@Column_Activity_Type"))){
							passed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type present");
					} else {
							failed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type not present");
					}
					}
					if(i==3)
					{
						if(text.equals(input.get("Verify@Column_Symbol"))){
							passed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol  present");
					} else {
							failed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol not present");
					}
					}
					if(i==4){
						if(text.equals(input.get("Verify@Column_Description"))){
							passed("verify Column_Description","verify Column_Description should present","verify Column_Description  present");
					} else {
							failed("verify Column_Description","verify Column_Description should present","verify Column_Description not present");
					}
					}
					if(i==5){
						if(text.equals(input.get("Verify@Column_Quantity"))){
							passed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity present");
					} else {
							failed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity not present");
					}
					}
					}
			RetriveColumndataandSort("Security_Transactions_In_Out.tblTableColumns","Security_Transactions_In_Out.tblData");
		
				
			//7. click("AllTransactionsByDate.btnIDCSymbol")
			if(!input.get("Click@Symbol").equals(""))
			{
				
				String link=uiDriver.getLocator("Security_Transactions_In_Out.eltIDCSymbol");
			
			String link2=link.replace("link", input.get("Click@Symbol"));
			System.out.println(link2);
			uiDriver.ClickXpath(link2+"/../img");
			//System.out.println(uiDriver.getAttribute("Security_Transactions_In_Out.linkPopUp", "href"));
			uiDriver.sendKeysEnter ("Security_Transactions_In_Out.linkPopUp");
			
	 		int cp=uiDriver.NoOfWindows();
	 		System.out.println(cp);
	 		String parentwindow= uiDriver.getWindowHandle();
			uiDriver.switchToWindowByID(parentwindow);
	 		//12. Verify("Security_Transactions_In_Out.elttitle", input.get("Verify@title"))
			
			/*String MarketInfo=uiDriver.getControl("Security_Transactions_In_Out.lblMarketInfo").getText().trim();
			if (MarketInfo.equals(input.get("Verify@MarketInfo").trim())) {
				passed("Verify MarketInfo","Verify MarketInfo should Present","Verify  MarketInfo Present");
			} else {	
				failed("Verify MarketInfo","Verify MarketInfo should Present","Verify MarketInfo not Present");
			}*/
			uiDriver.switchToWindowParentWindow(parentwindow);
			}
		
		
		
	}
	
	public void TaxExempt_Income(DataRow input, DataRow output) {
		uiDriver.ApplicationSync1();
		uiDriver.checkElementPresentpro("TaxExempt_Income.lstSelected_from_date", 150);
		String check_date= uiDriver.getControl("TaxExempt_Income.lstSelected_from_date").getText();
		System.out.println(check_date);
		if(check_date.equalsIgnoreCase(input.get("Verify@Selected_from_Date"))){
			 passed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date present");
			} else {
				failed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date not present");
			 }
		
		//2. Verify("TaxExempt_Income.tblTable_Grid_Message", input.get("Verify@Table_Grid_Message"))
		uiDriver.checkElementPresentpro("TaxExempt_Income.LblSelected_Account", 15);
		String check_account= uiDriver.getControl("TaxExempt_Income.LblSelected_Account").getText();
		 System.out.println(check_account);
		 if(check_account.contains(input.get("Verify@Selected_Account"))){
			 passed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account present");
			} else {
				failed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account not present");
	}
		//3. Verify("Checks.lstTD_Description_Less", input.get("Verify@TD_Description_Less"))
			String check_Description= uiDriver.getControl("TaxExempt_Income.lstTD_Description_Less").getText();
			System.out.println(check_Description);
			if (check_Description.equalsIgnoreCase(input.get("Verify@TD_Description_Less"))) {
					passed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less present");
			} else {
					failed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less not present");
			}
			for(int i=1;i<=5;i++){
				String Check_header = uiDriver.getLocator("TaxExempt_Income.tblColumn_Grid");
				Check_header = Check_header+i+"]";	
				System.out.println(Check_header);
				String text= uiDriver.getWebElement(Check_header).getText();
				System.out.println(text);
				if(i==1){
					if(text.equals(input.get("Verify@Column_Date"))){
						passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
				} else {
						failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
				}
				}
				if(i==2){
					if(text.equals(input.get("Verify@Column_Activity_Type"))){
						passed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type present");
				} else {
						failed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type not present");
				}
				}
				if(i==3)
				{
					if(text.equals(input.get("Verify@Column_Symbol"))){
						passed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol  present");
				} else {
						failed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol not present");
				}
				}
				if(i==4){
					if(text.equals(input.get("Verify@Column_Description"))){
						passed("verify Column_Description","verify Column_Description should present","verify Column_Description  present");
				} else {
						failed("verify Column_Description","verify Column_Description should present","verify Column_Description not present");
				}
				}
				if(i==5){
					if(text.equals(input.get("Verify@Column_Amount"))){
						passed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity present");
				} else {
						failed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity not present");
				}
				}
				}
		RetriveColumndataandSort("TaxExempt_Income.tblTableColumns","TaxExempt_Income.tblData");
		if(!input.get("Click@Symbol").equals(""))
		{
		String link=uiDriver.getLocator("TaxExempt_Income.eltIDCSymbol");
		
		String link2=link.replace("link", input.get("Click@Symbol"));
		System.out.println(link2);
		uiDriver.ClickXpath(link2+"/../img");
		//System.out.println(uiDriver.getAttribute("TaxExempt_Income.linkPopUp", "href"));
		uiDriver.sendKeysEnter("TaxExempt_Income.linkPopUp");
		
 		int cp=uiDriver.NoOfWindows();
 		System.out.println(cp);
 		String parentwindow= uiDriver.getWindowHandle();
		uiDriver.switchToWindowByID(parentwindow);
 		//12. Verify("TaxExempt_Income.elttitle", input.get("Verify@title"))
		/*String MarketInfo=uiDriver.getControl("TaxExempt_Income.lblMarketInfo").getText().trim();
		if (MarketInfo.equals(input.get("Verify@MarketInfo").trim())) {
			passed("Verify MarketInfo","Verify MarketInfo should Present","Verify  MarketInfo Present");
		} else {	
			failed("Verify MarketInfo","Verify MarketInfo should Present","Verify MarketInfo not Present");
		}*/
		uiDriver.switchToWindowParentWindow(parentwindow);
		}
				
	}
	
	
	public void Taxable_Income(DataRow input, DataRow output) {
		uiDriver.ApplicationSync1();
		uiDriver.checkElementPresentpro("Taxable_Income.lstSelected_from_date", 150);
		String check_date= uiDriver.getControl("Taxable_Income.lstSelected_from_date").getText();
		System.out.println(check_date);
		if(check_date.equalsIgnoreCase(input.get("Verify@Selected_from_Date"))){
			 passed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date present");
			} else {
				failed("verify Selected_from_date","verify Selected_from_date should present","verify Selected_from_date not present");
			 }
		
		//2. Verify("Taxable_Income.tblTable_Grid_Message", input.get("Verify@Table_Grid_Message"))
		uiDriver.checkElementPresentpro("Taxable_Income.LblSelected_Account", 15);
		String check_account= uiDriver.getControl("Taxable_Income.LblSelected_Account").getText();
		 System.out.println(check_account);
		 if(check_account.contains(input.get("Verify@Selected_Account"))){
			 passed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account present");
			} else {
				failed("verify Selected_Account","verify Selected_Account should present","verify Selected_Account not present");
	}
		//3. Verify("Checks.lstTD_Description_Less", input.get("Verify@TD_Description_Less"))
			String check_Description= uiDriver.getControl("Taxable_Income.lstTD_Description_Less").getText();
			System.out.println(check_Description);
			if (check_Description.equalsIgnoreCase(input.get("Verify@TD_Description_Less"))) {
					passed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less present");
			} else {
					failed("Verify TD_Description_Less","Verify TD_Description_Less should present","Verify TD_Description_Less not present");
			}
			for(int i=1;i<=5;i++){
				String Check_header = uiDriver.getLocator("Taxable_Income.tblColumn_Grid");
				Check_header = Check_header+i+"]";	
				System.out.println(Check_header);
				String text= uiDriver.getWebElement(Check_header).getText();
				System.out.println(text);
				if(i==1){
					if(text.equals(input.get("Verify@Column_Date"))){
						passed("verify Column_Date","verify Column_Date should present","verify Column_Date present");
				} else {
						failed("verify Column_Date","verify Column_Date should present","verify Column_Date not present");
				}
				}
				if(i==2){
					if(text.equals(input.get("Verify@Column_Activity_Type"))){
						passed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type present");
				} else {
						failed("verify Column_Activity_Type","verify Column_Activity_Type should present","verify Column_Activity_Type not present");
				}
				}
				if(i==3)
				{
					if(text.equals(input.get("Verify@Column_Symbol"))){
						passed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol  present");
				} else {
						failed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol not present");
				}
				}
				if(i==4){
					if(text.equals(input.get("Verify@Column_Description"))){
						passed("verify Column_Description","verify Column_Description should present","verify Column_Description  present");
				} else {
						failed("verify Column_Description","verify Column_Description should present","verify Column_Description not present");
				}
				}
				if(i==5){
					if(text.equals(input.get("Verify@Column_Amount"))){
						passed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity present");
				} else {
						failed("verify Column_Quantity","verify Column_Quantity should present","verify Column_Quantity not present");
				}
				}
				}
		RetriveColumndataandSort("Taxable_Income.tblTableColumns","Taxable_Income.tblData");	
		
		if(!input.get("Click@Symbol").equals(""))
		{
		String link=uiDriver.getLocator("Taxable_Income.eltIDCSymbol");
		
		String link2=link.replace("link", input.get("Click@Symbol"));
		System.out.println(link2);
		uiDriver.ClickXpath(link2+"/../img");
		//System.out.println(uiDriver.getAttribute("Taxable_Income.linkPopUp", "href"));
		uiDriver.sendKeysEnter("Taxable_Income.linkPopUp");
		
 		int cp=uiDriver.NoOfWindows();
 		System.out.println(cp);
 		String parentwindow= uiDriver.getWindowHandle();
		uiDriver.switchToWindowByID(parentwindow);
 		//12. Verify("TaxExempt_Income.elttitle", input.get("Verify@title"))
		/*String MarketInfo=uiDriver.getControl("Taxable_Income.lblMarketInfo").getText().trim();
		if (MarketInfo.equals(input.get("Verify@MarketInfo").trim())) {
			passed("Verify MarketInfo","Verify MarketInfo should Present","Verify  MarketInfo Present");
		} else {	
			failed("Verify MarketInfo","Verify MarketInfo should Present","Verify MarketInfo not Present");
		}*/
		uiDriver.switchToWindowParentWindow(parentwindow);
		}
	}
	
	public void TransactionDetails_HPD(DataRow input, DataRow output) {
		//1. checkElementPresent("TransactionDetails_HPD.lnkPrint", 15000)
		uiDriver.checkElementPresentpro("TransactionDetails_HPD.lnkPrint", 150);
		
		//2. click("TransactionDetails_HPD.lnkPrint")
		uiDriver.javascriptClick("TransactionDetails_HPD.lnkPrint");

		uiDriver.enter();
		
		
		//4. click("TransactionDetails_HPD.lnkDownload")
		uiDriver.checkElementPresentpro("TransactionDetails_HPD.lnkPrint", 150);
		uiDriver.javascriptClick("TransactionDetails_HPD.lnkDownload");
		
		
		
		//6. click("TransactionDetails_HPD.lnkHelp")
		uiDriver.checkElementPresentpro("TransactionDetails_HPD.lnkHelp", 150);
		uiDriver.javascriptClick("TransactionDetails_HPD.lnkHelp");
		
		uiDriver.javascriptClick("TransactionDetails_HPD.eltQuestions");
		
		//7. Verify("TransactionDetails_HPD.eltQuestions", input.get("Verify@Questions"))
		String queslabel=uiDriver.getControl("TransactionDetails_HPD.eltQuestions").getText().trim();
		if (queslabel.equals(input.get("Verify@Questions").trim())) {
			passed("Verify","Verify should pass","Verify passed");
		} else {
			failed("Verify","Verify should pass","Verify failed");
		}
		
	
   List<String> ques=uiDriver.SelectQuestions("TransactionDetails_HPD.VerifyQues");
	
		if(ques.contains(input.get("VerifyQues1").trim()));
		{
			passed("Verify TermTab","Verify TermTab should pass","VerifyTermTab passed");	
			}
	
		uiDriver.checkElementPresentpro("TransactionDetails_HPD.btnTermTab", 30);
		uiDriver.javascriptClick("TransactionDetails_HPD.btnTermTab");
		String term=uiDriver.getControl("TransactionDetails_HPD.btnTermTab").getText().trim();;
		
		//8. Verify("TransactionDetails_HPD.pgeTermTab", input.get("Verify@TermTab"))
		if (term.equals(input.get("Verify@TermTab"))) {
			passed("Verify TermTab","Verify TermTab should pass","VerifyTermTab passed");
		} else {
			failed("Verify TermTab","Verify TermTab should pass","Verify  TermTab failed");
		}
		uiDriver.checkElementPresentpro("TransactionDetails_HPD.lnkTransaction_Details", 30);
		uiDriver.javascriptClick("TransactionDetails_HPD.lnkTransaction_Details");
		
	}


	public void Register_Now(DataRow input, DataRow output) {
		//1. checkElementPresent("Register_Now.lnkRegister_Now", 15000)
		System.out.println("in Url launch ");
		uiDriver.launchApplication(input.get("Navigate@URL"));	
		
		uiDriver.checkElementPresentpro("Register_Now.lnkRegister_Now", 40);
		uiDriver.IsDisplayed_boolean("Register_Now.lnkRegister_Now", 15);
		//2. click("Register_Now.lnkRegister_Now")s
		
		uiDriver.javascriptClick("Register_Now.lnkRegister_Now");
		
		uiDriver.Sync("Register_Now.lnkNext");
		//3. click("Register_Now.lnkNext")
		
		uiDriver.checkElementPresentpro("Register_Now.lnkNext", 60);
		
		uiDriver.click("Register_Now.lnkNext");
	}
	
	
	public void Contact_Infomation(DataRow input, DataRow output) {
		//1. checkElementPresent("Contact_Infomation.lnkNext", 15000)
		uiDriver.IsDisplayed_boolean("Contact_Infomation.lnkNext", 30);
		uiDriver.checkElementPresent("Contact_Infomation.lnkNext", 15);
		
		//3. setValue("Contact_Infomation.edtFirst_Name", input.get("type@First_Name"))
		if(!input.get("type@First_Name").equals("NA"))
		uiDriver.setValue("Contact_Infomation.edtFirst_Name", input.get("type@First_Name"));
		
		//4. setValue("Contact_Infomation.edtLastName", input.get("type@LastName"))
		if(!input.get("type@LastName").equals("NA"))
		uiDriver.setValue("Contact_Infomation.edtLastName", input.get("type@LastName"));
		
		//5. setValue("Contact_Infomation.edtAddress_1", input.get("type@Address_1"))
		if(!input.get("type@Address_1").equals("NA"))
		uiDriver.setValue("Contact_Infomation.edtAddress_1", input.get("type@Address_1"));
		
		//6. setValue("Contact_Infomation.edtAddress_2", input.get("type@Address_2"))
		if(!input.get("type@Address_2").equals("NA"))
		uiDriver.setValue("Contact_Infomation.edtAddress_2", input.get("type@Address_2"));
		
		//7. setValue("Contact_Infomation.edtCity", input.get("type@City"))
		if(!input.get("type@City").equals("NA"))
		uiDriver.setValue("Contact_Infomation.edtCity", input.get("type@City"));
		
		//8. setValue("Contact_Infomation.edtCountry", input.get("type@Country"))
		if(!input.get("type@First_Name").equals("NA"))
		uiDriver.setValue("Contact_Infomation.edtCountry", input.get("type@Country"));
		
		//9. setValue("Contact_Infomation.lstState", input.get("Select@State"))
		if(!input.get("Select@State").equals("NA"))
		uiDriver.setValue("Contact_Infomation.lstState", input.get("Select@State"));
		
		//10. setValue("Contact_Infomation.edtPostal_Code", input.get("type@Postal_Code"))
		if(!input.get("type@Postal_Code").equals("NA"))
		uiDriver.setValue("Contact_Infomation.edtPostal_Code", input.get("type@Postal_Code"));

		//2. click("Contact_Infomation.lnkNext")
		uiDriver.click("Contact_Infomation.lnkNext");
		
		if(!input.get("Verify@ErrMsgFirstName").equals("NA")){
			uiDriver.checkElementPresentpro("Contact_Infomation.ErrMsgFirstName", 20);
			String ErrMsgFirstName= uiDriver.getControl("Contact_Infomation.ErrMsgFirstName").getText();
			if(ErrMsgFirstName.contains(input.get("Verify@ErrMsgFirstName"))){
				passed("Verify ErrMsgFirstName","Verify ErrMsgFirstName should present","Verify ErrMsgFirstName is present");
			}else{
				failed("Verify ErrMsgFirstName","Verify ErrMsgFirstName should present","Verify ErrMsgFirstName is not present");
			}
			
		}
		

		if(!input.get("Verify@ErrMsgLastName").equals("NA")){
			uiDriver.checkElementPresentpro("Contact_Infomation.ErrMsgLastName", 20);
			String ErrMsgLastName= uiDriver.getControl("Contact_Infomation.ErrMsgLastName").getText();
			if(ErrMsgLastName.contains(input.get("Verify@ErrMsgLastName"))){
				passed("Verify ErrMsgLastName","Verify ErrMsgLastName should present","Verify ErrMsgLastName is present");
			}else{
				failed("Verify ErrMsgLastName","Verify ErrMsgLastName should present","Verify ErrMsgLastName is not present");
			}
			
		}
		
		if(!input.get("Verify@ErrMsgAddr1").equals("NA")){
			uiDriver.checkElementPresentpro("Contact_Infomation.ErrMsgAddr1", 20);
			String ErrMsgAddr1= uiDriver.getControl("Contact_Infomation.ErrMsgAddr1").getText();
			if(ErrMsgAddr1.contains(input.get("Verify@ErrMsgAddr1"))){
				passed("Verify ErrMsgAddr1","Verify ErrMsgAddr1 should present","Verify ErrMsgAddr1 is present");
			}else{
				failed("Verify ErrMsgAddr1","Verify ErrMsgAddr1 should present","Verify ErrMsgAddr1 is not present");
			}
			
		}
		if(!input.get("Verify@ErrMsgCity").equals("NA")){
			uiDriver.checkElementPresentpro("Contact_Infomation.ErrMsgCity", 20);
			String ErrMsgCity= uiDriver.getControl("Contact_Infomation.ErrMsgCity").getText();
			if(ErrMsgCity.contains(input.get("Verify@ErrMsgCity"))){
				passed("Verify ErrMsgCity","Verify ErrMsgCity should present","Verify ErrMsgCity is present");
			}else{
				failed("Verify ErrMsgCity","Verify ErrMsgCity should present","Verify ErrMsgCity is not present");
			}
			
		}
		
		
		if(!input.get("Verify@ErrMsgState").equals("NA")){
			uiDriver.checkElementPresentpro("Contact_Infomation.ErrMsgState", 20);
			String ErrMsgState= uiDriver.getControl("Contact_Infomation.ErrMsgState").getText();
			if(ErrMsgState.contains(input.get("Verify@ErrMsgState"))){
				passed("Verify ErrMsgState","Verify ErrMsgState should present","Verify ErrMsgState is present");
			}else{
				failed("Verify ErrMsgState","Verify ErrMsgState should present","Verify ErrMsgState is not present");
			}
			
		}
		
		if(!input.get("Verify@ErrMsgPostalCode").equals("NA")){
			uiDriver.checkElementPresentpro("Contact_Infomation.ErrMsgPostalCode", 20);
			String ErrMsgPostalCode= uiDriver.getControl("Contact_Infomation.ErrMsgPostalCode").getText();
			if(ErrMsgPostalCode.contains(input.get("Verify@ErrMsgPostalCode"))){
				passed("Verify ErrMsgPostalCode","Verify ErrMsgPostalCode should present","Verify ErrMsgPostalCode is present");
			}else{
				failed("Verify ErrMsgPostalCode","Verify ErrMsgPostalCode should present","Verify ErrMsgPostalCode is not present");
			}
			
		}
		
		if(!input.get("Verify@ErrMsgCountry").equals("NA")){
			uiDriver.checkElementPresentpro("Contact_Infomation.ErrMsgCountry", 20);
			String ErrMsgCountry= uiDriver.getControl("Contact_Infomation.ErrMsgCountry").getText();
			if(ErrMsgCountry.contains(input.get("Verify@ErrMsgCountry"))){
				passed("Verify ErrMsgCountry","Verify ErrMsgCountry should present","Verify ErrMsgCountry is present");
			}else{
				failed("Verify ErrMsgCountry","Verify ErrMsgCountry should present","Verify ErrMsgCountry is not present");
			}
			
		}
		
	}
	public void TD_No_Data(DataRow input, DataRow output) {
		//1. setValue("TD_No_Data.lstNo_data"))
		
		 uiDriver.checkElementPresentpro("TD_No_Data.lblNo_data", 15);
		String NoDataMsg= uiDriver.getControl("TD_No_Data.lblNo_data").getText().trim();
		System.out.println(NoDataMsg);
		 if(NoDataMsg.equalsIgnoreCase(input.get("Select@No_data").trim())){
			 passed("eltVerifyMsg","eltVerifyMsg should present","eltVerifyMsg present");
			} else {
				failed("eltVerifyMsg","eltVerifyMsg should present","eltVerifyMsg present");
			}
		
	}

	public void PersonalInformation(DataRow input, DataRow output) throws InterruptedException {
		//uiDriver.Sync("PersonalInformation.VerifyPage");
		uiDriver.checkElementPresentpro("PersonalInformation.VerifyPage", 30);
		String Page=uiDriver.getControl("PersonalInformation.VerifyPage").getText();
		if(Page.equalsIgnoreCase(input.get("Verify@text")))
		{
			passed("Verify PersonalInformation","Verify PersonalInformation should present","Verify PersonalInformation is present");
		}else{
			failed("Verify PersonalInformation","Verify PersonalInformation should present","Verify PersonalInformation is not present");
		}
		
		//1. checkElementPresent("PersonalInformation.edtSSN", 15000)
		uiDriver.checkElementPresentpro("PersonalInformation.edtSSN", 30);
		//2. setValue("PersonalInformation.edtSSN", input.get("type@SSN"))
		if(!input.get("type@SSN").equals("NA"))
		uiDriver.setValue("PersonalInformation.edtSSN",input.get("type@SSN"));
		
		//3. setValue("PersonalInformation.chkI_do_not_have_SSN", input.get("Select@I_do_not_have_SSN"))
		if(input.get("Select@I_do_not_have_SSN").equals("YES"))
		uiDriver.javascriptClick("PersonalInformation.chkI_do_not_have_SSN");
		
		//4. setValue("PersonalInformation.lstMMM", input.get("Select@MMM"))
		if(!input.get("Select@MMM").equals("NA"))
		uiDriver.setValue("PersonalInformation.lstMMM", input.get("Select@MMM"));
		
		//11. setValue("PersonalInformation.edtDD", input.get("type@DD"))
		if(!input.get("type@DD").equals("NA"))
		uiDriver.setValue("PersonalInformation.edtDD", input.get("type@DD"));
				
		//12. setValue("PersonalInformation.edtYYYY", input.get("type@YYYY"))
		if(!input.get("type@YYYY").equals("NA"))
		uiDriver.setValue("PersonalInformation.edtYYYY", input.get("type@YYYY"));
		
		//5. setValue("PersonalInformation.edtPostal_Code", input.get("type@Postal_Code"))
		if(!input.get("type@Postal_Code").equals("NA"))
		uiDriver.setValue("PersonalInformation.edtPostal_Code", input.get("type@Postal_Code"));
		
		//6. setValue("PersonalInformation.chkI_have_a_non_US_address", input.get("Select@I_have_a_non_US_address"))
		if(input.get("Select@I_have_a_non_US_address").equals("YES"))
		uiDriver.javascriptClick("PersonalInformation.chkI_have_a_non_US_address");
		
		//7. setValue("PersonalInformation.edtEmail", input.get("type@Email#1"))
		if(!input.get("type@Email#1").equals("NA"))
		uiDriver.setValue("PersonalInformation.edtEmail", input.get("type@Email#1"));
		
		//8. setValue("PersonalInformation.edtRe_enter_Email", input.get("type@Re_enter_Email"))
		if(!input.get("type@Re_enter_Email").equals("NA"))
		uiDriver.setValue("PersonalInformation.edtRe_enter_Email", input.get("type@Re_enter_Email"));
		
		//9. setValue("PersonalInformation.edtMobile_Number", input.get("type@Mobile_Number"))
		if(!input.get("type@Mobile_AreaCode").equals("NA"))
		uiDriver.setValue("PersonalInformation.edtMobile_Number_AreaCode", input.get("type@Mobile_AreaCode"));
		
		if(!input.get("type@Mobile_Number").equals("NA"))
		uiDriver.setValue("PersonalInformation.edtMobile_Number", input.get("type@Mobile_Number"));
		
		if(!input.get("type@Mobile_NumExt").equals("NA"))
		uiDriver.setValue("PersonalInformation.edtMobile_NumExt", input.get("type@Mobile_NumExt"));
		
		//10. setValue("PersonalInformation.edtPrimary_Account_Number", input.get("type@Primary_Account_Number"))
		if(!input.get("type@Primary_Account_Number").equals("NA"))
		uiDriver.setValue("PersonalInformation.edtPrimary_Account_Number", input.get("type@Primary_Account_Number"));		
		
		uiDriver.javascriptClick("PersonalInformation.btnNext");
		
		if(!input.get("Verify@SSNErrorMsg").equals("NA"))
		{   uiDriver.checkElementPresentpro("PersonalInformation.ErrMsgSSN", 30);
			String msg=uiDriver.getControl("PersonalInformation.ErrMsgSSN").getText();
			if(msg.contains(input.get("Verify@SSNErrorMsg"))){
				passed("Verify SSNErrorMsg","Verify SSNErrorMsg should present","Verify SSNErrorMsg is present");
			}else{
				failed("Verify SSNErrorMsg","Verify SSNErrorMsg should present","Verify SSNErrorMsg is not present");
			}
		}
		if(!input.get("Verify@DOBErrorMsg").equals("NA"))
		{    uiDriver.checkElementPresentpro("PersonalInformation.ErrMsgDOB", 30);
			String msg=uiDriver.getControl("PersonalInformation.ErrMsgDOB").getText();
			//System.out.println(msg);
			if(msg.contains(input.get("Verify@DOBErrorMsg"))){
				passed("Verify DOBErrorMsg","Verify DOBErrorMsg should present","Verify DOBErrorMsg is present");
			}else{
				failed("Verify DOBErrorMsg","Verify DOBErrorMsg should present","Verify DOBErrorMsg is not present");
			
			}
		}
		
		
		if(!input.get("Verify@PCErrorMsg").equals("NA"))
		{   uiDriver.checkElementPresentpro("PersonalInformation.ErrMsgPC", 30);
			String msg=uiDriver.getControl("PersonalInformation.ErrMsgPC").getText();
			if(msg.contains(input.get("Verify@PCErrorMsg"))){
				passed("Verify PCErrorMsg","Verify PCErrorMsg should present","Verify PCErrorMsg is present");
			}else{
				failed("Verify PCErrorMsg","Verify PCErrorMsg should present","Verify PCErrorMsg is not present");
			
			}
		}
		
		
		if(!input.get("Verify@EmailErrorMsg").equals("NA"))
		{   uiDriver.checkElementPresentpro("PersonalInformation.ErrMsgEMAIL", 30);
			String msg=uiDriver.getControl("PersonalInformation.ErrMsgEMAIL").getText();
			System.out.println(msg);
			if(msg.contains(input.get("Verify@EmailErrorMsg"))){
				passed("Verify EmailErrorMsg","Verify EmailErrorMsg should present","Verify EmailErrorMsg is present");
			}else{
				failed("Verify EmailErrorMsg","Verify EmailErrorMsg should present","Verify EmailErrorMsg is not present");
			
			}
		}
		
		if(!input.get("Verify@ReEmailErrorMsg").equals("NA"))
		{   
			uiDriver.checkElementPresentpro("PersonalInformation.ErrMsgReEMAIL", 30);
			String xpath=uiDriver.getLocator("PersonalInformation.ErrMsgReEMAIL");
			System.out.println(xpath);
			String msg=uiDriver.getWebElement(xpath).getText();
			System.out.println(msg);
			if(msg.contains(input.get("Verify@ReEmailErrorMsg"))){
				passed("Verify ReEmailErrorMsg","Verify ReEmailErrorMsg should present","Verify ReEmailErrorMsg is present");
			}else{
				failed("Verify ReEmailErrorMsg","Verify ReEmailErrorMsg should present","Verify ReEmailErrorMsg is not present");
			
			}
		}
		
		if(!input.get("Verify@MobileNumberErrorMsg").equals("NA"))
		{   uiDriver.checkElementPresentpro("PersonalInformation.ErrMsgMobNum", 30);
			String msg=uiDriver.getControl("PersonalInformation.ErrMsgMobNum").getText();
			if(msg.contains(input.get("Verify@MobileNumberErrorMsg"))){
				passed("Verify MobileNumberErrorMsg","Verify MobileNumberErrorMsg should present","Verify MobileNumberErrorMsg is present");
			}else{
				failed("Verify MobileNumberErrorMsg","Verify MobileNumberErrorMsg should present","Verify MobileNumberErrorMsg is not present");
			
			}
		}
		
		if(!input.get("Verify@PAErrorMsg").equals("NA"))
		{    uiDriver.checkElementPresentpro("PersonalInformation.ErrMsgPriACCT", 30);
			String msg=uiDriver.getControl("PersonalInformation.ErrMsgPriACCT").getText();
			if(msg.contains(input.get("Verify@PAErrorMsg"))){
				passed("Verify PAErrorMsg","Verify PAErrorMsg should present","Verify PAErrorMsg is present");
			}else{
				failed("Verify PAErrorMsg","Verify PAErrorMsg should present","Verify PAErrorMsg is not present");
			
			}
		}
	
	}
	public void UserId_Password(DataRow input, DataRow output) throws InterruptedException {
		//uiDriver.waitForBrowserStability(10);
		//uiDriver.AppSync();
		//uiDriver.checkElementPresentpro("UserId_Password.Verifypage", 50);
		//uiDriver.IsDisplayed_boolean("UserId_Password.Verifypage", 50);
		uiDriver.Sync("UserId_Password.Verifypage");
		String page=uiDriver.getControl("UserId_Password.Verifypage").getText().trim();
		System.out.print(page);
		if(page.contains(input.get("Verify@page").trim()))
		{
			passed("Verify UserId_Password","Verify UserId_Password should present","Verify UserId_Password is present");
		}else{
			failed("Verify UserId_Password","Verify UserId_Password should present","Verify UserId_Password is not present");
			
		}
		
		//3. setValue("UserId_Password.edtUserID", input.get("type@UserID"))
		
		uiDriver.checkElementPresentpro("UserId_Password.edtUserID", 50);
		if(!input.get("type@UserID").equals("NA"))
		uiDriver.setValue("UserId_Password.edtUserID", input.get("type@UserID"));
		
		//1. checkElementPresent("UserId_Password.lnkNext", 15000)
		//4. setValue("UserId_Password.edtUserID_Hint", input.get("type@UserID_Hint"))
		if(!input.get("type@UserID_Hint").equals("NA"))
		uiDriver.setValue("UserId_Password.edtUserID_Hint", input.get("type@UserID_Hint"));
		

		
		//6. setValue("UserId_Password.edtPassword", input.get("type@Password"))
		if(!input.get("type@Password").equals("NA"))
		uiDriver.setValue("UserId_Password.edtPassword", input.get("type@Password"));
		
		//5. setValue("UserId_Password.edtConfirm_Password", input.get("type@Confirm_Password"))
		if(!input.get("type@Confirm_Password").equals("NA"))
		uiDriver.setValue("UserId_Password.edtConfirm_Password", input.get("type@Confirm_Password"));

		if(!input.get("Verify@ErrMsgUserIDexistsAlready").equals("NA"))
		{   
			uiDriver.checkElementPresentpro("UserId_Password.ErrMsgUserIDexistsAlready", 40);
			String msg=uiDriver.getControl("UserId_Password.ErrMsgUserIDexistsAlready").getText();
			System.out.println(msg);
			if(msg.contains(input.get("Verify@ErrMsgUserIDexistsAlready"))){
				passed("Verify ErrMsgUserIDexistsAlready","Verify ErrMsgUserIDexistsAlready should present","Verify ErrMsgUserIDexistsAlready is present");
			}else{
				failed("Verify ErrMsgUserIDexistsAlready","Verify ErrMsgUserIDexistsAlready should present","Verify ErrMsgUserIDexistsAlready is not present");
			
			}
		}
		
		uiDriver.checkElementPresentpro("UserId_Password.lnkNext", 15);
		
		//2. click("UserId_Password.lnkNext")
		uiDriver.click("UserId_Password.lnkNext");
		
		if(!input.get("Verify@ErrMsgUserID").equals("NA"))
		{   uiDriver.checkElementPresentpro("UserId_Password.ErrMsgUserID", 30);
			String msg=uiDriver.getControl("UserId_Password.ErrMsgUserID").getText();
			System.out.println(msg);
			if(msg.contains(input.get("Verify@ErrMsgUserID"))){
				passed("Verify ErrMsgUserID","Verify ErrMsgUserID should present","Verify ErrMsgUserID is present");
			}else{
				failed("Verify ErrMsgUserID","Verify ErrMsgUserID should present","Verify ErrMsgUserID is not present");
			
			}
		}
		
		
		
		if(!input.get("Verify@ErrMsgUserIDHint").equals("NA"))
		{   uiDriver.checkElementPresentpro("UserId_Password.ErrMsgUserIDHint", 30);
			String msg=uiDriver.getControl("UserId_Password.ErrMsgUserIDHint").getText();
			if(msg.contains(input.get("Verify@ErrMsgUserIDHint"))){
				passed("Verify ErrMsgUserIDHint","Verify ErrMsgUserIDHint should present","Verify ErrMsgUserIDHint is present");
			}else{
				failed("Verify ErrMsgUserIDHint","Verify ErrMsgUserIDHint should present","Verify ErrMsgUserIDHint is not present");
			
			}
		}
		
		if(!input.get("Verify@ErrMsgPassword").equals("NA"))
		{   uiDriver.checkElementPresentpro("UserId_Password.ErrMsgPassword", 30);
			String msg=uiDriver.getControl("UserId_Password.ErrMsgPassword").getText();
			System.out.println(msg);
			if(msg.contains(input.get("Verify@ErrMsgPassword"))){
				passed("Verify ErrMsgPassword","Verify ErrMsgPassword should present","Verify ErrMsgPassword is present");
			}else{
				failed("Verify ErrMsgPassword","Verify ErrMsgPassword should present","Verify ErrMsgPassword is not present");
			
			}
		}
		
		if(!input.get("Verify@ErrMsgConfirmPassword").equals("NA"))
		{   uiDriver.checkElementPresentpro("UserId_Password.ErrMsgConfirmPassword", 30);
		
			String msg=uiDriver.getControl("UserId_Password.ErrMsgConfirmPassword").getText();
			System.out.println(msg);
			if(msg.contains(input.get("Verify@ErrMsgConfirmPassword"))){
				passed("Verify ErrMsgConfirmPassword","Verify ErrMsgConfirmPassword should present","Verify ErrMsgConfirmPassword is present");
			}else{
				failed("Verify ErrMsgConfirmPassword","Verify ErrMsgConfirmPassword should present","Verify ErrMsgConfirmPassword is not present");
			
			}
		}
		
	}
	
	public void Account_Selection(DataRow input, DataRow output) {
		//1. checkElementPresent("Account_Selection.lnkNext", 15000)
		uiDriver.checkElementPresent("Account_Selection.lnkNext", 15000);
		
		//2. setValue("Account_Selection.edtAccount_Number_1", input.get("Type@Account_Number_1"))
		if(!input.get("Type@Account_Number_1").equals("NA"))
		uiDriver.setValue("Account_Selection.edtAccount_Number_1", input.get("Type@Account_Number_1"));
		
		//3. setValue("Account_Selection.edtAccount_Number_2", input.get("Type@Account_Number_2"))
		if(!input.get("Type@Account_Number_2").equals("NA"))
		uiDriver.setValue("Account_Selection.edtAccount_Number_2", input.get("Type@Account_Number_2"));
		
		//4. setValue("Account_Selection.edtAccount_Label_1", input.get("Type@Account_Label_1"))
		if(!input.get("Type@Account_Label_1").equals("NA"))
		uiDriver.setValue("Account_Selection.edtAccount_Label_1", input.get("Type@Account_Label_1"));
		
		//5. setValue("Account_Selection.edtAccount_Label_2", input.get("Type@Account_Label_2"))
		if(!input.get("Type@Account_Label_2").equals("NA"))
		uiDriver.setValue("Account_Selection.edtAccount_Label_2", input.get("Type@Account_Label_2"));
		
		//6. click("Account_Selection.lnkNext")
		
		uiDriver.click("Account_Selection.lnkNext");
		
		//7. Verify Account_Selection.ErrMsgAccount1 
		if(!input.get("Verify@ErrMsgAccount1").equals("NA"))
		{   uiDriver.checkElementPresentpro("Account_Selection.ErrMsgAccount1", 30);
		
			String ErrMsgAccount1=uiDriver.getControl("Account_Selection.ErrMsgAccount1").getText();
			if(ErrMsgAccount1.contains(input.get("Verify@ErrMsgAccount1"))){
				passed("Verify ErrMsgAccount1","Verify ErrMsgAccount1 should present","Verify ErrMsgAccount1 is present");
			}else{
				failed("Verify ErrMsgAccount1","Verify ErrMsgAccount1 should present","Verify ErrMsgAccount1 is not present");
			
			}
		}
		//8. Verify Account_Selection.ErrMsgAccount2 
		if(!input.get("Verify@ErrMsgAccount2").equals("NA"))
		{   uiDriver.checkElementPresentpro("Account_Selection.ErrMsgAccount2", 30);
		
			String ErrMsgAccount2=uiDriver.getControl("Account_Selection.ErrMsgAccount2").getText();
			if(ErrMsgAccount2.contains(input.get("Verify@ErrMsgAccount2"))){
				passed("Verify ErrMsgAccount2","Verify ErrMsgAccount2 should present","Verify ErrMsgAccount2 is present");
			}else{
				failed("Verify ErrMsgAccount2","Verify ErrMsgAccount2 should present","Verify ErrMsgAccount2 is not present");
			
			}
		}
		//9. Verify Account_Selection.ErrMsgLabel1 
		if(!input.get("Verify@ErrMsgLabel1").equals("NA"))
		{   uiDriver.checkElementPresentpro("Account_Selection.ErrMsgLabel1", 30);
		
			String ErrMsgLabel1=uiDriver.getControl("Account_Selection.ErrMsgLabel1").getText();
			System.out.println(ErrMsgLabel1);
			if(ErrMsgLabel1.contains(input.get("Verify@ErrMsgLabel1"))){
				passed("Verify ErrMsgLabel1","Verify ErrMsgLabel1 should present","Verify ErrMsgLabel1 is present");
			}else{
				failed("Verify ErrMsgLabel1","Verify ErrMsgLabel1 should present","Verify ErrMsgLabel1 is not present");
			
			}
		}
		//10. Verify Account_Selection.ErrMsgLabel2
		if(!input.get("Verify@ErrMsgLabel2").equals("NA"))
		{   uiDriver.checkElementPresentpro("Account_Selection.ErrMsgLabel2", 30);
		
			String ErrMsgLabel2=uiDriver.getControl("Account_Selection.ErrMsgLabel2").getText();
			if(ErrMsgLabel2.contains(input.get("Verify@ErrMsgLabel2"))){
				passed("Verify ErrMsgLabel2","Verify ErrMsgLabel2 should present","Verify ErrMsgLabel2 is present");
			}else{
				failed("Verify ErrMsgLabel2","Verify ErrMsgLabel2 should present","Verify ErrMsgLabel2 is not present");
			
			}
		}
	}
	
	public void Review_And_Submit(DataRow input, DataRow output) throws InterruptedException {
		//1. checkElementPresent("Review_And_Submit.lnkNext", 15000)
		
		uiDriver.checkElementPresentpro("Review_And_Submit.lnkNext", 30);
		//2. check review and submit page is present
		uiDriver.checkElementPresentpro("Review_And_Submit.pgeVerify", 30);
		String Review=uiDriver.getControl("Review_And_Submit.pgeVerify").getText().trim();
		System.out.println(Review);
		//3.verify the page contains review and submit
		if(Review.contains(input.get("Verify@Review_and_SubmitPage").trim())){
			passed("Verify Review_and_SubmitPage","Verify Review_and_SubmitPage should present","Verify Review_and_SubmitPage is present");
		}else{
			failed("Verify Review_and_SubmitPage","Verify Review_and_SubmitPage should present","Verify Review_and_SubmitPage is not present");
		}
		//4. click("Review_And_Submit.lnkNext")
		uiDriver.javascriptClick("Review_And_Submit.lnkNext");
		//uiDriver.AppSync();
		//5.wait untill confirmation page appears
		uiDriver.Sync("Review_And_Submit.PgeConfirm");
		uiDriver.checkElementPresentpro("Review_And_Submit.PgeConfirm", 30);
		String Confirm=uiDriver.getControl("Review_And_Submit.PgeConfirm").getText().trim();
		System.out.println(Confirm);
		//6/Verify Confirmation page
		if(Confirm.equals(input.get("Verify@Confirmation_Page").trim())){
			passed("Verify Confirmation_Page","Verify Confirmation_Page should present","Verify Confirmation_Page is present");
		}else{
			failed("Verify Confirmation_Page","Verify Confirmation_Page should present","Verify Confirmation_Page is not present");
		}
	}
	

	public void OD_NoData(DataRow input, DataRow output) {
		//1. checkElementPresent("OD_NoData.lnkAccount_Summary", 15000)
		uiDriver.Sync("OD_NoData.lnkAccount_Summary");
		uiDriver.checkElementPresentpro("OD_NoData.lnkAccount_Summary", 15);
		
		//2. click("OD_NoData.lnkAccount_Summary")
				uiDriver.javascriptClick("OD_NoData.lnkAccount_Summary");
		
		//3. Verify("OD_NoData.eltAccountDetailDisplayed", input.get("Verify@AccountDetailDisplayed"))
				uiDriver.Sync("OD_NoData.eltAccountDetailDisplayed");
		uiDriver.checkElementPresentpro("OD_NoData.eltAccountDetailDisplayed", 50);
		 String ActDetail= uiDriver.getControl("OD_NoData.eltAccountDetailDisplayed").getText();
		 if(ActDetail.equalsIgnoreCase(input.get("Verify@AccountDetailDisplayed"))){
				passed("Verify AccountDetailDisplayed ","Verify Account Detail should Displayed","Verify Account Detail Displayed");
			} else {
				failed("Verify AccountDetailDisplayed ","Verify Account Detail should Displayed","Verify Account Detail is not Displayed");
		}
		
		 uiDriver.checkElementPresentpro("OD_NoData.lnkOnline_Documents", 15);
		//4. click("OD_NoData.lnkOnline_Documents")
		uiDriver.javascriptClick("OD_NoData.lnkOnline_Documents");
		
		uiDriver.Sync("OD_NoData.eltOnlineDocumentDisplayed");
		uiDriver.checkElementPresentpro("OD_NoData.eltOnlineDocumentDisplayed", 15);
	//	uiDriver.IsDisplayed_boolean("OD_NoData.eltOnlineDocumentDisplayed", 50);
		 String OnlineDoc= uiDriver.getControl("OD_NoData.eltOnlineDocumentDisplayed").getText().trim();
		 System.out.println(OnlineDoc);
		 if(OnlineDoc.equalsIgnoreCase(input.get("Verify@OnlineDocumentDisplayed").trim())){
				passed("Verify OnlineDocumentDisplayed ","Verify OnlineDocument should Displayed","Verify OnlineDocument Displayed");
			} else {
				failed("Verify OnlineDocumentDisplayed ","Verify OnlineDocument should Displayed","Verify OnlineDocument is not Displayed");
		}
		
		//5. setValue("OD_NoData.lstaccount", input.get("Select@account"))
		uiDriver.setValue("OD_NoData.lstaccount", input.get("Select@account"));
		
		//6. click("OD_NoData.btnView")
		uiDriver.javascriptClick("OD_NoData.btnView");
		uiDriver.checkElementPresentpro("OD_NoData.edtVerify_text", 50);
		 String NoData= uiDriver.getControl("OD_NoData.edtVerify_text").getText();
		 if(NoData.equalsIgnoreCase(input.get("Verify@Verify_text"))){
				passed("Verify No_data_msg ","Verify No_data_msg should Displayed","Verify No_data_msg Displayed");
			} else {
				failed("Verify No_data_msg ","Verify No_data_msg should Displayed","Verify No_data_msg is not Displayed");
		}
		
	}
	
	public void Online_Documents(DataRow input, DataRow output) {
		
		
		uiDriver.Sync("Online_Documents.lnkAccount_Summary");
		//1. checkElementPresent("Online_Documents.lnkAccount_Summary", 15000)
		uiDriver.checkElementPresentpro("Online_Documents.lnkAccount_Summary", 15000);
				
		//2. click("Online_Documents.lnkAccount_Summary")
		uiDriver.javascriptClick("Online_Documents.lnkAccount_Summary");
				
		
		//3. Verify("Online_Documents.eltAccountDetailDisplayed", input.get("Verify@AccountDetailDisplayed"))
		uiDriver.Sync("Online_Documents.eltAccountDetailDisplayed");
		uiDriver.checkElementPresentpro("Online_Documents.eltAccountDetailDisplayed", 50);
		 String ActDetail= uiDriver.getControl("Online_Documents.eltAccountDetailDisplayed").getText();
		 if(ActDetail.equalsIgnoreCase(input.get("Verify@AccountDetailDisplayed"))){
				passed("Verify AccountDetailDisplayed ","Verify Account Detail should Displayed","Verify Account Detail Displayed");
			} else {
				failed("Verify AccountDetailDisplayed ","Verify Account Detail should Displayed","Verify Account Detail is not Displayed");
		}
		
		 uiDriver.checkElementPresentpro("Online_Documents.lnkOnline_Documents", 15);
		//4. click("OD_NoData.lnkOnline_Documents")
		uiDriver.javascriptClick("Online_Documents.lnkOnline_Documents");
		//6. Verify("Online_Documents.eltTitle_online_document", input.get("Verify@Title_online_document"))
		
		uiDriver.Sync("Online_Documents.eltTitle_online_document");
		uiDriver.checkElementPresentpro("Online_Documents.eltTitle_online_document", 15);
	//	uiDriver.IsDisplayed_boolean("OD_NoData.eltOnlineDocumentDisplayed", 50);
		 String OnlineDoc= uiDriver.getControl("Online_Documents.eltTitle_online_document").getText().trim();
		 System.out.println(OnlineDoc);
		 if(OnlineDoc.equalsIgnoreCase(input.get("Verify@Title_online_document").trim())){
				passed("Verify OnlineDocumentDisplayed ","Verify OnlineDocument should Displayed","Verify OnlineDocument Displayed");
			} else {
				failed("Verify OnlineDocumentDisplayed ","Verify OnlineDocument should Displayed","Verify OnlineDocument is not Displayed");
		}
		
		
		//5. Verify("Online_Documents.eltVerify_Breadcrumb", input.get("Verify@Verify_Breadcrumb"))
		String bcrum= uiDriver.getControl("Online_Documents.eltVerify_Breadcrumb").getText();
		System.out.println(bcrum);
		if (bcrum.equals(input.get("Verify@Verify_Breadcrumb"))) {
			passed("Verify_Breadcrumb","Verify_Breadcrumb should pass","Verify_Breadcrumb passed");
		} else {
			failed("Verify_Breadcrumb","Verify_Breadcrumb should pass","Verify_Breadcrumb failed");
		}
		
	
		
		//7. Verify("Online_Documents.eltDefault_tab", input.get("Verify@Default_tab"))
		String tab= uiDriver.getControl("Online_Documents.eltDefault_tab").getText();
		System.out.println(tab);
		if (tab.equals(input.get("Verify@Default_tab"))) {
			passed("Verify Default_tab","Verify Default_tab should pass","Verify Default_tab passed");
		} else {
			failed("Verify Default_tab","Verify Default_tab should pass","Verify Default_tab failed");
		}
		
		//8. setValue("Online_Documents.edtSelect_Account", input.get("type@Select_Account"))
		if(!input.get("type@Select_Account").equals(""))
		uiDriver.setValue("Online_Documents.edtSelect_Account", input.get("type@Select_Account"));
		
		//9. setValue("Online_Documents.lstDocument_Type", input.get("Select@Document_Type"))
		if(!input.get("Select@Document_Type").equals(""))
		uiDriver.setValue("Online_Documents.lstDocument_Type", input.get("Select@Document_Type"));
		
		//10. click("Online_Documents.rdgDate_Range")
		if(!input.get("Select@rdgDate_Range").equals(""))
		{
			String data=null;
			if(input.get("Select@rdgDate_Range").equals("Defined"))
			{
				 data="true";
			}
			if(input.get("Select@rdgDate_Range").equals("Custom"))
			{
				 data="false";
			}
			String def = uiDriver.getLocator("Online_Documents.rdgDate_Range");
			def=def.replace("Data",data);
			System.out.println(def);
			uiDriver.ClickXpath(def);
			//uiDriver.jsClickxpath(def);
		}
		//11. setValue("Online_Documents.lstDefined", input.get("Select@Defined"))
		if(!input.get("Select@DataRange").equals(""))
		uiDriver.setValue("Online_Documents.lstDefined", input.get("Select@DataRange"));
		
		//12. setValue("Online_Documents.lstF_MMM", input.get("Select@F_MMM"))
		if(!input.get("Select@F_MMM").equals(""))
		{
		uiDriver.checkElementPresentpro("Online_Documents.lstF_MMM", 15);
		uiDriver.setValue("Online_Documents.lstF_MMM", input.get("Select@F_MMM"));
		}
		//13. setValue("Online_Documents.edtF_DD", input.get("type@F_DD"))
		if(!input.get("type@F_DD").equals(""))
		uiDriver.setValue("Online_Documents.edtF_DD", input.get("type@F_DD"));
		
		//14. setValue("Online_Documents.edtF_YYYY", input.get("type@F_YYYY"))
		if(!input.get("type@F_YYYY").equals(""))
		uiDriver.setValue("Online_Documents.edtF_YYYY", input.get("type@F_YYYY"));
		
		//15. setValue("Online_Documents.lstT_MMM", input.get("Select@T_MMM"))
		if(!input.get("Select@T_MMM").equals(""))
		uiDriver.setValue("Online_Documents.lstT_MMM", input.get("Select@T_MMM"));
		
		//16. setValue("Online_Documents.edtT_DD", input.get("type@T_DD"))
		if(!input.get("type@T_DD").equals(""))
		uiDriver.setValue("Online_Documents.edtT_DD", input.get("type@T_DD"));
		
		//17. setValue("Online_Documents.edtT_YYYY", input.get("type@T_YYYY"))
		if(!input.get("type@T_YYYY").equals(""))
		uiDriver.setValue("Online_Documents.edtT_YYYY", input.get("type@T_YYYY"));
		
	}
	
	public void OD_DateRange_Custom(DataRow input, DataRow output) {
		
		if (uiDriver.verifyText("OD_DateRange_Custom.eltDefault_Message", input.get("Verify@Default_Message"))) {
			passed("Verify eltDefault_Message before clicking view","Verify  eltDefault_Message before clicking view should present","Verify eltDefault_Message before clicking view present");
		} else {
			failed("Verify eltDefault_Message before clicking view","Verify  eltDefault_Message before clicking view should present","Verify eltDefault_Message before clicking view is not present");
		}
		//14. click("OD_DateRange_Custom.btnView")
		uiDriver.checkElementPresentpro("OD_DateRange_Custom.btnView", 15);
		uiDriver.javascriptClick("OD_DateRange_Custom.btnView");
		//13. Verify("OD_DateRange_Custom.eltDefault_Message", input.get("Verify@Default_Message"))
		if (uiDriver.verifyText("OD_DateRange_Custom.eltDefault_Message", input.get("Verify@Default_Message"))) {
			passed("Verify eltDefault_Message AFTER clicking view","Verify  eltDefault_Message AFTER clicking view should present","Verify eltDefault_Message AFTER clicking view present");
		} else {
			failed("Verify eltDefault_Message AFTER clicking view","Verify  eltDefault_Message AFTER clicking view should present","Verify eltDefault_Message AFTER clicking view is not present");
		}
		
		
		
	}
	

	public void DT_Confirmations(DataRow input, DataRow output) {
		String Check_header=null;
		//1. Verify("DT_Confirmations.eltDcoument_Type", input.get("Verify@Dcoument_Type"))
		if (uiDriver.verifyText("DT_Confirmations.eltDocumentType", input.get("Verify@DocumentType"))) {
			passed("Verify eltDocumentType","Verify eltDocumentType should pass","Verify eltDocumentType passed");
		} else {
			failed("Verify eltDocumentType","Verify eltDocumentType should pass","Verify eltDocumentType failed");
		}
		
		//2. Verify("DT_Confirmations.eltGrid_Message", input.get("Verify@Grid_Message"))
		if (uiDriver.verifyText("DT_Confirmations.eltGrid_Message", input.get("Verify@Grid_Message"))) {
			passed("Verify verifyText","Verify verifyText should pass","Verify verifyText passed");
		} else {
			failed("Verify verifyText","Verify verifyText should pass","Verify verifyText failed");
		}
		
		if(uiDriver.checkIfElementPresent("DT_Confirmations.eltVerify_Headers",5))
		Check_header = uiDriver.getLocator("DT_Confirmations.eltVerify_Headers");
		else
		Check_header = uiDriver.getLocator("DT_Confirmations.eltVerify_HeadersNodata");
		
		for(int i=1;i<=3;i++){
			
			String Check_headers = Check_header+"["+i+"]";	
			System.out.println(Check_headers);
			String text= uiDriver.getWebElement(Check_headers).getText();
			System.out.println(text);
			if(i==1){
				if(text.equals(input.get("Verify@Col_DocumentDate"))){
					passed("verify Col_DocumentDate","verify Col_DocumentDate should present","verify Col_DocumentDate present");
			} else {
					failed("verify Col_DocumentDate","verify Col_DocumentDate should present","verify Col_DocumentDate not present");
			}
			}
			if(i==2){
				if(text.equals(input.get("Verify@Col_Description"))){
					passed("verify Col_Description","verify Col_Description should present","verify Col_Description present");
			} else {
					failed("verify Col_Description","verify Col_Description should present","verify Col_Description not present");
			}
			}
			if(i==3)
			
				if(text.equals(input.get("Verify@Col_RelatedInformation"))){
					passed("verify Col_RelatedInformation","verify Col_RelatedInformation should present","verify Col_RelatedInformation  present");
			} else {
					failed("verify Col_RelatedInformation","verify Col_RelatedInformation should present","verify Col_RelatedInformation not present");
			}
			
			}
			
		if(uiDriver.checkIfElementPresent("DT_Confirmations.tblTableColumns", 5))
		RetriveColumndataandSort("DT_Confirmations.tblTableColumns","DT_Confirmations.tblData");

		
	
	}
	
	

	public void OD_Help(DataRow input, DataRow output) {
		//1. checkElementPresent("OD_Help.lnkHelp", 15000)
		uiDriver.checkElementPresentpro("OD_Help.lnkHelp", 15);
		
		//2. click("OD_Help.lnkHelp")
		uiDriver.javascriptClick("OD_Help.lnkHelp");
		
		//3. Verify("OD_Help.eltQuestions", input.get("Verify@Questions"))
		if (uiDriver.verifyText("OD_Help.eltQuestions", input.get("Verify@Questions"))) {
			passed("Verify eltQuestions","Verify eltQuestions should pass","Verify eltQuestions passed");
		} else {
			failed("Verify eltQuestions","Verify eltQuestions should pass","Verify eltQuestions failed");
		}
		
		List<String> ques=uiDriver.SelectQuestions("OD_Help.VerifyQues");
		
		if(ques.contains(input.get("VerifyQues1").trim()));
		{
			passed("Verify OnlineDocument_Ques","Verify OnlineDocument_Ques should pass","Verify OnlineDocument_Ques passed");	
			
		}
		//5. click("OD_Help.btnTermTab")
		uiDriver.checkElementPresentpro("OD_Help.btnTermTab", 15);
		uiDriver.click("OD_Help.btnTermTab");
				
		//4. Verify("OD_Help.pgeTermTab", input.get("Verify@TermTab"))
		String term=uiDriver.getControl("OD_Help.btnTermTab").getText().trim();;
		if (term.equals(input.get("Verify@TermTab"))) {
			passed("Verify TermTab","Verify TermTab should pass","VerifyTermTab passed");
		} else {
			failed("Verify TermTab","Verify TermTab should pass","Verify  TermTab failed");
		}
		
		
		//6. click("OD_Help.lnkGo_to_Online_Documents")
		uiDriver.checkElementPresentpro("OD_Help.lnkGo_to_Online_Documents", 15);
		uiDriver.click("OD_Help.lnkGo_to_Online_Documents");
		
		
	
		
	}
	
	public void DT_TaxDocuments(DataRow input, DataRow output) {
		String Check_header=null;
		//1. Verify("DT_TaxDocuments.eltDcoument_Type", input.get("verify@Dcoument_Type"))
		if (uiDriver.verifyText("DT_TaxDocuments.eltDcoument_Type", input.get("Verify@DocumentType"))) {
			passed("Verify eltDcoument_Type","Verify eltDcoument_Type should pass","Verify eltDcoument_Type passed");
		} else {
			failed("Verify eltDcoument_Type","Verify eltDcoument_Type should pass","Verify eltDcoument_Type failed");
		}
		
		if (uiDriver.verifyText("DT_TaxDocuments.eltGrid_Message", input.get("Verify@Grid_Message"))) {
			passed("Verify verifyText","Verify verifyText should pass","Verify verifyText passed");
		} else {
			failed("Verify verifyText","Verify verifyText should pass","Verify verifyText failed");
		}
		
		if(uiDriver.checkIfElementPresent("DT_TaxDocuments.eltVerify_Headers",5))
		Check_header = uiDriver.getLocator("DT_TaxDocuments.eltVerify_Headers");
		else
		Check_header = uiDriver.getLocator("DT_TaxDocuments.eltVerify_HeadersNodata");
		
		for(int i=1;i<=3;i++){
			
			String Check_headers = Check_header+"["+i+"]";	
			System.out.println(Check_headers);
			String text= uiDriver.getWebElement(Check_headers).getText();
			System.out.println(text);
			if(i==1){
				if(text.equals(input.get("Verify@Col_DocumentDate"))){
					passed("verify Col_DocumentDate","verify Col_DocumentDate should present","verify Col_DocumentDate present");
			} else {
					failed("verify Col_DocumentDate","verify Col_DocumentDate should present","verify Col_DocumentDate not present");
			}
			}
			if(i==2){
				if(text.equals(input.get("Verify@Col_Description"))){
					passed("verify Col_Description","verify Col_Description should present","verify Col_Description present");
			} else {
					failed("verify Col_Description","verify Col_Description should present","verify Col_Description not present");
			}
			}
			if(i==3)
			
				if(text.equals(input.get("Verify@Col_RelatedInformation"))){
					passed("verify Col_RelatedInformation","verify Col_RelatedInformation should present","verify Col_RelatedInformation  present");
			} else {
					failed("verify Col_RelatedInformation","verify Col_RelatedInformation should present","verify Col_RelatedInformation not present");
			}
			
			}
			
		if(uiDriver.checkIfElementPresent("DT_TaxDocuments.tblTableColumns", 5))
		RetriveColumndataandSort("DT_TaxDocuments.tblTableColumns","DT_TaxDocuments.tblData");

		
		
	}
	public void CloseBrowser(DataRow input, DataRow output){
		//1.Close the browser
		uiDriver.closeBrowser();	
	}
	
	public void InvestorCenter(DataRow input, DataRow output) {
		//1. checkElementPresent("InvestorCenter.lnkInvestor_Center", 15000)
		uiDriver.Sync("InvestorCenter.lnkInvestor_Center");
		uiDriver.checkElementPresentpro("InvestorCenter.lnkInvestor_Center", 15);
		
		//2. click("InvestorCenter.lnkInvestor_Center")
		uiDriver.javascriptClick("InvestorCenter.lnkInvestor_Center");
		
	}
	public void Research_and_Insights_Not0(DataRow input, DataRow output) {
		
		if(!uiDriver.checkIfElementPresent("Research_and_Insights_Not0.edtInvestor_Center", 5))
		{
			passed("verify Research & Insights ","verify Research & Insights  should not present","verify Research & Insights  is not present");
		} else {
				failed("verify Research & Insights ","verify Research & Insights  should not present","verify Research & Insights  present");
			
		}
	}

	public void Research_Insights_NoAgreement(DataRow input, DataRow output) {
		//1. setValue("Research_Insights_NoAgreement.edtInvestor_center", input.get("Type@Investor_center"))
		uiDriver.switchToiFrame("marketInfoWidLen");
		uiDriver.javascriptClick("Research_Insights_NoAgreement.lnkResearch_and_Insights");
		
		uiDriver.checkElementPresentpro("Research_Insights_NoAgreement.lnkResearch_and_Insights", 5);
		if(uiDriver.checkIfElementPresent("Research_Insights_NoAgreement.lnkResearch_and_Insights", 5))
		{
			passed("verify Research & Insights ","verify Research & Insights  should present","verify Research & Insights  is present");
		} else {
				failed("verify Research & Insights ","verify Research & Insights  should present","verify Research & Insights  not present");
			
		}
		
		//3. click("Research_Insights_NoAgreement.lnkResearch_and_Insights")
	
		
		String researchTab= uiDriver.getControl("Research_Insights_NoAgreement.VerifyAllResearch").getText().trim();
		if(researchTab.equals(input.get("Verify@Investor_center").trim())){
			passed("verify Research & Insights clicked successfully ","verify Research & Insights  should clicked successfully","verify Research & Insights  is clicked successfully");
		} else {
			failed("verify Research & Insights clicked successfully ","verify Research & Insights  should clicked successfully","verify Research & Insights  not clicked successfully");
		}
	
	}
	
	public void Click_Contact(DataRow input, DataRow output) {
		//1. checkElementPresent("Click_Contact.btnContact", 15000)
		uiDriver.checkElementPresent("Click_Contact.btnContact", 15000);
		
		//2. click("Click_Contact.btnContact")
		uiDriver.click("Click_Contact.btnContact");
		
		//3. Validate the Breadcrumb is My Service Center > Communications > Contact Us
		uiDriver.checkElementPresent("Click_Contact.eltBreadcrumb", 15);
		
		System.out.println("Breadcrum is present");
		
		String BreadCrum= uiDriver.getControl("Click_Contact.eltBreadcrumb").getText().trim();
		
		System.out.println("Got control on div");
		System.out.println(BreadCrum);
		
		
		if(BreadCrum.equalsIgnoreCase(input.get("Verify@BreadCrum").trim())){
			passed("Verify lnkBreadCrum ","Verify eltBreadcrumb should Displayed","Verify eltBreadcrumb Displayed");
		} else {
			failed("Verify lnkBreadCrum ","Verify eltBreadcrumb should Displayed","Verify eltBreadcrumb is not Displayed");
		}
		
		
		
	}
public void MarketInfo_APFinancialNews(DataRow input, DataRow output) {
		
		uiDriver.verifyText("MarketInfo_APFinancialNews.eltSection_Header", input.get("Verify@APHeader"));
		
		uiDriver.checkElementPresent("MarketInfo_APFinancialNews.lnkLink", 15000);
		
		uiDriver.getInnerHTMLText("MarketInfo_APFinancialNews.lnkLink");
		//1. click("MarketInfo_APFinancialNews.lnkLink")
		uiDriver.click("MarketInfo_APFinancialNews.lnkLink");
		
	}
	
	public void PortfolioSummary(DataRow input, DataRow output) {
		//1. checkElementPresent("PortfolioSummary.lnkPortfolio_Summary", 15000)
		uiDriver.checkElementPresent("PortfolioSummary.lnkPortfolio_Summary", 15000);
		
		//2. click("PortfolioSummary.lnkPortfolio_Summary")
		uiDriver.click("PortfolioSummary.lnkPortfolio_Summary");
		
		String [] dataArray=uiDriver.fetchsessionlogfromDB1("QADRC13");
		System.out.println("Validating session log from database");
		
		System.out.println(dataArray[0]);
		if (dataArray[0].equals("126") ) {
			passed("Change_Contact_Information","Session log should match","sesion log is matched");
		} else {
			failed("Change_Contact_Information","Session log should match","sesion log is not matched");
		}
		
//		if (dataArray[2].equals("chk2375@gmail.com") ) {
//			passed("Change_Contact_Information","Session log should match","sesion log is matched");
//		} else {
//			failed("Change_Contact_Information","Session log should match","sesion log is not matched");
//		}
		
//		if (dataArray[1].equals("null") ) {
//			passed("Change_Contact_Information","Session log should match","sesion log is matched");
//		} else {
//			failed("Change_Contact_Information","Session log should match","sesion log is not matched");
//		}

		
	}
	
	public void PS_BalancesTab(DataRow input, DataRow output) {
		//1. checkElementPresent("PS_BalancesTab.lnkBalances", 15000)
		uiDriver.checkElementPresent("PS_BalancesTab.lnkBalances", 15000);
		
		System.out.println("Balance tab is present");
		
		uiDriver.click("PS_BalancesTab.lnkBalances");
//		uiDriver.checkElementPresent("PS_BalancesTab.eltBalances",15000);
//		//2. verify the accounts  which are having multicurrency," � "
//		uiDriver.verifyText("PS_BalancesTab.eltBalances","�");
//		
//		uiDriver.checkElementPresent("PS_BalancesTab.lnkBalances",15000);
//		//3. click("PS_BalancesTab.lnkBalances")
//		uiDriver.click("PS_BalancesTab.lnkBalances");
//		
//		uiDriver.checkElementPresent("PS_BalancesTab.eltAS",15000);
//		//4. Verify the Astric symbol (*) for the accounts
//		uiDriver.verifyText("PS_BalancesTab.eltAS", "*");
				
		//5.
		RetriveColumndataandSort(uiDriver.getLocator("PS_BalancesTab.btnColumn_name"),"PS_BalancesTab.eltSort");

		
		//6. Peform sorting by Clicking on the all column headers for all the tables displayed
		
		
		
	}
	
		public void RetriveColumndataandSort(String mainpath,String localpath){
			List listA = new ArrayList();
			List listB = new ArrayList();
			 String data;
			String locator = uiDriver.getLocator(localpath);
			List<WebElement> tr_Collection = uiDriver.getWebElements(locator+"/tr");
			//webDr.findElements(By.xpath(locator+"/tr"));
			 int c=uiDriver.getColumnCount(mainpath);
			 int var = tr_Collection.size();
			 
			 System.out.println(c);
			 String columnname="";
			 for(int i=0;i<c;i++)
			 {
				 columnname=uiDriver.th.getCellData(mainpath, 0, i); 
				 System.out.println(columnname);
				/* if (!uiDriver.th.getCellData(mainpath, 0, i).equals(""))
				 {*/
				 if(!columnname.equals("")){
	                uiDriver.ClickCell(mainpath, 0, i);
	                uiDriver.wait(2000);
	                for(int j=0;j<var;j++){
	               	 data=uiDriver.th.getCellData(localpath, j, i).trim();
	               	 listA.add(data);
	                } 
				 //}
	                listB.addAll(listA);
	             	System.out.println(listB);
				
					
	             	System.out.println(listA);
	             	listA.clear();
	             	Collections.reverse(listB);
	             	System.out.println(listB);
					uiDriver.ClickCell(mainpath, 0, i);
					uiDriver.wait(2000);
					for(int j=0;j<var;j++){
						 data=uiDriver.th.getCellData(localpath, j, i).trim();
						 listA.add(data);
					} 
					System.out.println(listA);
					System.out.println(listB);
					System.out.println(listA.equals(listB));
					if(listA.equals(listB)){
						 passed("Sorting","Sorting should be done successfully","Sorting is done successfully for the colomn" + columnname  );
						 
						} else {
							failed("Sorting","Sorting should be done successfully","Sorting is not  successfully" + columnname);
						} 
					listA.clear();
					listB.clear();
				 }
		 }	
		 }



	//function to do sorting on particular column

	public void PS_GetaQuote(DataRow input, DataRow output) {
		//1. checkElementPresent("PS_GetaQuote.edtSymbol", 15000)
		uiDriver.checkElementPresent("PS_GetaQuote.edtSymbol", 15000);
		
		//2. setValue("PS_GetaQuote.edtSymbol", input.get("type@Symbol"))
		uiDriver.setValue("PS_GetaQuote.edtSymbol", input.get("type@Symbol"));
		
		//3. click("PS_GetaQuote.btnGo")
		uiDriver.click("PS_GetaQuote.btnGo");
		
		//4. click("PS_GetaQuote.lnkMy_Portfolio")
		uiDriver.click("PS_GetaQuote.lnkMy_Portfolio");
		
	}
	
	public void PS_HistoricalTab(DataRow input, DataRow output) {
		//1. checkElementPresent("PS_HistoricalTab.lnkHistorical", 15000)
		uiDriver.checkElementPresent("PS_HistoricalTab.lnkHistorical", 15000);
		
		//2. click("PS_HistoricalTab.lnkHistorical")
		uiDriver.click("PS_HistoricalTab.lnkHistorical");
		
		//3. click("PS_HistoricalTab.btnColumn_name")
//		uiDriver.click("PS_HistoricalTab.btnColumn_name");
		
		RetriveColumndataandSort(uiDriver.getLocator("PS_HistoricalTab.btnColumn_name"),"PS_HistoricalTab.eltSort");
		
	}
	
	public void PS_Market_Overview(DataRow input, DataRow output) {
		//1. checkElementPresent("PS_Market_Overview.lnkMy_Portfolio", 15000)
		uiDriver.checkElementPresent("PS_Market_Overview.lnkMy_Portfolio", 15000);
		
		//2. click("PS_Market_Overview.lnkMy_Portfolio")
		uiDriver.click("PS_Market_Overview.lnkMy_Portfolio");
		
		//3.
		uiDriver.verifyText("PS_Market_Overview.eltSection_Header", input.get("verify@MarketOverview"));
		
		//4.
		for(int i=1;i<=4;i++){
			String Check_header = uiDriver.getLocator("PS_Market_Overview.eltTable");
			Check_header = Check_header+"["+i+"]";	
			System.out.println(Check_header);
			String text= uiDriver.getWebElement(Check_header).getText();
			System.out.println(text);
			if(i==1){
				if(text.equals(input.get("Verify@Column_Index"))){
					passed("verify Column_Index","verify Column_Index should present","verify Column_Index present");
			} else {
					failed("verify Column_Index","verify Column_Index should present","verify Column_Index not present");
			}
			}
			if(i==2){
				if(text.equals(input.get("Verify@Column_Last"))){
					passed("verify Column_Last","verify Column_Last should present","verify Column_Last present");
			} else {
					failed("verify Column_Last","verify Column_Last should present","verify Column_Last not present");
			}
			}
			
			if(i==3){
				if(text.equals(input.get("Verify@Column_change"))){
					passed("verify Column_change","verify Column_change should present","verify Column_change  present");
			} else {
					failed("verify Column_change","verify Column_change should present","verify Column_change not present");
			}
			}
			if(i==4){
				if(text.equals(input.get("Verify@Column_%change"))){
					passed("verify Column_%change","verify Column_%change should present","verify Column_%change present");
			} else {
					failed("verify Column_%change","verify Column_%change should present","verify Column_%change not present");
			}
			}
			}

		
		uiDriver.checkElementPresent("PS_Market_Overview.lnkIndex", 15000);
		System.out.println("Index link is present");
		uiDriver.click("PS_Market_Overview.lnkIndex");

		System.out.println("Clicked on first Element");
		
		//4.
		uiDriver.switchToiFrame("marketInfoWidLen");
		System.out.println("Switched frame");
		String BreadCrum= uiDriver.getControl("PS_Market_Overview.eltHeaders").getText().trim();
		
		System.out.println("Got control on div");
		System.out.println(BreadCrum);
		
		
		if(BreadCrum.equalsIgnoreCase(input.get("Verify@ElementHeader").trim())){
			passed("Verify ElementHeader ","Verify ElementHeader should Displayed","Verify ElementHeader Displayed");
		} else {
			failed("Verify ElementHeader ","Verify ElementHeader should Displayed","Verify ElementHeader is not Displayed");
		}
		
		
	}
	
	public void PS_MarketSnapshot(DataRow input, DataRow output) {
		
		uiDriver.checkElementPresent("PS_MarketSnapshot.eltSection_Header", 15000);
		
		uiDriver.click("PS_MarketSnapshot.eltSection_Header");
		
		//1. click("PS_MarketSnapshot.lnkLink")
		uiDriver.click("PS_MarketSnapshot.lnkLink");
		
		uiDriver.switchToiFrame("marketInfoWidLen");
		
		uiDriver.verifyText("PS_MarketSnapshot.eltCompany_Research", "Verify@MSHeader");
		
		uiDriver.switchingToParentFrame();
		//2. checkElementPresent("PS_MarketSnapshot.lnkMy_Portfolio", 15000)
		uiDriver.checkElementPresent("PS_MarketSnapshot.lnkMy_Portfolio", 15000);
		
		//3. click("PS_MarketSnapshot.lnkMy_Portfolio")
		uiDriver.click("PS_MarketSnapshot.lnkMy_Portfolio");
		
		
		
	}
	
	public void PS_MultiCurrency(DataRow input, DataRow output) {
		//1. checkElementPresent("PS_MultiCurrency.lnkMulti_Currency", 15000)
		uiDriver.checkElementPresent("PS_MultiCurrency.lnkMulti_Currency", 15000);
		
		//2. click("PS_MultiCurrency.lnkMulti_Currency")
		uiDriver.click("PS_MultiCurrency.lnkMulti_Currency");
		
		RetriveColumndataandSort(uiDriver.getLocator("PS_MultiCurrency.btnColumn_name"),"PS_MultiCurrency.eltSort");
		//3. click("PS_MultiCurrency.btnColumn_name")
//		uiDriver.click("PS_MultiCurrency.btnColumn_name");
		
		//3. validate other currency 
		uiDriver.checkElementPresent("PS_MultiCurrency.tblOC", 15000);
		
		
	}
	
	public void PS_QuickLinks(DataRow input, DataRow output) {
		//1. checkElementPresent("PS_QuickLinks.lnkTest_City_National", 15000)
		uiDriver.checkElementPresent("PS_QuickLinks.lnkTest_City_National", 15000);
		
		String parentwindow= uiDriver.getWindowHandle();
		//2. click("PS_QuickLinks.lnkTest_City_National")
		uiDriver.click("PS_QuickLinks.lnkTest_City_National");
		
		uiDriver.checkElementPresent("PS_QuickLinks.eltTitle", 15000);
		
//		uiDriver.verifyText("PS_QuickLinks.eltTitle", input.get("Verify@NWTitle"));
		
		uiDriver.closeBrowsers();
		
		uiDriver.switchToWindowByID(parentwindow);
		
		uiDriver.checkElementPresent("PS_QuickLinks.lnkView_Realized_Gain_Loss", 15000);
		
		//3. click("PS_QuickLinks.lnkView_Realized_Gain_Loss")
		uiDriver.click("PS_QuickLinks.lnkView_Realized_Gain_Loss");
		
		uiDriver.checkElementPresent("PS_QuickLinks.eltRealized", 15000);
		
		uiDriver.verifyText("PS_QuickLinks.eltRealized", input.get("Verify@RealizedTitle"));
		
		uiDriver.clear("PS_QuickLinks.lnkMy_Portfolio");
		
		//4. click("PS_QuickLinks.lnkView_Online_Documents")
		uiDriver.click("PS_QuickLinks.lnkView_Online_Documents");
		
		
		uiDriver.verifyText("PS_QuickLinks.eltOnline", input.get("Verify@OnlineTitle"));
		
		uiDriver.clear("PS_QuickLinks.lnkMy_Portfolio");
		
		//5. click("PS_QuickLinks.lnkResearch")
		uiDriver.click("PS_QuickLinks.lnkResearch");
		
		uiDriver.verifyText("PS_QuickLinks.eltResearch", input.get("Verify@ReasearchHeader"));
		
		uiDriver.closeBrowsers();
		
		uiDriver.switchToWindowByID(parentwindow);
		
		//6. click("PS_QuickLinks.lnkCost_Basis_Updates")
		uiDriver.click("PS_QuickLinks.lnkCost_Basis_Updates");
		
		uiDriver.verifyText("PS_QuickLinks.eltResearch", input.get("Verify@CBHeader"));
		
		uiDriver.closeBrowsers();
		
		uiDriver.switchToWindowByID(parentwindow);
		
		//7. click("PS_QuickLinks.lnkAdd_Accounts")
		uiDriver.click("PS_QuickLinks.lnkAdd_Accounts");
		
		uiDriver.verifyText("PS_QuickLinks.eltAdd", input.get("Verify@AddTitle"));
		
		uiDriver.clear("PS_QuickLinks.lnkMy_Portfolio");
		
		//8. click("PS_QuickLinks.lnkIncome_Summary")
		uiDriver.click("PS_QuickLinks.lnkIncome_Summary");
		
		uiDriver.verifyText("PS_QuickLinks.eltIncome", input.get("Verify@IncomeTitle"));
		
		uiDriver.clear("PS_QuickLinks.lnkMy_Portfolio");
		
		//11. click("PS_QuickLinks.lnkTransaction_Detail")
		uiDriver.click("PS_QuickLinks.lnkTransaction_Detail");
		
		uiDriver.verifyText("PS_QuickLinks.eltTrans", input.get("Verify@TransTitle"));
		
		uiDriver.clear("PS_QuickLinks.lnkMy_Portfolio");
		
		
	}
	
	public void PS_StockWatch(DataRow input, DataRow output) {
		
		uiDriver.switchingToParentFrame();
		
		//1. checkElementPresent("PS_StockWatch.lnkMy_Portfolio", 15000)
		uiDriver.checkElementPresent("PS_StockWatch.lnkMy_Portfolio", 15000);
		
		//2. click("PS_StockWatch.lnkMy_Portfolio")
		uiDriver.click("PS_StockWatch.lnkMy_Portfolio");
		
		//3.
		uiDriver.verifyText("PS_StockWatch.eltSection_Header", input.get("Verify@StockWatch"));
		
		//4.
		for(int i=1;i<=4;i++){
			String Check_header = uiDriver.getLocator("PS_StockWatch.elttable");
			Check_header = Check_header+"["+i+"]";	
			System.out.println(Check_header);
			String text= uiDriver.getWebElement(Check_header).getText();
			System.out.println(text);
			if(i==1){
				if(text.equals(input.get("Verify@Column_Symbol").trim())){
					passed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol present");
			} else {
					failed("verify Column_Symbol","verify Column_Symbol should present","verify Column_Symbol not present");
			}
			}
			if(i==2){
				if(text.equals(input.get("Verify@Column_Last").trim())){
					passed("verify Column_Last","verify Column_Last should present","verify Column_Last present");
			} else {
					failed("verify Column_Last","verify Column_Last should present","verify Column_Last not present");
			}
			}
			
			if(i==3){
				if(text.equals(input.get("Verify@Column_change").trim())){
					passed("verify Column_change","verify Column_change should present","verify Column_change  present");
			} else {
					failed("verify Column_change","verify Column_change should present","verify Column_change not present");
			}
			}
			if(i==4){
				if(text.equals(input.get("Verify@Column_%change").trim())){
					passed("verify Column_%change","verify Column_%change should present","verify Column_%change present");
			} else {
					failed("verify Column_%change","verify Column_%change should present","verify Column_%change not present");
			}
			}
			}
		
		uiDriver.checkElementPresent("PS_StockWatch.btnRefresh", 15000);
		
		//3. click("PS_StockWatch.btnRefresh")
		uiDriver.click("PS_StockWatch.btnRefresh");
		
		
		//4. click("PS_StockWatch.lnkEdit")
		uiDriver.click("PS_StockWatch.lnkEdit");
		
		uiDriver.switchToiFrame("marketInfoWidLen");
		
		//5. setValue("PS_StockWatch.lstYou_are_viewing", input.get("Select@You_are_viewing"))
		uiDriver.setValue("PS_StockWatch.lstYou_are_viewing", input.get("Select@You_are_viewing"));
		
		//6. setValue("PS_StockWatch.edtEnter_Symbol_or_Keyword", input.get("type@Enter_Symbol_or_Keyword"))
		uiDriver.setValue("PS_StockWatch.edtEnter_Symbol_or_Keyword", input.get("type@Enter_Symbol_or_Keyword"));
		
		//7. click("PS_StockWatch.btnAdd")
		uiDriver.click("PS_StockWatch.btnAdd");
		
		for(int i=1;i<=8;i++){
			String Check_header = uiDriver.getLocator("PS_StockWatch.eltCurrent_Pricetbl");
			Check_header = Check_header+"["+i+"]";	
			System.out.println(Check_header);
			String text= uiDriver.getWebElement(Check_header).getText();
			System.out.println(text);
			if(i==1){
				if(text.equals(input.get("Verify@Symbol").trim())){
					passed("verify Symbol","verify Symbol should present","verify Symbol present");
			} else {
					failed("verify Symbol","verify Symbol should present","verify Symbol not present");
			}
			}
			if(i==2){
				if(text.equals(input.get("Verify@CurrentPrice").trim())){
					passed("verify CurrentPrice","verify CurrentPrice should present","verify CurrentPrice present");
			} else {
					failed("verify CurrentPrice","verify CurrentPrice should present","verify CurrentPrice not present");
			}
			}
			
			if(i==3){
				if(text.equals(input.get("Verify@DayChagePrice").trim())){
					passed("verify DayChagePrice","verify DayChagePrice should present","verify DayChagePrice  present");
			} else {
					failed("verify DayChagePrice","verify DayChagePrice should present","verify DayChagePrice not present");
			}
			}
			if(i==4){
				if(text.equals(input.get("Verify@Volume").trim())){
					passed("verify Volume","verify Volume should present","verify Volume present");
			} else {
					failed("verify Volume","verify Volume should present","verify Volume not present");
			}
			}
			if(i==5){
				if(text.equals(input.get("Verify@EPS").trim())){
					passed("verify EPS","verify EPS should present","verify EPS present");
			} else {
					failed("verify EPS","verify EPS should present","verify EPS not present");
			}
			}
			if(i==6){
				if(text.equals(input.get("Verify@PERatio").trim())){
					passed("verify PERatio","verify PERatio should present","verify PERatio present");
			} else {
					failed("verify PERatio","verify PERatio should present","verify PERatio not present");
			}
			}
			if(i==7){
				if(text.equals(input.get("Verify@WeekRange").trim())){
					passed("verify WeekRange","verify WeekRange should present","verify WeekRange present");
			} else {
					failed("verify WeekRange","verify WeekRange should present","verify WeekRange not present");
			}
			}
			if(i==8){
				if(text.equals(input.get("Verify@Remove").trim())){
					passed("verify Remove","verify Remove should present","verify Remove present");
			} else {
					failed("verify Remove","verify Remove should present","verify Remove not present");
			}
			}
			}
		
		uiDriver.switchingToParentFrame();
		//8. click("PS_StockWatch.lnkMy_Portfolio")
		uiDriver.click("PS_StockWatch.lnkMy_Portfolio");
		
		
	}
	
	public void PS_SummaryTab(DataRow input, DataRow output) {
		//1. checkElementPresent("PS_SummaryTab.lnkSummary", 15000)
		uiDriver.checkElementPresent("PS_SummaryTab.lnkSummary", 15000);
		
		//2. click("PS_SummaryTab.lnkSummary")
		uiDriver.click("PS_SummaryTab.lnkSummary");
		
		//3. click("PS_SummaryTab.lnkNew_Documents")
		uiDriver.click("PS_SummaryTab.lnkNew_Documents");
		
		//4. click("PS_SummaryTab.lnkPortfolio_Summary")
		uiDriver.click("PS_SummaryTab.lnkPortfolio_Summary");
		
		//5. click("PS_SummaryTab.btnColumn_name")
		uiDriver.click("PS_SummaryTab.btnColumn_name");
		
	}
	
	public void PS_Verifications(DataRow input, DataRow output) {
		
		//1. Verify the explanation for astric symbol below the summary table
		uiDriver.verifyText("PS_Verifications.tbltext", input.get("Select@AstFooter"));
		
		//2. Verify the explanation for hash symbol  below the summary table.
		uiDriver.verifyText("PS_Verifications.elttext", input.get("Select@MulCurrFooter"));
		
		//3. checkElementPresent("PS_Verifications.btnRefresh_Prices", 15000)
		uiDriver.checkElementPresent("PS_Verifications.btnRefresh_Prices", 15000);
		
		//4. click("PS_Verifications.btnRefresh_Prices")
		uiDriver.click("PS_Verifications.btnRefresh_Prices");
		
		//5. click("PS_Verifications.eltTable")
		/*uiDriver.click("PS_Verifications.eltTable");*/
		
		//6. click("PS_Verifications.lnkHelp")
		uiDriver.click("PS_Verifications.lnkHelp");
		
		//7. check that the Questions & Answers is the default tab.
		uiDriver.checkElementPresent("PS_Verifications.eltQuestions", 15000);
		
		System.out.println("Question & Answers Element is present");
		//8. Verify that the Questions & Answers is the default tab and it contains Portfolio Summary Related Queries.
		uiDriver.verifyText("PS_Verifications.eltQuestions","Questions & Answers");
		
		System.out.println("Failed before this step");
		//9. Verify("PS_Verifications.btnTermTab")
		uiDriver.verifyText("PS_Verifications.btnTermTab","Terms");
		
		//10. Click("PS_Verifications.btnTermTab")
		uiDriver.click("PS_Verifications.btnTermTab");
		
		//11. click("PS_Verifications.lnkGo_to_Portfolio_Summary")
		uiDriver.javascriptClick("PS_Verifications.lnkGo_to_Portfolio_Summary");
		
		//12. click("PS_Verifications.lnkPrint")
		
		
		//13. select("PS_Verifications.lstAccount")
		uiDriver.checkElementPresentpro("PS_Verifications.lstAccount", 40);
		uiDriver.click("PS_Verifications.lstAccount");
		
		//14. Verify Account detail page.
		uiDriver.verifyText("PS_Verifications.eltAccount",input.get("Verify@AccountDetails"));
		
	}
	
	public void Forgot_Password(DataRow input, DataRow output) {
		
		uiDriver.launchApplication(input.get("Navigate@URL"));
		//1. Verify whether Forgot_Password link exists
		uiDriver.checkElementPresent("Forgot_Password.lnkForgot_Password", 15000);
		
		//2. Click on Forgot_Password Link
		uiDriver.javascriptClick("Forgot_Password.lnkForgot_Password");
		
	}
	
	public void Forgot_Password_PersonalInfo(DataRow input, DataRow output) {
		//1. Exists UserID
		uiDriver.checkElementPresentpro("Forgot_Password_PersonalInfo.edtUserID",15000);
		//2. Type Input in UserID field
		uiDriver.setValue("Forgot_Password_PersonalInfo.edtUserID", input.get("type@UserID"));
		
		//3. Type Input in Social_Security_Number field
		uiDriver.setValue("Forgot_Password_PersonalInfo.edtSocial_Security_Number", input.get("type@Social_Security_Number"));
		
		//4. Select Input from the MMM list
		uiDriver.setValue("Forgot_Password_PersonalInfo.lstMMM", input.get("Select@MMM"));
		
		//5. Type Input in DD field
		uiDriver.setValue("Forgot_Password_PersonalInfo.edtDD", input.get("type@DD"));
		
		//6. Type Input in Postal_Code field
		uiDriver.setValue("Forgot_Password_PersonalInfo.edtPostal_Code", input.get("type@Postal_Code"));
		
		//7. Type Input in YYYY field
		uiDriver.setValue("Forgot_Password_PersonalInfo.edtYYYY", input.get("type@YYYY"));
		
		/*//8. Type Input in User_ID field
		uiDriver.setValue("Forgot_Password_PersonalInfo.edtUser_ID", input.get("Type@User_ID"));
		
		//9. Type Input in Social_Security_Number field
		uiDriver.setValue("Forgot_Password_PersonalInfo.edtSocial_Security_Number", input.get("Type@Social_Security_Number#2"));
		
		//10. Type Input in Date_of_Birth field
		uiDriver.setValue("Forgot_Password_PersonalInfo.edtDate_of_Birth", input.get("Type@Date_of_Birth"));
		
		//11. Type Input in Postal_Code field
		uiDriver.setValue("Forgot_Password_PersonalInfo.edtPostal_Code", input.get("Type@Postal_Code#2"));*/
		
		//1. Verify whether Next link exists
		uiDriver.checkElementPresent("Forgot_Password_PersonalInfo.lnkNext", 5000);
				
		//2. Click on Next Link
		uiDriver.click("Forgot_Password_PersonalInfo.lnkNext");
		
		uiDriver.wait(2000);
		
		//12. Verify the text  Input in the Error_Message field for User ID
		
		if(!input.get("VerifyText@UserID").equals(""))
		{
		if (uiDriver.verifyText("Forgot_Password_PersonalInfo.eltError_Message", input.get("VerifyText@UserID"))) {
			passed("verifyText","verifyText should pass","verifyText UserID passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText UserID failed");
		}
		
		}
		
		if(!input.get("VerifyText@Social_Security_Number").equals(""))
		{
		if (uiDriver.verifyText("Forgot_Password_PersonalInfo.eltError_Message1", input.get("VerifyText@Social_Security_Number"))) {
			passed("verifyText","verifyText should pass","verifyText SSN passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText SSN failed");
		}
		}
		
		if(!input.get("VerifyText@Date").equals(""))
		{
		if (uiDriver.verifyText("Forgot_Password_PersonalInfo.eltError_Message2", input.get("VerifyText@Date"))) {
			passed("verifyText","verifyText should pass","verifyText Date passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText Date failed");
		}
		}
		
		if(!input.get("VerifyText@Postal_Code").equals(""))
		{
		if (uiDriver.verifyText("Forgot_Password_PersonalInfo.eltError_Message3", input.get("VerifyText@Postal_Code"))) {
			passed("verifyText","verifyText should pass","verifyText Date passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText Date failed");
		}
		}
		
	}
	
	public void ForgotPassword_NewPassword(DataRow input, DataRow output) {
		
		//1. Exists New_Password
		uiDriver.checkElementPresentpro("ForgotPassword_NewPassword.edtNew_Password", 10000);
		
		//uiDriver.click("ForgotPassword_NewPassword.edtNew_Password");
		//2. Type Input in New_Password field
		uiDriver.setValue("ForgotPassword_NewPassword.edtNew_Password", input.get("type@New_Password"));
		
		//uiDriver.click("ForgotPassword_NewPassword.edtNew_Password");
		//3. Type Input in Confirm_Password field
		uiDriver.setValue("ForgotPassword_NewPassword.edtConfirm_Password", input.get("type@Confirm_Password"));
		
		/*//4. Type Input in New_Password field
		uiDriver.setValue("ForgotPassword_NewPassword.edtNew_Password", input.get("Type@New_Password#2"));
		
		//5. Type Input in Confirm_Password field
		uiDriver.setValue("ForgotPassword_NewPassword.edtConfirm_Password", input.get("Type@Confirm_Password#2"));*/
		
		uiDriver.checkElementPresent("ForgotPassword_NewPassword.lnksubmit", 4000);
		uiDriver.click("ForgotPassword_NewPassword.lnksubmit");
		
		//6. Verify the text  Input in the Error_Message_BlankNewPassword field
		if(!input.get("VerifyText@Error_Message").equals("")){
		if (uiDriver.verifyText("ForgotPassword_NewPassword.eltError_Message", input.get("VerifyText@Error_Message"))) {
			passed("verifyText","verifyText should pass","verifyText passed");
		} else {
			failed("verifyText","verifyText should pass","verifyText failed");
		}
		}
		
		//7.Verify the text1 in Incorrect format of New_password
		if(!input.get("VerifyText@Error_Message").equals("")){
			if (uiDriver.verifyText("ForgotPassword_NewPassword.eltError_Message1", input.get("VerifyText@WrongFormat_NewPass"))) {
				passed("verifyText","verifyText should pass","verifyText passed");
			} else {
				failed("verifyText","verifyText should pass","verifyText failed");
			}
			}
		
		//8.Verify the text2 in Incorrect format of New_password
		if(!input.get("VerifyText@Error_Message").equals("")){
			if (uiDriver.verifyText("ForgotPassword_NewPassword.eltError_Message2", input.get("VerifyText@Rectify_NewPass"))) {
				passed("verifyText","verifyText should pass","verifyText passed");
			} else {
				failed("verifyText","verifyText should pass","verifyText failed");
			}
			}
		//8.Verify the text3 in Incorrect format of New_password
		if(!input.get("VerifyText@Error_Message").equals("")){
			if (uiDriver.verifyText("ForgotPassword_NewPassword.eltError_Message3", input.get("VerifyText@Rectify_ConfirmPass"))) {
				passed("verifyText","verifyText should pass","verifyText passed");
			} else {
				failed("verifyText","verifyText should pass","verifyText failed");
			}
			}
		
		//9.Verify the text4 in Blank format of New_password
		if(!input.get("VerifyText@Error_Message").equals("")){
			if (uiDriver.verifyText("ForgotPassword_NewPassword.eltError_Message4", input.get("VerifyText@Blank_ConfirmPass"))) {
				passed("verifyText","verifyText should pass","verifyText passed");
			} else {
				failed("verifyText","verifyText should pass","verifyText failed");
			}
			}
		
		//Verify Success message
		if(!input.get("VerifyText@SuccessMsg").equals("")){
			if (uiDriver.verifyText("ForgotPassword_NewPassword.Success_Message", input.get("VerifyText@SuccessMsg"))) {
				passed("verifyText","verifyText should pass","verifyText passed");
			} else {
				failed("verifyText","verifyText should pass","verifyText failed");
			}
			}
		
		/*String [] dataArray=uiDriver.sessionLog("QADRC160");
		System.out.println("Validating session log from database");
		
		System.out.println(dataArray[0]);
		if (dataArray[0].equals("117") ) {
			passed("Nav_Add_Accounts","Session log should match","sesion log is matched");
		} else {
			failed("Nav_Add_Accounts","Session log should match","sesion log is not matched");
		}
		//4. Verify Input innertext for Miscinfo_Infoaccessed WebElement
		if (dataArray[2].equals("chk2375@gmail.com") ) {
			passed("Nav_Add_Accounts","Session log should match","sesion log is matched");
		} else {
			failed("Nav_Add_Accounts","Session log should match","sesion log is not matched");
		}
		
		//click on back to sign in button
		uiDriver.checkElementPresent("Forgot_Password_NewPassword.lnkbacktosignin", 4000);
		uiDriver.click("ForgotPassword_NewPassword.lnkbacktosignin");*/
}
	
	
	public void Verify_ID_Not_Locked_NP_Page(DataRow input, DataRow output) {
		//1. Exists New_Password
		uiDriver.checkElementPresent("Verify_ID_Not_Locked_NP_Page.edtNew_Password", 15000);
		
		//2. Type Input in New_Password field
		uiDriver.setValue("Verify_ID_Not_Locked_NP_Page.edtNew_Password", input.get("type@New_Password"));
		
		//3. Type Input in Confirm_Password field
		uiDriver.setValue("Verify_ID_Not_Locked_NP_Page.edtConfirm_Password", input.get("type@Confirm_Password"));
		
		//4. Click on Submit Link
		uiDriver.click("Verify_ID_Not_Locked_NP_Page.lnkSubmit");
		
		/*//5. Type Input in New_Password field
		uiDriver.setValue("Verify_ID_Not_Locked_NP_Page.edtNew_Password", input.get("type@New_Password#2"));
		
		//6. Type Input in Confirm_Password field
		uiDriver.setValue("Verify_ID_Not_Locked_NP_Page.edtConfirm_Password", input.get("type@Confirm_Password#2"));
		
		//7. Click on Submit Link
		uiDriver.click("Verify_ID_Not_Locked_NP_Page.lnkSubmit");
		
		//8. Type Input in New_Password field
		uiDriver.setValue("Verify_ID_Not_Locked_NP_Page.edtNew_Password", input.get("type@New_Password#3"));
		
		//9. Type Input in Confirm_Password field
		uiDriver.setValue("Verify_ID_Not_Locked_NP_Page.edtConfirm_Password", input.get("type@Confirm_Password#3"));
		
		//10. Click on Submit Link
		uiDriver.click("Verify_ID_Not_Locked_NP_Page.lnkSubmit");
		
		//11. Type Input in New_Password field
		uiDriver.setValue("Verify_ID_Not_Locked_NP_Page.edtNew_Password", input.get("type@New_Password#4"));
		
		//12. Type Input in Confirm_Password field
		uiDriver.setValue("Verify_ID_Not_Locked_NP_Page.edtConfirm_Password", input.get("type@Confirm_Password#4"));
		
		//13. Click on Submit Link
		uiDriver.click("Verify_ID_Not_Locked_NP_Page.lnkSubmit");
		
		//14. Type Input in New_Password field
		uiDriver.setValue("Verify_ID_Not_Locked_NP_Page.edtNew_Password", input.get("type@New_Password#5"));
		
		//15. Type Input in Confirm_Password field
		uiDriver.setValue("Verify_ID_Not_Locked_NP_Page.edtConfirm_Password", input.get("type@Confirm_Password#5"));
		
		//16. Click on Submit Link
		uiDriver.click("Verify_ID_Not_Locked_NP_Page.lnkSubmit");
		
		//17. Type Input in Id_is_not_locked field (Field is not present in Application)
		//uiDriver.setValue("Verify_ID_Not_Locked_NP_Page.edtId_is_not_locked", input.get("Type@Id_is_not_locked"));
		*/
		
		if(!input.get("VerifyText@Error").equals("")){
			if (uiDriver.verifyText("Verify_ID_Not_Locked_NP_Page.eltError1", input.get("VerifyText@Error"))) {
				passed("verifyText","verifyText should pass","verifyText passed");
			} else {
				failed("verifyText","verifyText should pass","verifyText failed");
			}
			}
		
	}

	/**
	*Overriding toString() method of object class to print WMOnline
	*format string
	**/
	public String toString(){
		return "WMOnlineDriver";
	}
}
