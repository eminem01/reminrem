/******************************************************************************
$Id : WebUIDriver.java 3/3/2016 7:07:41 PM
Copyright 2016-2017 IGATE GROUP OF COMPANIES. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF IGATE GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND IGATE GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
 ******************************************************************************/

package cbfx.selenium;

import static cbf.engine.TestResultLogger.failed;
import static cbf.engine.TestResultLogger.passed;
import static cbf.engine.TestResultLogger.done;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;






import org.apache.poi.ss.formula.functions.Index;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Mouse;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.host.Popup;
import com.sun.jmx.snmp.Timestamp;


import cbfx.selenium.TableHandler;
import cbf.harness.Harness;
import cbf.plugin.PluginManager;
import cbf.utils.DataRow;
import cbf.utils.LogUtils;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbf.utils.StringUtils;
import cbfx.selenium.browsers.Browser;

/**
 * 
 * Extends BaseWebAppDriver and handles all the common functionalities for
 * webControls like setting the TextBox,Selecting an option in Dropdown ,etc..
 * 
 */

public class WebUIDriver {
	private static XSSFWorkbook wb;
	private static XSSFSheet Sheet1;
	/**
	 * Overloaded Constructor to initialize webdriver and selenium
	 * 
	 * @param parameters
	 *            webDriver: object of WebDriver selenium: object of
	 *            WebDriverBackedSelenium
	 */
	public WebUIDriver(Map parameters) {
		Map obj = (Map<String, Object>) Harness.GCONFIG.get("ObjectMap");
		objMap = (ObjectMap) PluginManager.getPlugin(
				(String) obj.get("plugin"), null);

		browser = (Browser) PluginManager.getPlugin(
				(String) parameters.get("plugin"),
				(Map<String, Object>) parameters.get("parameters"));
		this.th = new TableHandler(this);
	}
	//session log for  Change Address status page
		public String [] fetchsessionlogfromDB1(String string){
			String valueArray [] =new String[1];
			System.out.println("inside function");
			String dbUrl = "jdbc:sqlserver://yke0-q2k8n2\\in02;databaseName=DUBC0_DRCAccess";
			String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
			String query = "Select * from dbo.sessionlog where eventdatetime in(select MAX(eventdatetime) from dbo.sessionlog where userid = 'CSSTST62')";
			String user = "webuser";
			String password = "Apple2012";
			try {

				//Class.forName(dbClass);
				Class.forName(dbClass);
				System.out.println("dbclass--------------------");
				Connection con = DriverManager.getConnection (dbUrl,user,password);
				System.out.println(con);
				if(con!=null){
					System.out.println("***************************************************");
					System.out.println("Connection successfull");
				}
				else{
					System.out.println("***************************************************");
					System.out.println("Not connected");
				}
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(query);
				//System.out.println(rs);
				 while(rs.next()){
					//String dbtime = rs.getString(1);	
					String eventid = rs.getString("eventid");
					
					valueArray[0]=eventid;
					
					System.out.println(eventid);
					
					
				 }
					

					con.close();
					
			}
				catch(ClassNotFoundException e) {
					e.printStackTrace();
					}

					catch(SQLException e) {
					e.printStackTrace();
					}
			return valueArray;
		}
		public String getInnerHTMLText(String elementName) {

			String innerHTML = null;
			try {

				WebElement element = getControl(elementName);
				innerHTML = element.getAttribute("innerText");//innerText
				System.out.println(innerHTML);
				return innerHTML;
			}

			catch (Exception e) {
				logger.trace("Error: Caused getting the InnerText of WebElement \" "
						+ elementName + " \"");
				return innerHTML;
			}
		}

	public List<WebElement> getWebElements(String elementName) {
		List<WebElement> tableElement = null;
		try {
			
			tableElement = webDr.findElements(By.xpath(elementName));
			
		} catch (Exception e) {
			logger.handleError("Failed to get WebElements ", elementName);
		}
		return tableElement;
	}
	public int getColumnCount(String elementName) {
		int col_count1 = 0;

		try {
			col_count1 = getControl(elementName).findElements(
					By.tagName("th")).size();
		} catch (Exception e) {
			logger.handleError("Failed to get row count for ", elementName);
		}
		return col_count1;
	} 
	
	public Boolean ClickCell(String elementName, int row, int col) {
		WebElement tableElement = getControl(elementName);
		List<WebElement> tr_Collection = tableElement.findElements(By
				.tagName("tr"));
		int row_num = 0;
		
		try {
			for (WebElement trElement : tr_Collection) {

				if (row_num == row) {
					List<WebElement> td_collection = trElement.findElements(By
							.tagName("td"));

					if (td_collection.size() == 0) {
						td_collection = trElement
								.findElements(By.xpath("./th/a"));
						
					}
					 System.out.println(td_collection.get(col));
					 td_collection.get(col).click();

					break;
				}

				row_num++;
			}
		} catch (Exception e) {
			logger.handleError("Failed to Click Cell", tableElement,
					" ", e);
		}
		return true;
	}
	public boolean CheckTextInOption(List<String> element,String Text){
		int count=1;
		for(String option : element){
			if(option.contains(Text)) {
				count=0;
				break;
			} else {
				count++;
			}
		}
		if(count==0){
			return true;
		}
		else{
		 return  false;
		}	
	}
	public boolean jsClickxpath(String element){
		try{
			
			JavascriptExecutor js = (JavascriptExecutor) webDr;  
			js.executeScript("arguments[0].click();", getControl(element));
			return true;
		}
		catch(Exception e){
			logger.error("Unable to click element", element, e);
			return false;
		}

	}
	public void sendKeysEnter (String elementName) {
		try {
			WebElement element = getControl(elementName);
			element.sendKeys(Keys.ENTER);
			System.out.println("sendKeysEnter on Element:"+elementName);
			passed("sendKeysEnter on element "+elementName,"sendKeysEnter on element "+elementName+" should pass","sendKeysEnter on element "+elementName+" passed");
			
		} catch (Exception e) {
			logger.handleError("Failed to click on the element ", elementName,
					" ", e);
		}

	}

public void ApplicationSync1(){
	wait(5000);
}

public List<String> SelectQuestions(String elementName){
	List<String> questions=new ArrayList();
	String ques;
	String locator = getLocator(elementName);
	try {
		List<WebElement> tr_Collection = webDr.findElements(By.xpath(locator));
		System.out.println(tr_Collection);
		for(WebElement tr:tr_Collection)
		{
		ques=tr.getText().trim();	
		questions.add(ques);
		}
		
	} catch (Exception e) {
		logger.handleError("Failed to Click cell object for ", elementName," ", e);
		
	}
	return questions;
}

	public boolean switchToWindowParentWindow(String parentwindow) {
		try {
				webDr.switchTo().window(parentwindow);
					System.out.println("Inside Swtich window If loop");
					return true;
		} catch (Exception e) {
			logger.handleError("No child window is available to switch ", e);
		}
	return false;
}
	public void ClickXpath(String Xpath){
		WebElement Element = webDr.findElement(By.xpath(Xpath));
		Element.click();
	}
	public void createWord(String lines) throws IOException {
	    
	    //Blank Document
	    XWPFDocument document = new XWPFDocument();
	    //Write the Document in file system
	    FileOutputStream out = new FileOutputStream(
	            new File(lines+".docx"));

	    //create Paragraph
	    //XWPFParagraph paragraph = document.createParagraph();
	    //XWPFRun run = paragraph.createRun();
	    //run.setText("VK Number (Parameter): " + line + " here you type your text...\n");
	    //document.write(out);
	   
	    //Close document
	    out.close();
	   // System.out.println("createdWord" + "_" + line + ".docx" + " written successfully");
	}
	//session log 
		public String [] fetchsessionlogfromDB(){
			String valueArray [] =new String[1];
			System.out.println("inside function");
			String dbUrl = "jdbc:sqlserver://yke0-q2k8n2\\in02;databaseName=DUBC0_DRCAccess";
			String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
			String query = "Select * from dbo.sessionlog where eventdatetime in(select MAX(eventdatetime) from dbo.sessionlog where userid = 'CSSTST100')";
			String user = "webuser";
			String password = "Apple2012";
			try {

				//Class.forName(dbClass);
				Class.forName(dbClass);
				System.out.println("dbclass--------------------");
				Connection con = DriverManager.getConnection (dbUrl,user,password);
				System.out.println(con);
				if(con!=null){
					System.out.println("***************************************************");
					System.out.println("Connection successfull");
				}
				else{
					System.out.println("***************************************************");
					System.out.println("Not connected");
				}
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(query);
				//System.out.println(rs);
				 while(rs.next()){
					//String dbtime = rs.getString(1);
					String eventid = rs.getString("eventid");
					
					valueArray[0]=eventid;
					
					System.out.println(eventid);
					
					
				 }
					

					con.close();
					
			}
				catch(ClassNotFoundException e) {
					e.printStackTrace();
					}

					catch(SQLException e) {
					e.printStackTrace();
					}
			return valueArray;
		}
	private void openBrowser() {
		this.webDr = browser.openDriver();
		webDr.manage().window().maximize();
	}
	
public void ClickOnGivenCheckbox(String element,String checkboxtext){
		
		element=getLocator(element);
		element = element.replace("ChkBoxText", checkboxtext);
		if(!IsSelected(element)){
		webDr.findElement(By.xpath(element)).click();;}
			
	}
public void ClickOnGivenlinks(String element,String linkvalue){
	
	element=getLocator(element);
	element = element.replace("linkvalue", linkvalue);
	//if(!IsSelected(element)){
	webDr.findElement(By.xpath(element)).click();
		
}
public void ClickOnGivenwebradiogroups(String element,String radiovalue){
	
	element=getLocator(element);
	element = element.replace("radvalue", radiovalue);
	if(!IsSelected(element)){
	webDr.findElement(By.xpath(element)).click();;}
		
}

   /* public void openBrowser_IE(String url) {
        
        DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
        capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
        capabilities.setCapability("ignoreZoomSetting", true); 
        File file = new File("C:\\CafeNext\\BrowserDrivers\\IEDriverServer.exe");
        System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
        WebDriver driver = new InternetExplorerDriver(capabilities);
        driver.get(url);
        //this.webDr = browser.openDriver();
        driver.manage().window().maximize();
 }*/
    /*private void openBrowser() {
		this.webDr = browser.openDriver();
		webDr.manage().window().maximize();
	}
	private void openBrowser_IE(String url) {
		
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		capabilities.setCapability("ignoreZoomSetting", true); 
		File file = new File("C:\\CafeNext\\BrowserDrivers\\IEDriverServer.exe");
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		WebDriver driver = new InternetExplorerDriver(capabilities);
		driver.get(url);
		//this.webDr = browser.openDriver();
		driver.manage().window().maximize();
	}*/

	/**
	 * Launches the Application in the Browser
	 * 
	 * @param url
	 *            URL of the page to be opened.
	 */
	/*public void launchApplication(String url) {
		closeBrowsers();
		wait(5000);
		openBrowser_IE(url);

		try {
			//webDr.get(url);

			passed("Open " + " " + url, "Should open " + url, url + " "
					+ "opened successfully");

		} catch (Exception e) {

			failed("Open " + " " + url, "Should open " + url, url + " "
					+ "opened unsuccessfully");

			logger.handleError("Error while navigating to url " + url, e);

		}

	}*/

	/**
	 * Launches the Application in the Browser
	 * 
	 * @param url
	 *            URL of the page to be opened.
	 */
	public void launchApplication(String url) {
		closeBrowsers();
		openBrowser();
		webDr.get(url);	
		passed("URL launch","URL should launch successfully","URL launched successfully");
	}
	
	/**
	 * Navigates to the specified url in the browser
	 * 
	 * @param url
	 *            URL of the page to be opened.
	 */
	public void navigateToPage(String url) {
		try {
			webDr.get(url);
		} catch (Exception e) {
			logger.handleError("Error while navigating to url " + url, e);

		}

	}
	public boolean ClickUsername(String elementName){
		String name,username1;
			try {
				
				String locator = getLocator(elementName);
				List<WebElement> tr_Collection = webDr.findElements(By.xpath(locator));
				System.out.println(tr_Collection.size());
				for(int j=1;j<=tr_Collection.size();j++)
				{
					
						System.out.println(webDr.findElement(By.xpath(locator+"["+j+"]")).getText());
					
					WebElement AdvsrName=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]"));
					
					name=AdvsrName.getText();
					System.out.println(name);
					String array2[]= name.split(",");
					System.out.println(array2[0]);
					username1=array2[0];
					username1=array2[0];
					if(username1.toUpperCase().equals(username1)) 
					{	
						
						
						
						
						WebElement reportClick=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/a"));
						//reportClick.click();
						JavascriptExecutor js = (JavascriptExecutor) webDr;
						js.executeScript("arguments[0].click();", reportClick);
						//				groupClick.click();
						/*BackFromiFrame();
					BackFromiFrame();*/
						return true;			
					}

				}

				return false;
			} catch (Exception e) {
				logger.handleError("Failed to Click cell object for ", elementName," ", e);
				return false;
			}
		} 
	public Boolean listCount3(String elementName1,String ExpectedValue) {
		try{
		String locator1 = getLocator(elementName1);
		long Count = webDr.findElements(By.xpath(locator1)).size();
		if(Count==Integer.parseInt(ExpectedValue))
			return true;
		else
		return false;}catch (Exception e) {
			logger.handleError("Unable to find the element ", elementName1," ", e);
			return false;
		}
	} 
	public Boolean listCount(String elementName1,String elementName2,String elementName3,String ExpectedValue) {
		try{
		String locator1 = getLocator(elementName1),locator2 = getLocator(elementName2),locator3=getLocator(elementName3);
		long Count = webDr.findElements(By.xpath(locator1)).size()+webDr.findElements(By.xpath(locator2)).size();
		long Sum=Count+webDr.findElements(By.xpath(locator3)).size();
		if(Sum==Integer.parseInt(ExpectedValue))
			return true;
		else
		return false;}catch (Exception e) {
			logger.handleError("Unable to find the element ", elementName1, "or", elementName2," ", e);
			return false;
		}
	} 

public Boolean listCount2(String elementName1,String elementName2,String ExpectedValue) {
	try{
	String locator1 = getLocator(elementName1),locator2 = getLocator(elementName2);
	long Count = webDr.findElements(By.xpath(locator1)).size()+webDr.findElements(By.xpath(locator2)).size();
	if(Count==Integer.parseInt(ExpectedValue))
		return true;
	else
	return false;}catch (Exception e) {
		logger.handleError("Unable to find the element ", elementName1, "or", elementName2," ", e);
		return false;
	}
} 
	public int NoOfWindows(){
		int size = webDr.getWindowHandles().size();
		return size;
	}
	public boolean checkIfElementPresent(String elementName, int mSec) 
	{

		try 
		{
			webDr.manage().timeouts().implicitlyWait(mSec, TimeUnit.MILLISECONDS);
			WebElement element = getControl(elementName);

			if (element != null) 
			{
				return true;
			} 
			else 
			{
				return false;
			}
		} 
		catch (Exception e) 
		{
			logger.handleError("Error: Caused while Verifying the Presence of Element \" ", e);
			return false;
		}
	} 
	public boolean menuselection(String first,String second,String third){
		try 
		{
			int first1 = Integer.parseInt(first),second1 = Integer.parseInt(second),third1=Integer.parseInt(third);
			
			Actions actionObject = new Actions(webDr);
			for(int i=0;i<first1;i++){
			actionObject = actionObject.sendKeys(Keys.ARROW_DOWN); //ASSIGN the return or you lose this event.
			actionObject.perform();
			wait(2000);
			}
			pressEnter();
			//sendKey("enter");
			wait(5000);
			for(int i=0;i<second1;i++){
			actionObject = actionObject.sendKeys(Keys.ARROW_DOWN); //ASSIGN the return or you lose this event.
			actionObject.perform();
			wait(2000);
			}
			pressEnter();
			//sendKey("enter");
			wait(15000);
			for(int i=0;i<third1;i++){
				actionObject = actionObject.sendKeys(Keys.ARROW_DOWN); //ASSIGN the return or you lose this event.
				actionObject.perform();
				wait(2000);
				}
			pressEnter();
			//sendKey("enter");
			
			wait(3000);
			
			/*Actions builder = new Actions(webDr);
			WebElement item1 = getControl(element1);
			checkElementPresent(element1,3);
			builder.moveToElement(item1).build().perform();
			WebElement item2 = getControl(element2);
			checkElementPresent(element2,3);
			builder.moveToElement(item2).build().perform();
			wait(5000);
			WebElement item3 = getControl(element3);
			checkElementPresent(element3,3);
			builder.moveToElement(item3).build().perform();
			wait(5000);
			WebElement item4 = getControl(element4);
			checkElementPresent(element4,3);
			builder.moveToElement(item4).click().build().perform();
			wait(5000);*/
			
			return true;
		} 
		catch (Exception e) 
		{
			logger.handleError("Failed to select menu ", "", e);
			return false;
		}
	}
	
	public boolean menuselection1(String first,String second,String third){
		try{
		try 
		{
			if(!first.equals("")){
			switch (first) {
			case "New_Client":
				checkElementPresentpro("Home.New_Client", 20);
				wait(4000);
				javascriptClick("Home.New_Client");
				break;
			case "New_Account":
				checkElementPresentpro("Home.New_Account", 20);
				wait(4000);
				javascriptClick("Home.New_Account");
				break;
			case "ChangeRepIDs":
				checkElementPresentpro("Home.ChangeRepIDs", 20);
				wait(4000);
				javascriptClick("Home.ChangeRepIDs");
				break;
			}
			}
		}catch (Exception e) 
		{
			logger.handleError("Failed to select first menu item: "+first, "", e);
			return false;
		}
		try{
			if(!second.equals("")){
			switch (second) {
			case "Entity":
				checkElementPresentpro("Home.Entity", 20);
				wait(4000);
				ClickItemByAction("Home.Entity");
				//javascriptClick("Home.Entity");
				break;
			case "Person":
				checkElementPresentpro("Home.Person", 20);
				wait(4000);
				javascriptClick("Home.Person");
				break;
			case "RepChangeJob":
				checkElementPresentpro("Home.RepChangeJob", 20);
				wait(4000);
				javascriptClick("Home.RepChangeJob");
				break;
			case "Retirement":
				checkElementPresentpro("Home.Retirement", 20);
				wait(4000);
				javascriptClick("Home.Retirement");
				break;
			case "Entity_account":
				checkElementPresentpro("Home.Entity_account", 20);
				wait(4000);
				javascriptClick("Home.Entity_account");
				break;
			case "Education":
				checkElementPresentpro("Home.Education", 20);
				wait(4000);
				javascriptClick("Home.Education");
				break;
			case "Custodian":
				checkElementPresentpro("Home.Custodian", 20);
				wait(4000);
				javascriptClick("Home.Custodian");
				break;
			case "Joint":
				checkElementPresentpro("Home.Joint", 20);
				wait(4000);
				javascriptClick("Home.Joint");
				break;
			case "Individual":
				checkElementPresentpro("Home.Individual", 20);
				wait(4000);
				javascriptClick("Home.Individual");
				break;
			case "Sole_Proprietor":
				checkElementPresentpro("Home.Sole_Proprietor", 20);
				wait(4000);
				javascriptClick("Home.Sole_Proprietor");
				break;
				
			}
			}
		}catch (Exception e) 
		{
			logger.handleError("Failed to select second menu item: "+second, "", e);
			return false;
		}
		try{
			if(!third.equals("")){
			switch (third) {
			case "Business_Corporation":
				checkElementPresentpro("Home.Business_Corporation", 20);
				wait(4000);
				javascriptClick("Home.Business_Corporation");
				break;
			case "Business_Investment_Club":
				checkElementPresentpro("Home.Business_Investment_Club", 20);
				wait(4000);
				javascriptClick("Home.Business_Investment_Club");
				break;
			case "Business_Non_Profit":
				checkElementPresentpro("Home.Business_Non_Profit", 20);
				wait(4000);
				javascriptClick("Home.Business_Non_Profit");
				break;
			case "Business_Partnership":
				checkElementPresentpro("Home.Business_Partnership", 20);
				wait(4000);
				javascriptClick("Home.Business_Partnership");
				break;
			case "Estate":
				checkElementPresentpro("Home.Estate", 20);
				wait(4000);
				javascriptClick("Home.Estate");
				break;
			case "Government":
				checkElementPresentpro("Home.Government", 20);
				wait(4000);
				javascriptClick("Home.Government");
				break;
			case "Self_Trusted_Qualified_Plan":
				checkElementPresentpro("Home.Self_Trusted_Qualified_Plan", 20);
				wait(4000);
				javascriptClick("Home.Self_Trusted_Qualified_Plan");
				break;
			case "Custodial_Qualified_Plan":
				checkElementPresentpro("Home.Custodial_Qualified_Plan", 20);
				wait(4000);
				javascriptClick("Home.Custodial_Qualified_Plan");
				break;
			case "Decedent_IRA_DI":
				checkElementPresentpro("Home.Decedent_IRA_DI", 20);
				wait(4000);
				javascriptClick("Home.Decedent_IRA_DI");
				break;
			case "Held_Away_529_College_Savings_Plan":
				checkElementPresentpro("Home.Held_Away_529_College_Savings_Plan", 20);
				wait(4000);
				javascriptClick("Home.Held_Away_529_College_Savings_Plan");
				break;
			case "STQP_TO":
				checkElementPresentpro("Home.STQP_TO", 20);
				wait(4000);
				javascriptClick("Home.STQP_TO");
				break;
			case "Decedent_403b_DB":
				checkElementPresentpro("Home.Decedent_403b_DB", 20);
				wait(4000);
				javascriptClick("Home.Decedent_403b_DB");
				break;
			case "STQP_QP":
				checkElementPresentpro("Home.STQP_QP", 20);
				wait(4000);
				javascriptClick("Home.STQP_QP");
				break;
			case "Decedent_Custodial_Plan_DK":
				checkElementPresentpro("Home.Decedent_Custodial_Plan_DK", 20);
				wait(4000);
				javascriptClick("Home.Decedent_Custodial_Plan_DK");
				break;
			case "STQP_S4":
				checkElementPresentpro("Home.STQP_S4", 20);
				wait(4000);
				javascriptClick("Home.STQP_S4");
				break;
			case "SIMPLE_IRA_SR":
				checkElementPresentpro("Home.SIMPLE_IRA_SR", 20);
				wait(4000);
				javascriptClick("Home.SIMPLE_IRA_SR");
				break;
			case "Decedent_Roth_DO":
				checkElementPresentpro("Home.Decedent_Roth_DO", 20);
				wait(4000);
				javascriptClick("Home.Decedent_Roth_DO");
				break;
			case "Minor_IRA_MI":
				checkElementPresentpro("Home.Minor_IRA_MI", 20);
				wait(4000);
				javascriptClick("Home.Minor_IRA_MI");
				break;
			case "Minor_Roth_IRA_MR":
				checkElementPresentpro("Home.Minor_Roth_IRA_MR", 20);
				wait(4000);
				javascriptClick("Home.Minor_Roth_IRA_MR");
				break;
			case "Roth_IRA_RO":
				checkElementPresentpro("Home.Roth_IRA_RO", 20);
				wait(4000);
				javascriptClick("Home.Roth_IRA_RO");
				break;
			case "Segregated_IRA_RollOver_RR":
				checkElementPresentpro("Home.Segregated_IRA_RollOver_RR", 20);
				wait(4000);
				javascriptClick("Home.Segregated_IRA_RollOver_RR");
				break;
			case "Custodial_403b_Plan_KB":
				checkElementPresentpro("Home.Custodial_403b_Plan_KB", 20);
				wait(4000);
				javascriptClick("Home.Custodial_403b_Plan_KB");
				break;
			case "Sarsep_IRA_Employee_Employer_and_IRA_Contributions_IS":
				checkElementPresentpro("Home.Sarsep_IRA_Employee_Employer_and_IRA_Contributions_IS", 20);
				wait(4000);
				javascriptClick("Home.Sarsep_IRA_Employee_Employer_and_IRA_Contributions_IS");
				break;
			case "Sep_Plan_Employer_Contributions_Only_SP":
				checkElementPresentpro("Home.Sep_Plan_Employer_Contributions_Only_SP", 20);
				wait(4000);
				javascriptClick("Home.Sep_Plan_Employer_Contributions_Only_SP");
				break;
			case "Sarsep_Plan_Employee_and_Employer_Contributions_SS":
				checkElementPresentpro("Home.Sarsep_Plan_Employee_and_Employer_Contributions_SS", 20);
				wait(4000);
				javascriptClick("Home.Sarsep_Plan_Employee_and_Employer_Contributions_SS");
				break;
			case "Community_Property":
				checkElementPresentpro("Home.Community_Property", 20);
				wait(4000);
				javascriptClick("Home.Community_Property");
				break;
			case "CPW_ROS":
				checkElementPresentpro("Home.CPW_ROS", 20);
				wait(4000);
				javascriptClick("Home.CPW_ROS");
				break;
			case "Marital_Property_Wisconsin":
				checkElementPresentpro("Home.Marital_Property_Wisconsin", 20);
				wait(4000);
				javascriptClick("Home.Marital_Property_Wisconsin");
				break;
			case "MPW_ROS_Wisconsin":
				checkElementPresentpro("Home.MPW_ROS_Wisconsin", 20);
				wait(4000);
				javascriptClick("Home.MPW_ROS_Wisconsin");
				break;
			case "Tenants_in_Common":
				checkElementPresentpro("Home.Tenants_in_Common", 20);
				wait(4000);
				javascriptClick("Home.Tenants_in_Common");
				break;
			case "Tenants_by_Entirety":
				checkElementPresentpro("Home.Tenants_by_Entirety", 20);
				wait(4000);
				javascriptClick("Home.Tenants_by_Entirety");
				break;
			case "Tenants_Rights_of_Supervisorship":
				checkElementPresentpro("Home.Tenants_Rights_of_Supervisorship", 20);
				wait(4000);
				javascriptClick("Home.Tenants_Rights_of_Supervisorship");
				break;
			}
			}
		}catch (Exception e) 
		{
			logger.handleError("Failed to select third menu item: "+third, "", e);
			return false;
		}
			return true;
		} 
		catch (Exception e) 
		{
			logger.handleError("Failed to select menu ", "", e);
			return false;
		}
	}
	
	
	
		public boolean javascriptClick(String element){
			try{
				JavascriptExecutor js = (JavascriptExecutor) webDr;  
				js.executeScript("arguments[0].click();", getControl(element));
				passed("click on "+element, "click on "+element+" should pass", "click on "+element+" passed");
				return true;
			}
			catch(Exception e){
				logger.error("Unable to click element", element, e);
				return false;
			}

		}


	/**
	 * Checks whether page title matches or not
	 * 
	 * @param pageTitle
	 *            title of page opened
	 * @return true or false result
	 */
	public boolean checkPage(String pageTitle) {
		try {
			if (pageTitle.equals(webDr.getTitle())) 
			{
				return true;
			}
		} catch (Exception e) {
			logger.handleError(
					"Error in checking the page title: " + pageTitle, e);
		}
		return false;
	}

	/**
	 * Identifies the locator as needed by webDriver object
	 * 
	 * @param elementName
	 *            Name of the element whose locator is required
	 * @return Identified locator as Web Element
	 */

	public WebElement getControl(String elementName) {
		String actualLocator = getLocator(elementName);
		WebElement element = null;
		int index = 1;
		final By[] byCollection = { 
				By.xpath(actualLocator),
				By.className(actualLocator), By.cssSelector(actualLocator),
				By.tagName(actualLocator), By.linkText(actualLocator),
				By.id(actualLocator),By.name(actualLocator),
				By.id(actualLocator),
				By.partialLinkText(actualLocator) };

		for (By by : byCollection) {
			try {
				element = webDr.findElement(by);
				if (!element.equals(null)) {
					break;
				}
			} catch (Exception e) {
				if (index == byCollection.length) {
					logger.error("Unable to find element ", elementName, e);
				} else {
					index++;
					continue;
				}
			}
		}
		return element;
	}

	public String getLocator(String element) {
		String actualLocator = "";
		List<Map> pageLocators = objMap.ObjectMaps(element.split("\\.")[0]);
		for (Map locator : pageLocators) {
			if (locator.get("elementName").equals(element.split("\\.")[1])) {
				actualLocator = (String) locator.get("locator");
				break;
			}
		}
		return actualLocator;

	}
	/**
	 * Selects the first item from the drop down list
	 * 
	 * @param elementName
	 *            name of element
	 */
public void selectFirstItem(String elementName) {
		WebElement element = getControl(elementName);
		try {
			String type = element.getAttribute("type");
		if (type != null){
			if (type.equals("select-one")) {
				Select selectOption = new Select(element);
				selectOption.selectByIndex(1);
				logger.trace("Selected first item in " + elementName + "'");
				return;
				}
			}
		}catch (Exception e) {
			logger.handleError("Error while setting value on element " + elementName, e);
		}
}
	/**
	 * Sets the value to the specified UI Element
	 * 
	 * @param elementName
	 *            name of element
	 * @param value
	 *            value to be set on element
	 */
	public void setValue(String elementName, String value) {
		WebElement element = getControl(elementName);
		try {
			String type = element.getAttribute("type");
			if ((type.equals("text")) || type.equals("password")) {
				element.clear();
				element.sendKeys(value);
				logger.trace("Typed text '" + value
						+ "' in the input element '" + elementName + "'");
				passed("setting the value for" + " " + elementName + " ",
						"value" + " " + value + " " + "should set properly",
						"value" + " " + value + " " + "entered successfully");

				return;
			}

			if (type.equals("select-one")) {
				Select selectOption = new Select(element);
				System.out.println(value);
				selectOption.selectByVisibleText(value);
				
				logger.trace("Selected  " + value + "' in " + elementName + "'");
				passed("setting the value for" + " " + elementName + " ",
						"value" + " " + value + " " + "should set properly",
						"value" + " " + value + " " + "entered successfully");

				return;
			}

			if (type.equalsIgnoreCase("Calendar")) {
				setCalendar(element, value);
				passed("setting the value for" + " " + elementName + " ",
						"value" + " " + value + " " + "should set properly",
						"value" + " " + value + " " + "entered successfully");

				return;
			}
			if (element.getTagName().equalsIgnoreCase("textarea")) {
				element.clear();
				element.sendKeys(value);
				logger.trace("Typed text '" + value
						+ "' in the input element '" + elementName + "'");
				passed("setting the value for" + " " + elementName + " ",
						"value" + " " + value + " " + "should set properly",
						"value" + " " + value + " " + "entered successfully");

				return;
			}
			if (type.equals("")) {
				element.clear();
				element.sendKeys(value);
				logger.trace("Typed text '" + value
						+ "' in the input element '" + elementName + "'");
				return;
			}
			if ((type.equals("checkbox")) || type.equals("radio")) {
				element.click();
				logger.trace("Clicked on " + elementName);
				passed("setting the value for" + " " + elementName + " ",
						"value" + " " + value + " " + "should set properly",
						"value" + " " + value + " " + "entered successfully");

				return;

			} else {
				element.click();
				element.sendKeys(value);
				element.click();
				logger.trace("Clicked on " + elementName);
				return;
			}
		} catch (Exception e) {
			failed("setting the value for" + " " + elementName + " ", "value"
					+ " " + value + " " + "should set properly",
					"Failed to set value" + " " + value);

			logger.handleError("Error while setting value ," + value
					+ " on element " + elementName, e);

		}
	}

	/**
	 * Sets the value to the specified UI Element
	 * 
	 * @param elementName
	 *            name of element
	 * @param input
	 *            input datarow with UI properties
	 *            
	 *            
	 */
	
	public void setValueifdatanotpresent(String elementName, String value) {
					
					if (!"".equals(value)) {
					WebElement element = getControl(elementName);
					try {
						String type = element.getAttribute("type");

						if ((type.equals("text")) || type.equals("password")) {
							element.clear();
							element.sendKeys(value);
							logger.trace("Typed text '" + value
									+ "' in the input element '" + elementName + "'");
							passed("setting the value for" + " " + elementName + " ",
									"value" + " " + value + " " + "should set properly",
									"value" + " " + value + " " + "entered successfully");

							return;
						}

						if (type.equals("select-one")) {
							Select selectOption = new Select(element);
							System.out.println(value);
							selectOption.selectByVisibleText(value);
							
							logger.trace("Selected  " + value + "' in " + elementName + "'");
							passed("setting the value for" + " " + elementName + " ",
									"value" + " " + value + " " + "should set properly",
									"value" + " " + value + " " + "entered successfully");

							return;
						}

						if (type.equalsIgnoreCase("Calendar")) {
							setCalendar(element, value);
							passed("setting the value for" + " " + elementName + " ",
									"value" + " " + value + " " + "should set properly",
									"value" + " " + value + " " + "entered successfully");

							return;
						}
						if (element.getTagName().equalsIgnoreCase("textarea")) {
							element.clear();
							element.sendKeys(value);
							logger.trace("Typed text '" + value
									+ "' in the input element '" + elementName + "'");
							passed("setting the value for" + " " + elementName + " ",
									"value" + " " + value + " " + "should set properly",
									"value" + " " + value + " " + "entered successfully");

							return;
						}
						if (type.equals("")) {
							element.clear();
							element.sendKeys(value);
							logger.trace("Typed text '" + value
									+ "' in the input element '" + elementName + "'");
							return;
						}
						if ((type.equals("checkbox")) || type.equals("radio")) {
							element.click();
							logger.trace("Clicked on " + elementName);
							passed("setting the value for" + " " + elementName + " ",
									"value" + " " + value + " " + "should set properly",
									"value" + " " + value + " " + "entered successfully");

							return;

						} else {
							element.click();
							element.sendKeys(value);
							element.click();
							logger.trace("Clicked on " + elementName);
							return;
						}
					} catch (Exception e) {
						failed("setting the value for" + " " + elementName + " ", "value"
								+ " " + value + " " + "should set properly",
								"Failed to set value" + " " + value);

						logger.handleError("Error while setting value ," + value
								+ " on element " + elementName, e);

					}
					}
				} 

		public void enter(){
			Robot robot;
			try {
				robot = new Robot();
				robot.keyPress(KeyEvent.VK_ENTER);
			} catch (AWTException e) {
				logger.handleError("Failed to press enter", "",
						" ", e);
			}
			
		} 

	public void setValue(String elementName, DataRow input) {
		setValue(elementName, input.get("elementName"));
	}

	// TODO:Should be made as a plugin
	private void setCalendar(WebElement element, String value) {
		element.click();
		webDr.findElement(
				By.linkText(value.substring(0, value.indexOf("/")).toString()))
				.click();
	}

	/**
	 * Sets the value to all the locators on the specified page.
	 * 
	 * @param pageName
	 *            name of the page
	 * @param data
	 *            value to be set on page
	 */
	public void setValues(String pageName, Map data) {
		List<Map> resultMap = new ArrayList();
		resultMap = objMap.ObjectMaps(pageName);
		setValues(data, resultMap);
	}

	private void setValues(Map data, List<Map> uiElements) {
		String elementName = "";
		for (Map uiElement : uiElements) {
			elementName = ((String) uiElement.get("elementName"));

			if (data.containsKey(elementName)) {
				setValue(elementName, (String) data.get(elementName));
			}
		}
	}

	/**
	 * Gets the value of the specified element
	 * 
	 * @param elementName
	 *            whose value has to be obtained
	 */
	public String getValue(String elementName) {
		WebElement element = getControl(elementName);
		try {
			String type = element.getAttribute("type");
		if (type != null){
			if (type.equals("text") || type.equals("password")|| type.equals("label") || type.equals(null) || type.equals("")) {

				/*if (element.getText().equals(""))
					return getAttribute(elementName, "value");*/
				return element.getText();

			}
			if (type.equals("select-one")) {

				Select selectOption = new Select(element);
				return selectOption.getFirstSelectedOption().getText();

			}
			if (type.equals("checkbox") || type.equals("radio") ) {
				//element.click();
				if (element.isSelected()) {
					return "Yes";
				} else {
					return "No";
				}
			}
			}
		else {
			return element.getText();
		}
		} catch (Exception e) {
			logger.handleError("Error while getting value of element "
					+ elementName, e);
		}

		return null;
	}
	
	public String getElementText(String elementName) {
		String text = null;
		try {
			WebElement element = getControl(elementName);
			text = element.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	/**
	 * Clears the value of specified element
	 * 
	 * @param elementName
	 *            element to be cleared
	 */
	public boolean clear(String elementName) {
		try {
			getControl(elementName).clear();
			return true;
		} catch (Exception e) {
			logger.handleError("Failed to clear  " + elementName, e);
			return false;
		}

	}
	public void FocusAndClick(String elementName) {
		try {
			WebElement link = getControl(elementName);
			new Actions(webDr).moveToElement(link).click().perform();
			
			
		
		} catch (Exception e) {
			logger.handleError("Falied to focus on ", elementName, e);
			
		}

	}


	/**
	 * Navigates to the Menu
	 * 
	 * @param menuList
	 *            list of menu items
	 */
	public void navigateMenu(String menuList) {
		String[] aMenu;
		aMenu = menuList.split(",");
		try {
			for (int i = 0; i < aMenu.length; i++) {
				if (!(aMenu[i].matches(""))) {
					getControl(aMenu[i]).click();
					logger.trace("Clicked on menu: " + aMenu[i] + ".");
					waitForBrowserStability(1000);
				}
			}
		} catch (Exception e) {
			if (menuList.contains(","))
				menuList = menuList.replaceAll(",", "-->");
			logger.handleError("Failed while Navigating to  " + menuList);
		}
	}

	/**
	 * Checks the presence of element till timeout
	 * 
	 * @param elementName
	 *            name of the element
	 * @param timeInSec
	 *            time limit
	 * @return boolean result
	 */
	public boolean checkElementPresent(final String elementName, int timeInSec) {

		boolean result = false;

		try {
			ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver webDriver) {
					WebElement element = getControl(elementName);
					if (element != null) {
						return true;
					} else {
						return false;

					}
				}
			};

			Wait<WebDriver> wait = new WebDriverWait(webDr, timeInSec);
			try {
				result = wait.until(expectation);
			} catch (Exception e) {

			}
		} catch (Exception e) {

		}
		return result;
	}

	public boolean checkElementPresentXpath(final String elementName, int timeInSec) {

		boolean result = false;

		try {
			ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver webDriver) {
					WebElement element = webDr.findElement(By.xpath(elementName));
					if (element != null) {
						return true;

					} else {
						return false;

					}
				}
			};

			Wait<WebDriver> wait = new WebDriverWait(webDr, timeInSec);
			try {
				result = wait.until(expectation);
			} catch (Exception e) {

			}
		} catch (Exception e) {

		}
		return result;
	}
	
	/**
	 * Check for the presence of the specified text on page till timeout
	 * 
	 * @param text
	 *            text to be verified
	 * @param timeInSec
	 *            time-limit(in seconds)
	 * @return boolean Result
	 */
	public boolean checkTextOnPage(String text, int timeInSec) {
		boolean result = false;
		WebDriverWait waitForPage = new WebDriverWait(webDr,
				TimeUnit.MILLISECONDS.toSeconds(500));

		try {
			for (int second = 0;; second++) {
				if (second >= timeInSec * 10) {
					logger.trace("TimeOut for " + second);
					break;
				}
				if (webDr.findElement(By.tagName("body")).getText()
						.contains(text)) {
					result = true;
					break;
				}
				waitForPage.until(ExpectedConditions.visibilityOf(webDr
						.findElement(By.tagName("body"))));
			}
		} catch (Exception e) {
			logger.handleError(
					"Error: Caused while Verifying the Presence of Text \" "
							+ text + " \"", e);
		}
		return result;
	}

	/**
	 * Clicks on the specified element
	 * 
	 * @param elementName
	 *            element to be clicked
	 */

	public void click(String elementName) {
		try {		
			getControl(elementName).click();
			passed("click on Element "+elementName,"click on Element"+elementName+" should pass","click on Element"+elementName+" passed");
		} catch (Exception e) {
			logger.handleError("Failed to click on the element ", elementName,
					" ", e);
		}

	}

	
	public void clickLinkByJavaScript(String text)
	{
		JavascriptExecutor js = (JavascriptExecutor)webDr;
		String script = "return document.getElementsByTagName('a');";
		List<WebElement> elmts= (List<WebElement>) js.executeScript(script);
		System.out.println(elmts.size());
		for(WebElement ele : elmts){
			System.out.println(ele.getAttribute("text"));
		}
		
		WebElement found = (WebElement) js.executeScript("var found; var aTags=document.getElementsByTagName('a');for(var i=0;i<aTags.length;i++){if (aTags[i].textContent == '"+text+"') {found = aTags[i];break;}};return found;");
		System.out.println("Found...************"+found.getAttribute("text"));
		//js.executeScript("arguments[0].setAttribute('style,'border: solid 2px red'');", found);
		js.executeScript("arguments[0].click();", found);
	}
	/**
	 * Mouse overs on the specified menu and clicks on the sub menu.
	 * 
	 * @param menu
	 *            menu of the elements
	 * @param subMenu
	 *            element to be clicked
	 */

	public void mouseOverAndClick(String menu, String subMenu) {
		try {
			Mouse mouse = mouseOver(menu);
			Locatable hoverSubItem = (Locatable) getControl(subMenu);
			mouse = ((HasInputDevices) webDr).getMouse();
			mouse.click(hoverSubItem.getCoordinates());
			//mouse.mouseDown(hoverSubItem.getCoordinates());
		} catch (Exception e) {
			logger.handleError("Falied to click ", subMenu, " on", menu, " ", e);
		}
	}

	/**
	 * Mouse overs on the specified element
	 * 
	 * @param elementName
	 *            name of element
	 */

	public Mouse mouseOver1(String elementName) {
		try {
			WebElement link = getControl(elementName);
			Locatable hoverItem = (Locatable) link;
			Mouse mouse = ((HasInputDevices) webDr).getMouse();
			mouse.mouseMove(hoverItem.getCoordinates());
			mouse.mouseDown(hoverItem.getCoordinates());
			mouse.mouseUp(hoverItem.getCoordinates());
			return mouse;
		} catch (Exception e) {
			logger.handleError("Falied to hover on ", elementName, e);
			return null;
		}

	}

	/**
	 * Performs the drag and drop operation
	 * 
	 * @param fromLocator
	 *            Contains the locator of source element
	 * @param toLocator
	 *            Contains the locator of destination element
	 */
	public void dragAndDrop(String fromLocator, String toLocator) {
		try {
			WebElement from = getControl(fromLocator);
			WebElement to = getControl(toLocator);
			Actions builder = new Actions(webDr);
			Action dragAndDrop = builder.clickAndHold(from).moveToElement(to)
					.release(to).build();
			dragAndDrop.perform();
		} catch (Exception e) {
			logger.handleError("Failed to drag drop elements ", fromLocator,
					" , ", toLocator, " ", e);
		}
	}
	public void ClickonDynamic(String fromLocator, String toLocator,String value) {
		try {
			WebElement from = getControl(fromLocator);
			WebElement to = getControl(toLocator);
			//WebElement to = getControl(toLocator);
			Actions act = null;
			Actions actions = new Actions(webDr);
			//actions.moveToElement(from).click().doubleClick(to).build().perform();
			//moveToElement(from).click().
				act = actions.sendKeys(to, value);
				act.build().perform();
				
			
			act.sendKeys(Keys.ENTER).build().perform();
			
			//actions.moveToElement(to).click().build().perform();
			//dragAndDrop.perform();
		} catch (Exception e) {
			logger.handleError("Failed to drag drop elements ", fromLocator,
					" , ", toLocator, " ", e);
		}
	}
	public void Clickoninsert(String fromLocator, String toLocator,String value) {
		try {
			WebElement from = getControl(fromLocator);
			WebElement to = getControl(toLocator);
			//WebElement to = getControl(toLocator);
			Actions act = null;
			Actions actions = new Actions(webDr);
			//actions.moveToElement(from).click().doubleClick(to).build().perform();
			//moveToElement(from).click().
				act = actions.moveToElement(from).click().sendKeys(to, value);
				act.build().perform();
				
			
			act.sendKeys(Keys.ENTER).build().perform();
			
			//actions.moveToElement(to).click().build().perform();
			//dragAndDrop.perform();
		} catch (Exception e) {
			logger.handleError("Failed to drag drop elements ", fromLocator,
					" , ", toLocator, " ", e);
		}
	}
	
	/**
	 * Switch to another window
	 * 
	 * @param title
	 *            Contains title of the new window
	 * @return true or false
	 */
	public boolean switchToWindow(String title) {
		Set<String> availableWindows = webDr.getWindowHandles();
		if (availableWindows.size() >= 1) {
			try {
				for (String windowId : availableWindows) {
					System.out.println("Inside Switch window for loop");
					if (webDr.switchTo().window(windowId).getTitle()
							.equals(title))
						System.out.println("Inside Swtich window If loop");
						return true;
				}
			} catch (Exception e) {
				logger.handleError("No child window is available to switch ", e);
			}
		}
		return false;
	}
	
	public String getWindowID() {
		String availableWindows = webDr.getWindowHandle();
		System.out.println("getWindowID - Parent Window ID:"+availableWindows);
		return availableWindows;
	}
	
	public boolean switchToWindowByID(String parentWindowID) {
		Set<String> availableWindows = webDr.getWindowHandles();
		System.out.println("switchToWindowByID: availableWindows = "+availableWindows);
		if (availableWindows.size() >= 1) {
			try {
				for (String windowId : availableWindows) {
					System.out.println("Child Window IDs = "+windowId);
					if (!parentWindowID.equals(windowId)){
						System.out.println("Child Window ID Matched= "+windowId);
						webDr.switchTo().window(windowId);
						return true;
				}					
				}
			} catch (Exception e) {
				logger.handleError("No child window is available to switch ", e);
			}
		}
		return false;
	}
		
	public boolean switchToMultipleWindow(String WindowID) {
		Set<String> availableWindows = webDr.getWindowHandles();
		System.out.println("Available Window: availableWindows ");
		int count =1;
		
		if (availableWindows.size() >= 1) {
			try {
				for (String windowId : availableWindows) {					
					if (count ==1 ){
						webDr.switchTo().window(windowId);
						return true;
				}
					count++;
				}
			} catch (Exception e) {
				logger.handleError("No child window is available to switch ", e);
			}
		}
		return false;
	}
	
	/**
	 * Uploads a file
	 * 
	 * @param filePath
	 *            Contains path of the file to be uploaded
	 * @param browse
	 *            Contains locator of the browse button
	 * @param upload
	 *            locator of the upload button
	 */
	public void fileUpload(String filePath, String browse, String upload) {
		WebElement element = getControl(browse);
		try {
			element.sendKeys(filePath);
			if (upload != null) {
				click("upload");
			}
		} catch (Exception e) {
			logger.handleError("Invalid File Path: ", filePath, e);
		}

	}

	/**
	 * Invokes enter/tab/F5 key
	 * 
	 * @param keyEvent
	 *            key to be invoked
	 * 
	 */
	// TODO:Check for other useful key events
	public void sendKey(String keyEvent) {
		try {
			Robot key = new Robot();
			if (keyEvent.equalsIgnoreCase("enter")) {
				key.keyPress(KeyEvent.VK_ENTER);
				key.keyRelease(KeyEvent.VK_ENTER);
				waitForBrowserStability(1000);
				return;
			}
			if (keyEvent.equalsIgnoreCase("tab")) {
				key.keyPress(KeyEvent.VK_TAB);
				key.keyRelease(KeyEvent.VK_TAB);
				waitForBrowserStability(5000);
				return;
			}
			if (keyEvent.equalsIgnoreCase("F5")) {
				key.keyPress(KeyEvent.VK_F5);
				key.keyRelease(KeyEvent.VK_F5);
				waitForBrowserStability(1000);
				return;
				
			}
			if (keyEvent.equalsIgnoreCase("SPACE")){
				key.keyPress(KeyEvent.VK_SPACE);
				key.keyRelease(KeyEvent.VK_SPACE);
				waitForBrowserStability(1000);
				return;
			}
			if (keyEvent.equalsIgnoreCase("CTRL")){
				key.keyPress(KeyEvent.VK_CONTROL);
				key.keyRelease(KeyEvent.VK_CONTROL);
				waitForBrowserStability(1000);
				return;
			}
			if (keyEvent.equalsIgnoreCase("SHIFT")){
				key.keyPress(KeyEvent.VK_SHIFT);
				key.keyRelease(KeyEvent.VK_SHIFT);
				waitForBrowserStability(1000);
				return;
			}
			if (keyEvent.equalsIgnoreCase("SHIFTCTRLS")){
				key.keyPress(KeyEvent.VK_SHIFT);
				key.keyPress(KeyEvent.VK_CONTROL);
				key.keyPress(KeyEvent.VK_S);
				waitForBrowserStability(1000);
				key.keyRelease(KeyEvent.VK_SHIFT);
				key.keyRelease(KeyEvent.VK_CONTROL);
				key.keyRelease(KeyEvent.VK_S);
				waitForBrowserStability(1000);
				return;
			}
			if (keyEvent.equalsIgnoreCase("SHIFT")){
				key.keyPress(KeyEvent.VK_SHIFT);
				key.keyRelease(KeyEvent.VK_SHIFT);
				waitForBrowserStability(1000);
				return;
			}
			if (keyEvent.equalsIgnoreCase("ESC")){
				key.keyPress(KeyEvent.VK_ESCAPE);
				key.keyRelease(KeyEvent.VK_ESCAPE);
				waitForBrowserStability(1000);
				return;
			}
			if (keyEvent.equalsIgnoreCase("ALT+O")){
				key.keyPress(KeyEvent.VK_ALT);
                key.keyPress(KeyEvent.VK_N);
                key.keyRelease(KeyEvent.VK_O);
                key.keyRelease(KeyEvent.VK_ALT);
                waitForBrowserStability(1000);

				return;
			}
		} catch (AWTException e) {
			logger.handleError("Error caused while clicking on '", keyEvent, e);
		}
	}
	
	public boolean verifyText(String elementName, String expectedText) {
		System.out.println("Im inside verifyText function ");
		String actualText = getValue(elementName);
		System.out.println("Excpected : " + expectedText);
		System.out.println("Actual :  " + actualText);
		if (actualText.trim().equalsIgnoreCase(expectedText.trim())) {
			passed("verifyText", expectedText + " should match", expectedText + " is matched");
			return true;
		} else {
			failed("verifyText", expectedText + " should match", expectedText + " is not matched");
			return false;
		}
	}

	public boolean pressEnter() {
		try {
			Actions action = new Actions(webDr);
			action.sendKeys(Keys.ENTER).build().perform();	
			return true;
		}
		catch(Exception e) {
			failed("Press enter", "Enter should be pressed","Press Enter Failed");
			logger.handleError("Error while pressing enter", "Press enter"," ", e);
			return false;
		}

	}  
	
	/**
	 * Compares actual and expected text from the application
	 * 
	 * @param elementName
	 *            element for which text is to be checked
	 * @param expectedText
	 *            expected text
	 * @return boolean result
	 */
	
	public boolean verifyinnerText(String elementName, String expectedText) {
		System.out.println("Im inside verifyText function ");
		String actualText = getControl(elementName).getAttribute("innerText");
		System.out.println(actualText);
		if (actualText.equalsIgnoreCase(expectedText)) {
			return true;
		}
		return false;
	}
	public boolean switchFrameById(String ID)
	{
		try{
			webDr.switchTo().frame(ID);
		}
		catch(Exception e){
			logger.handleError("Unable to switch to main frame", e);
			return false;
		}
		return false;
	}

	public boolean switchingToParentFrame()
	{
		try{
			webDr.switchTo().defaultContent();
			}
		catch(Exception e){
			logger.handleError("Unable to switch to the main frame", e);
			return false;
		}
		return false;
	}

	/** 
	 * 
	 * @param frameName
	 * @return
	 */
	public void switchToiFrame(String frameName) {
		//WebElement element = webDr.findElement(By.id(frameName));
		WebElement element = webDr.findElement(By.name(frameName));
		webDr.switchTo().frame(element);		

		
		
	}
   public void switchToiFrameById(String frameName) {
		
		
		WebElement element = webDr.findElement(By.id(frameName));
		webDr.switchTo().frame(element);
		
	}
	
	
	public void switchToiFrame0() {
		webDr.switchTo().frame(0);
	}
	public void switchToiFrame(int Framenumber) {
		webDr.switchTo().frame(Framenumber);
	}
	
	public Boolean BackFromiFrame() {
		webDr.switchTo().defaultContent();		
		return true;
	}
	public boolean verifyString(String elementName, String expectedText) {
		String actualText = getValue(elementName);
		if (actualText.equalsIgnoreCase(expectedText)) {
			return true;
		}
		return false;
	}
	
	public boolean verifyStringContains(String elementName, String expectedText) {
		String actualText = getValue(elementName);
		if (actualText.contains(expectedText)) {
			return true;
		}
		return false;
	}
	
	public boolean verifyStringXpath(String Xpath, String expectedText) {
		String actualText = webDr.findElement(By.xpath(Xpath)).getText();
		if (actualText.equalsIgnoreCase(expectedText)) {
			return true;
		}
		return false;
	}
	
	/**
	 * Verify Tooltip's text
	 * 
	 * @param elementName
	 *            Give element for which tooltip is visible
	 * @param expected
	 *            expected tooltip text
	 */

	public void verifyTooltip(String elementName, String expected) {
		WebElement element = getControl(elementName);
		String str = null;
		try {
			if (!element.getAttribute("title").isEmpty()) {
				str = element.getAttribute("title");
				if (str.contains(expected)) {
					passed("verify tooltip: " + str + "for " + element,
							"Tooltip's text should match with " + str + "for "
									+ element, "Tooltip's text matches with "
									+ str + "for " + element);
				} else {
					failed("verify tooltip: " + str,
							"Tooltip's text should match with " + str,
							"Tooltip's text doesn't match with " + str);
				}
			} else {
				failed("verify tooltip: " + str + "for " + element, str
						+ " not Visible", "Tooltip" + str
						+ " is not visible for " + element);
			}
		} catch (Exception e) {
			logger.handleError("Error while verifying tool tip", e);
		}

	}
	
	public void setValueIfDataPresent(String elementName, String value) {
	    
	    if (!"".equals(value)) {
	    WebElement element = getControl(elementName);
	    try {
	           String type = element.getAttribute("type");
	           if(type!=null){
	           if ((type.equals("text")) || type.equals("password")) {
	                 element.clear();
	                 element.sendKeys(value);
	                 logger.trace("Typed text '" + value
	                               + "' in the input element '" + elementName + "'");
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;
	           }

	           if (type.equals("select-one")) {
	                 Select selectOption = new Select(element);
	                 selectOption.selectByVisibleText(value);
	                 logger.trace("Selected  " + value + "' in " + elementName + "'");
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;
	           }

	           if (type.equalsIgnoreCase("Calendar")) {
	                 setCalendar(element, value);
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;
	           }
	           if (element.getTagName().equalsIgnoreCase("textarea")) {
	                 element.clear();
	                 element.sendKeys(value);
	                 logger.trace("Typed text '" + value
	                               + "' in the input element '" + elementName + "'");
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;
	           }
	           if (type.equals("")) {
	                 element.clear();
	                 element.sendKeys(value);
	                 logger.trace("Typed text '" + value
	                               + "' in the input element '" + elementName + "'");
	                 return;
	           }
	           if ((type.equals("checkbox")) || type.equals("radio")) {
	                 element.click();
	                 logger.trace("Clicked on " + elementName);
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;

	           }} else {
	                 element.click();
	                 element.sendKeys(value);
	                 element.click();
	                 logger.trace("Clicked on " + elementName);
	                 return;
	           }
	    } catch (Exception e) {
	           failed("setting the value for" + " " + elementName + " ", "value"
	                        + " " + value + " " + "should set properly",
	                        "Failed to set value" + " " + value);

	           logger.handleError("Error while setting value ," + value
	                        + " on element " + elementName, e);

	    }
	    }
	} 
	
	public String getText(String xpath){
		WebElement ele;
		String Text = null;
		try {
			ele = webDr.findElement(By.xpath(xpath));
			Text = ele.getText();
			return Text;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
			logger.handleError("Falied to get Text ", xpath, e);
		}
		return Text;
	}
	public boolean containsIgnoreCase( String haystack, String needle ) {
		  if(needle.equals(""))
		    return true;
		  if(haystack == null || needle == null || haystack .equals(""))
		    return false; 

		  Pattern p = Pattern.compile(needle,Pattern.CASE_INSENSITIVE+Pattern.LITERAL);
		  Matcher m = p.matcher(haystack);
		  return m.find();
		}

	public void screenShot_selective() {
		try {
			done("ScreenShot capture", "ScreenShot should capture", "ScreenShot captured successfully");
			
		} catch (Exception e) {
			logger.handleError("Failed to take screenshots", e);
		}
	}
	
	public boolean ScrollMoveIntoViewByXpath(String elementName){
		try{	
			JavascriptExecutor js = (JavascriptExecutor) webDr;  
			js.executeScript("arguments[0].scrollIntoView();",getControl(elementName));
			return true;
		}
		catch(Exception e){
			logger.error("Unable to move to the element", elementName, e);
			return false;
		}
	}
	
	public void maximizemyWindow() {
		//Maximizing window to handle Unitrax Application, post security Page
		webDr.manage().window().maximize();
		}
	
	public boolean SelectAccountandremove(String elementName, String Firstcolumnvalue){

		try {
			/*NumOfIframes();
		switchToiFrame0();
		switchToiFrame0();*/
			String locator = getLocator(elementName);
			List<WebElement> tr_Collection = (List<WebElement>) webDr.findElements(By.xpath(locator));
			for(int j=1;j<=tr_Collection.size();j++)
			{
				WebElement Packetname=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[1]"));
				
				if(Packetname.getText().trim().equals(Firstcolumnvalue)) 
				{	
					WebElement Packetnamechkbx=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[8]/a"));
					Packetnamechkbx.click();
				
						return true;
					}
					//				groupClick.click();
					/*BackFromiFrame();
				BackFromiFrame();*/			
				}
			return false;
			}
	 catch (Exception e) {
			logger.handleError("Failed to find the report Packet ", elementName," ", e);
			return false;
		}
	}
	
	public boolean SelectID(String elementName, String AccountID){
		


		try {
			
			
			String locator = getLocator(elementName);
			List<WebElement> tr_Collection = webDr.findElements(By.xpath(locator));
		
			for(int j=0;j<tr_Collection.size();j++)
			{
				for(int k=3;k<=5;k++)
				{
					System.out.println(webDr.findElement(By.xpath(locator+"["+(j+1)+"]/td["+k+"]")).getText());
				}
				WebElement AccID=(WebElement) webDr.findElement(By.xpath(locator+"["+(j+1)+"]/td[5]"));
				
				WebElement AccName=(WebElement) webDr.findElement(By.xpath(locator+"["+(j+1)+"]/td[4]"));
				if(AccID.getText().trim().contains(AccountID) ) 
				{	
					WebElement reportClick=(WebElement) webDr.findElement(By.xpath(locator+"["+(j+1)+"]/td[3]/input"));
					JavascriptExecutor js = (JavascriptExecutor) webDr;
					js.executeScript("arguments[0].click();", reportClick);
					//				groupClick.click();
					/*BackFromiFrame();
				BackFromiFrame();*/
								
				}
				
			
		}
			return true;
		} catch (Exception e) {
			logger.handleError("Failed to Click cell object for ", elementName," ", e);
			return false;
		}
	}
	public String [] sessionLog(String Userid){
		String valueArray [] =new String[3];
		System.out.println("inside function");
		String dbUrl = "jdbc:sqlserver://yke0-q2k8n2\\in02;databaseName=DUBC0_DRCAccess";
		String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String query = "Select * from dbo.sessionlog where eventdatetime in(select MAX(eventdatetime) from dbo.sessionlog where userid = '"+Userid+"')";
		System.out.println(query);
		String user = "webuser";
		String password = "Apple2012";
		try {

			//Class.forName(dbClass);
			Class.forName(dbClass);
			System.out.println("dbclass--------------------");
			Connection con = DriverManager.getConnection (dbUrl,user,password);
			System.out.println(con);
			if(con!=null){
				System.out.println("***************************************************");
				System.out.println("Connection successfull");
			}
			else{
				System.out.println("***************************************************");
				System.out.println("Not connected");
			}
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			//System.out.println(rs);
			while(rs.next()){
				//String dbtime = rs.getString(1);	
				String eventid = rs.getString("eventid");
				String infoaccessed = rs.getString("infoaccessed");
				String miscinfo = rs.getString("miscinfo");

				valueArray[0]=eventid;
				valueArray[1]=infoaccessed;
				valueArray[2]=miscinfo;
				
				System.out.println(eventid);
				System.out.println(infoaccessed);
				System.out.println(miscinfo);

			}


			con.close();

		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}

		catch(SQLException e) {
			e.printStackTrace();
		}
		return valueArray;
	}
	//session log for  Change Address status page
			public String [] fetchsessionlogfromDB1(){
				String valueArray [] =new String[1];
				System.out.println("inside function");
				String dbUrl = "jdbc:sqlserver://yke0-q2k8n2\\in02;databaseName=DUBC0_DRCAccess";
				String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
				String query = "Select * from dbo.sessionlog where eventdatetime in(select MAX(eventdatetime) from dbo.sessionlog where userid = 'CSSTST62')";
				String user = "webuser";
				String password = "Apple2012";
				try {

					//Class.forName(dbClass);
					Class.forName(dbClass);
					System.out.println("dbclass--------------------");
					Connection con = DriverManager.getConnection (dbUrl,user,password);
					System.out.println(con);
					if(con!=null){
						System.out.println("***************************************************");
						System.out.println("Connection successfull");
					}
					else{
						System.out.println("***************************************************");
						System.out.println("Not connected");
					}
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery(query);
					//System.out.println(rs);
					 while(rs.next()){
						//String dbtime = rs.getString(1);	
						String eventid = rs.getString("eventid");
						
						valueArray[0]=eventid;
						
						System.out.println(eventid);
						
						
					 }
						

						con.close();
						
				}
					catch(ClassNotFoundException e) {
						e.printStackTrace();
						}

						catch(SQLException e) {
						e.printStackTrace();
						}
				return valueArray;
			}
			public void clickOnMultipleCheckBox(String elementName){
				String locator = getLocator(elementName);
				List<WebElement> tr_Collection = webDr.findElements(By.xpath(locator));
				for(WebElement element : tr_Collection)
				{
					element.click();
				}
				System.out.println(tr_Collection.size());
				
				
				
			}
	public void setValueIfDataPresentwithoutclear(String elementName, String value) {
	    
	    if (!"".equals(value)) {
	    WebElement element = getControl(elementName);
	    try {
	           String type = element.getAttribute("type");
	           
	           if ((type.equals("text")) || type.equals("password")) {
	                 //element.clear();
	        	  
	        	   	 element.click();	
	        	   	 if(value.length()>1){
	        	   		 for(int i=0;i<value.length();i++){
	        	   			 element.sendKeys(""+value.charAt(i));
	        	   		 }
	        	   	 }else{
	        	   		element.sendKeys(value);
	        	   	 }
	                 element.click();
	                 wait(2000);
	                 logger.trace("Typed text '" + value
	                               + "' in the input element '" + elementName + "'");
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;
	           }

	           if (type.equals("select-one")) {
	                 Select selectOption = new Select(element);
	                 selectOption.selectByVisibleText(value);
	                 logger.trace("Selected  " + value + "' in " + elementName + "'");
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;
	           }

	           if (type.equalsIgnoreCase("Calendar")) {
	                 setCalendar(element, value);
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;
	           }
	           if (element.getTagName().equalsIgnoreCase("textarea")) {
	                 element.clear();
	                 element.sendKeys(value);
	                 logger.trace("Typed text '" + value
	                               + "' in the input element '" + elementName + "'");
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;
	           }
	           if (type.equals("")) {
	                 element.clear();
	                 element.sendKeys(value);
	                 logger.trace("Typed text '" + value
	                               + "' in the input element '" + elementName + "'");
	                 return;
	           }
	           if ((type.equals("checkbox")) || type.equals("radio")) {
	                 element.click();
	                 logger.trace("Clicked on " + elementName);
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;

	           } else {
	                 element.click();
	                 element.sendKeys(value);
	                 element.click();
	                 logger.trace("Clicked on " + elementName);
	                 return;
	           }
	    } catch (Exception e) {
	           failed("setting the value for" + " " + elementName + " ", "value"
	                        + " " + value + " " + "should set properly",
	                        "Failed to set value" + " " + value);

	           logger.handleError("Error while setting value ," + value
	                        + " on element " + elementName, e);

	    }
	    }
	} 
	
	public void switchToiFrameByXpath(String elementName) {
		WebElement element = webDr.findElement(By.xpath(getLocator(elementName)));
		webDr.switchTo().frame(element);			
	}
	
	public void ScrollandsetValueIfDataPresent(String elementName, String value) {
	    
	    if (!"".equals(value)) {
	    WebElement element = getControl(elementName);
	    ScrollMoveIntoViewByXpath(elementName);
	    try {
	           String type = element.getAttribute("type");

	           if ((type.equals("text")) || type.equals("password")) {
	                 //element.clear();
	        	   	 element.click();	
	                 element.sendKeys(value);
	                 element.click();
	                 wait(2000);
	                 logger.trace("Typed text '" + value
	                               + "' in the input element '" + elementName + "'");
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;
	           }

	           if (type.equals("select-one")) {
	                 Select selectOption = new Select(element);
	                 selectOption.selectByVisibleText(value);
	                 logger.trace("Selected  " + value + "' in " + elementName + "'");
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;
	           }

	           if (type.equalsIgnoreCase("Calendar")) {
	                 setCalendar(element, value);
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;
	           }
	           if (element.getTagName().equalsIgnoreCase("textarea")) {
	                 element.clear();
	                 element.sendKeys(value);
	                 logger.trace("Typed text '" + value
	                               + "' in the input element '" + elementName + "'");
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;
	           }
	           if (type.equals("")) {
	                 element.clear();
	                 element.sendKeys(value);
	                 logger.trace("Typed text '" + value
	                               + "' in the input element '" + elementName + "'");
	                 return;
	           }
	           if ((type.equals("checkbox")) || type.equals("radio")) {
	                 element.click();
	                 logger.trace("Clicked on " + elementName);
	                 passed("setting the value for" + " " + elementName + " ",
	                               "value" + " " + value + " " + "should set properly",
	                               "value" + " " + value + " " + "entered successfully");

	                 return;

	           } else {
	                 element.click();
	                 element.sendKeys(value);
	                 element.click();
	                 logger.trace("Clicked on " + elementName);
	                 return;
	           }
	    } catch (Exception e) {
	           failed("setting the value for" + " " + elementName + " ", "value"
	                        + " " + value + " " + "should set properly",
	                        "Failed to set value" + " " + value);

	           logger.handleError("Error while setting value ," + value
	                        + " on element " + elementName, e);

	    }
	    }
	}

	//Select Radio button from group of radio buttons based on parameterised selection from Test Data Sheet
		public void selectRadioButton(String elementName, String value ) {
			try {
				String valuexpath = "[@value='" +value+ "']";
					
				String actualLocator = getLocator(elementName);
				actualLocator = actualLocator+valuexpath;
				WebElement element = null;
				int index = 1;
				final By[] byCollection = { By.xpath(actualLocator),
						By.id(actualLocator), By.name(actualLocator),
						By.className(actualLocator), By.cssSelector(actualLocator),
						By.tagName(actualLocator), By.linkText(actualLocator),
						By.partialLinkText(actualLocator) };

				for (By by : byCollection) {
					try {
						element = webDr.findElement(by);
						if (!element.equals(null)) {
							//element.click();
							jsClick(element);
							break;
						}
					} catch (Exception e) {
						if (index == byCollection.length) {
							logger.error("Unable to find element ", elementName, e);
						} else {
							index++;
							continue;
						}
					}
					
				}
				
				
			
				
				
			} catch (Exception e) {
				failed("click on element", " " + elementName + " " + "element"
						+ " " + elementName + " " + "should be clicked",
						"Failed to click on element" + " " + elementName);

				logger.handleError("Failed to click on the element ", elementName,
						" ", e);
			}

		}

	/**
	 * Verifies text in alert and clicks on either OK or cancel.
	 * 
	 * @param text
	 *            expected text
	 * @param button
	 *            "OK" or "Cancel" button
	 */

	public void handleAlert(String text, String button) {
		try {
			Alert alert = webDr.switchTo().alert();
			if (!text.equals("")) {
				String alerttext = alert.getText();
				if (alerttext.matches(text)) {
					passed("verify " + text + " in alert", text
							+ " should present in alert", text
							+ " is present in  alert");
				} else {
					failed("verify " + text + " in alert", text
							+ " should present in alert", text
							+ " is not present in  alert");
				}
			}
			if (button.equalsIgnoreCase("yes") || button.equalsIgnoreCase("ok")) {
				alert.accept();
			} else {
				alert.dismiss();
			}
		} catch (Exception e) {
			logger.handleError("Error while verifying text:" + text
					+ " in alert with button", button, e);
		}

	}

	/**
	 * Sets the text in the alert box
	 * 
	 * @param value
	 *            text to be set in alert box
	 */

	public void setTextInAlert(String value) {
		try {
			Alert alt = webDr.switchTo().alert();
			alt.sendKeys(value);
			alt.accept();
		} catch (Exception e) {
			logger.handleError("Failed to set text:" + value + " in alert", e);
		}

	}

	/**
	 * Gets the text from the alert box
	 * 
	 * @return String
	 */

	public String getAlertText() {
		try {
			Alert alt = webDr.switchTo().alert();
			return alt.getText();
		} catch (Exception e) {
			logger.handleError("Failed to get text from alert box", e);
			return null;
		}
	}

	/**
	 * Verify the presence of alert till timeout
	 * 
	 * @param TimeOutinSeconds
	 *            Give max time limit
	 * @return boolean
	 */

	public boolean isAlertPresent(int TimeOutinSeconds) {
		for (int i = 0; i < TimeOutinSeconds; i++) {
			try {
				Thread.sleep(500);
				webDr.switchTo().alert();
				return true;
			} catch (Exception e) {
				logger.handleError("Failed to verify presence of alert", e);
			}
		}
		return false;
	}

	public void handleAlertSelective(String text, String button) {
		try {
			 
			Alert alert = webDr.switchTo().alert();
			if (!text.equals("")) {
				String alerttext = alert.getText();
				if (alerttext.equalsIgnoreCase(text)) {
					passed("verify " + text + " in alert", text
							+ " should present in alert", text
							+ " is present in  alert");
				} else {
					failed("verify " + text + " in alert", text
							+ " should present in alert", text
							+ " is not present in  alert");
				}
			}
			if (button.equalsIgnoreCase("yes") || button.equalsIgnoreCase("ok")) {
				alert.accept();
				passed("Click on "+button+" button in Alert","Click on "+button+" button in Alert should pass",button+" button clicked successfully");
			} else {
				alert.dismiss();
			}
		} catch (Exception e) {
			logger.handleError("Error while verifying text:" + text
					+ " in alert with button", button, e);
		}

	}
	/**
	 * For highlighting an element
	 * 
	 * @param elementName
	 *            Locator
	 */

	public void drawHighlight(String elementName) {
		WebElement element = getControl(elementName);
		try {
			JavascriptExecutor js = ((JavascriptExecutor) webDr);
			js.executeScript("arguments[0].style.border='2px groove red'",
					element);
		} catch (Exception e) {
			logger.handleError("Failed to highlight element", elementName, " ",
					e);
		}

	}

	/**
	 * Retrieve drop down options
	 * 
	 * @param elementName
	 *            name of dropdown
	 * 
	 */
	public List<String> getDropDownOptions(String elementName) {
		List<String> optionsStr = new ArrayList<String>();
		WebElement element = getControl(elementName);
		try {
			List<WebElement> options = element.findElements(By
					.tagName("option"));

			for (WebElement option : options) {
				optionsStr.add(option.getText());

			}

		} catch (Exception e) {
			logger.handleError("Failed to get dropdown list for: ",
					elementName, " ", e);
		}

		return optionsStr;
	}

	/**
	 * checks the presence of specified options in the dropdown
	 * 
	 * @param elementName
	 *            name of element
	 * @param optionsStr
	 *            options to be checked with comma separated values
	 * 
	 * 
	 */
	public boolean checkDropDownOptions(String elementName, String optionsStr) {
		List<Object> flag = new ArrayList<Object>();
		List<String> dropDownOptions = getDropDownOptions(elementName);
		List<String> dropDownOptionsLowerCase = new ArrayList<String>();
		for (String temp : dropDownOptions) {
			dropDownOptionsLowerCase.add(temp.trim().toLowerCase());
		}
		String[] dropDownOptionsActList = optionsStr.split(",");
		try {
			for (int i = 0; i < dropDownOptionsActList.length; i++) {
				if (dropDownOptionsLowerCase.contains(dropDownOptionsActList[i]
						.trim().toLowerCase())) {
					flag.add(true);
				} else {
					flag.add(false);
				}
			}

		} catch (Exception e) {
			logger.handleError("Failed to verify option: ", optionsStr, "for ",
					elementName, " ", e);
		}
		if (flag.contains(false)) {
			return false;
		} else {

			return true;
		}
	}

	/**
	 * Checks the attribute value
	 * 
	 * @param elementName
	 *            name of element
	 * 
	 * @param attribute
	 *            attribute to be set
	 * @param value
	 *            value of the attribute
	 */

	public boolean checkAtttribute(String elementName, String attribute,
			String value) {
		String actualValue = getAttribute(elementName, attribute);
		if (value.equals(actualValue))
			return true;
		return false;
	}

	/**
	 * Sets the attribute value
	 * 
	 * @param elementName
	 *            name of element
	 * 
	 * @param attribute
	 *            attribute to be set
	 * @param value
	 *            value of the attribute
	 */
	public void setAttribute(String elementName, String attribute, String value) {
		try {
			WebElement element = getControl(elementName);
			JavascriptExecutor js = (JavascriptExecutor) webDr;
			js.executeScript(
					"arguments[0].setAttribute(arguments[1], arguments[2])",
					element, attribute, value);

		} catch (Exception e) {
			logger.handleError("Failed to set ", value, " for attribute ",
					attribute, " for the element ", elementName, " ", e);
		}
	}

	/**
	 * Gets the attribute value
	 * 
	 * @param elementName
	 *            name of element
	 * 
	 * @param attribute
	 *            attribute name
	 * */
	public String getAttribute(String elementName, String attribute) {
		WebElement element; 
		if (elementName.contains("//")){
			 element = webDr.findElement(By.xpath(elementName));
		}else{
			 element = getControl(elementName);
		}
		
		
		try {
			String value = element.getAttribute(attribute);
			return value;
		} catch (Exception e) {
			logger.handleError("Failed to get value for attribute ", attribute,
					" for the element ", elementName, " ", e);
			return null;
		}
	}

	/**
	 * Executes Javascript
	 * 
	 * @param script
	 *            script to be executed
	 **/
	public void executeJavaScript(String script) {
		try {
			JavascriptExecutor js = (JavascriptExecutor) webDr;
	     js.executeScript(script);
	      
			//js.executeScript("arguments[0].click();", script);
			SleepUtils.sleep(TimeSlab.YIELD);
  
		} catch (Exception e) {
			logger.handleError("Falied to execute ", script);
		}
	}

	/**
	 * For Double clicking on any element
	 * 
	 * @param elementName
	 *            name of element
	 */

	public void doubleclick(String elementName) {
		Actions axn = new Actions(webDr);
		try {
			axn.doubleClick(getControl(elementName)).build().perform();
		} catch (Exception e) {
			logger.handleError("Failed to double click on " + elementName, e);
		}
	}

	/**
	 * For right clicking on any element
	 * 
	 * @param elementName
	 *            name of element
	 */

	public void rightClick(String elementName, int option) {
		Actions action = new Actions(webDr);
		Actions act = null;
		for (int i = 0; i < option - 1; i++) {
			act = action.contextClick(getControl(elementName)).sendKeys(
					Keys.ARROW_DOWN);
			act.build().perform();
		}
		act.sendKeys(Keys.ENTER).build().perform();

	}

	/**
	 * Shut downs the webdriver
	 */
	public void closeBrowsers() {
		if (webDr != null)
			browser.closeDriver();
	}
	public void closeBrowser() {
			webDr.close();
	}

	/**
	 * Takes screenshot
	 */
	public File takescreenshot() {
		try {
			File scrFile = ((TakesScreenshot) webDr)
					.getScreenshotAs(OutputType.FILE);
			return scrFile;
		} catch (Exception e) {
			logger.handleError("Failed to take screenshots", e);
			return null;
		}
	}

	/**
	 * Clear cookies
	 */
	public void clearCookies() {
		try {
			webDr.manage().deleteAllCookies();
		} catch (Exception e) {

			logger.handleError("Failed to clear cookies", e);
		}
	}

	/**
	 * Check the running process and kill it
	 * 
	 * @param serviceName
	 *            Give name of the process that you want to kill
	 * @return Boolean
	 * @throws IOException
	 */

	public void killProcess(String serviceName) throws IOException {
		String line;
		Process p = Runtime.getRuntime().exec(
				System.getenv("windir") + "\\system32\\" + "tasklist.exe");
		BufferedReader input = new BufferedReader(new InputStreamReader(
				p.getInputStream()));
		try {
			while ((line = input.readLine()) != null) {
				if (line.contains(serviceName)) {
					Runtime.getRuntime().exec("taskkill /f /IM " + serviceName);
				}
			}
			input.close();
		} catch (Exception e) {
			logger.handleError("Failed to kill ", serviceName, e);

		}
	}

	/**
	 * Checks whether the page is loaded or not
	 * 
	 * @param maxTimeInSec
	 *            time to wait(In seconds)
	 * @return boolean result
	 */
	public boolean waitForBrowserStability(int timeout) {
		boolean bResult = false;
		int secsWaited = 0;
		try {
			do {
				Thread.sleep(100);
				secsWaited++;
				if (isBrowserLoaded()) {
					bResult = true;
					break;
				}
			} while (secsWaited < (timeout * 10));
			Thread.sleep(100);
		} catch (Exception e) {
			logger.handleError("Error while waiting for the page to load ", e);
			bResult = false;
		}
		return bResult;
	}

	/**
	 * Checks if body of the page is loaded or not
	 * 
	 * @return Boolean Result
	 */
	public boolean isBrowserLoaded() {
		boolean isBrowserLoaded = false;
		try {
			long timeOut = 5000;
			long end = System.currentTimeMillis() + timeOut;

			while (System.currentTimeMillis() < end) {

				if (String.valueOf(
						((JavascriptExecutor) webDr)
								.executeScript("return document.readyState"))
						.equals("complete")) {
					isBrowserLoaded = true;
					break;
				}
			}
		} catch (Exception e) {
			logger.handleError("Failed to check for the browser to load", e);
		}
		return isBrowserLoaded;
	}

	public void wait(int mS) {
		try {
			Thread.sleep(mS);
		} catch (Exception e) {
			logger.handleError("Error in synchronization", e);
		}

	}
	/*
	 * Added all TABLE related functions here from TableHandle.java file
	 */
	public WebElement getWebElement(String elementName) {
		WebElement tableElement = null;
		try {
			
			tableElement = getControl(elementName);
			
		} catch (Exception e) {
			logger.handleError("Failed to get WebElement ", elementName);
		}
		return tableElement;
	}
	
	public String getCellData(String elementName, int row, String colName) {
		WebElement tableElement = getWebElement(elementName);
		List<WebElement> tr_Collection = tableElement.findElements(By
				.tagName("tr"));
		int row_num = 0;
		int col_num = 0;
		String Data = null;
		try {
			for (WebElement trElement : tr_Collection) {
				if (row_num == 0) {
					List<WebElement> td_col = trElement.findElements(By
							.tagName("td"));
					if (td_col.size() == 0) {
						td_col = trElement.findElements(By.tagName("th"));
					}
					for (int i = 0; i < td_col.size(); i++) {
						if (td_col.get(i).getText().contains(colName)) {
							col_num = i;
							break;
						}
					}
				}

				if (row_num == row) {
					List<WebElement> td_collection = trElement.findElements(By
							.tagName("td"));
					Data = td_collection.get(col_num).getText();
					break;
				}

				row_num++;
			}
		} catch (Exception e) {
			logger.handleError("Failed to get cell data for ", tableElement,
					" ", e);
		}
		return Data;

	}	
	
	public int getRowCount(String elementName) {
	int row_count = 0;
	try {
		row_count = getWebElement(elementName).findElements(
				By.tagName("tr")).size();

	} catch (Exception e) {
		logger.handleError("Failed to get row count for ", elementName);
	}
	return row_count;
}
	public String getCellData(String elementName, int row, int col) {
		WebElement tableElement = getWebElement(elementName);
		List<WebElement> tr_Collection = tableElement.findElements(By
				.tagName("tr"));
		int row_num = 0;
		String Data = null;
		try {
			for (WebElement trElement : tr_Collection) {

				if (row_num == row) {
					List<WebElement> td_collection = trElement.findElements(By
							.tagName("td"));

					if (td_collection.size() == 0) {
						td_collection = trElement
								.findElements(By.tagName("th"));
					}
					Data = td_collection.get(col).getText();

					break;
				}

				row_num++;
			}
		} catch (Exception e) {
			logger.handleError("Failed to get cell data for ", tableElement,
					" ", e);
		}
		return Data;
	}

	//New function added - to click on respective row and click on 1st column - CRS Project
	public void clickOnCell(String elementName) {
		
		WebElement tableElement = getWebElement(elementName);
		int row_num_size = getRowCount(elementName);
		String actualdata = "Resolved-Completed";
		try {
			for (int i = 2; i <= row_num_size; i++) {
				String cellDataValue = getCellData(elementName, i, "Status");
				if(!actualdata.trim().equals(cellDataValue.trim())){	
					System.out.println("Status Data Value:"+cellDataValue);
					int j=i+1;
					String radiobuttonpath = "//*[@id='ViewTable']/tbody/tr["+j+"]/td[1]/input";					
					WebElement element = webDr.findElement(By.xpath(radiobuttonpath));
					System.out.println(element);
					element.click();					
					break;
				}
			}
		}catch (Exception e) {
			logger.handleError("Failed to get cell data for ", tableElement,
					" ", e);
		}
	}
	
	
	public void verifyDataInTable(String elementName, String caseIDTaskID) {

		List<WebElement> myList = new ArrayList<WebElement>();	
		myList = webDr.findElements(By.xpath("//*[@id='navMiddle']/table/tbody/tr/td"));	

		int noOfPage = myList.size();
		int result = 0;

		try {
			for(int np = 1; np <noOfPage-1; np++ ){	
				int value = 0;	

				int row_num_size = getRowCount(elementName);
				for (int i = 1; i <= row_num_size-1; i++) {

					String cellDataValue = getCellData(elementName, i, 6);
					System.out.println("Checking...caseID & TaskID Value... "+cellDataValue);

					if((cellDataValue.trim()).equalsIgnoreCase(caseIDTaskID.trim())){	
						logger.trace("caseIDTaskID Value is Available in Table: "+caseIDTaskID);	
						System.out.println("caseIDTaskID Value is Available in Table: "+caseIDTaskID);					
						value++; result++;
						break;
					}		
				}
				if (value == 1){
					break;	}
				else{WebElement nextbutton = webDr.findElement(By.xpath("//a[@title='Next Page']"));
						nextbutton.click();
						wait(5000);}
				}
			if (result != 0){
				passed("caseIDTaskID", caseIDTaskID+"--Value should available in Table", "Value is Available in Table");}
			else {
				failed("caseIDTaskID", caseIDTaskID+"--Value should available in Table", "Value is NOT Available in Table");}
		}catch (Exception e) {
			logger.handleError("Failed to verify Data in Table ", myList,
					" ", e);
		}
	}
	
public void clickonelement(String elementType,String elementName){
		
		String target = "//"+elementType+"[text()='"+elementName+"']";
		
		WebElement element = webDr.findElement(By.xpath(target));
		element.click();
		
	} 

public boolean switchToWindowByID(String parentWindowID,String windowid) {
    Set<String> availableWindows = webDr.getWindowHandles();
    System.out.println("switchToWindowByID: availableWindows = "+availableWindows);
    if (availableWindows.size() >= 1) {
           try {
                 for (String windowId : availableWindows) {
                        System.out.println("Child Window IDs = "+windowId);
                        if (!parentWindowID.equals(windowId) && !windowid.equals(windowId)){
                               System.out.println("Child Window ID Matched= "+windowId);
                               webDr.switchTo().window(windowId);
               
                               return true;
                 }                                 
                 }
           } catch (Exception e) {
                 logger.handleError("No child window is available to switch ", e);
           }
    }
    return false;
}

public boolean switchToWindowNumber(int windowNumber) {
	Set<String> availableWindows = webDr.getWindowHandles();
	if (availableWindows.size() >= 1) {
		try {
			int i=1;
			for (String windowId : availableWindows) {
				if(windowNumber==i){
					webDr.switchTo().window(windowId);
					return true;
				}
				i++;
			}
			return false;
		} catch (Exception e) {
			logger.handleError("No child window is available to switch ", e);
		}
	}

	return false;
}

public boolean closeWindow(int windowNumber) {
	Set<String> availableWindows = webDr.getWindowHandles();
	if (availableWindows.size() >=1) {
		try {
			int i=1;
			for (String windowId : availableWindows) {
				if(windowNumber==i){
					webDr.switchTo().window(windowId).close();;
					return true;
				}
				i++;
			}
			return false;
		} catch (Exception e) {
			logger.handleError("No child window is available to switch ", e);
		}
	}

	return false;
} 

public void AppSync() throws InterruptedException{
	Thread.sleep(5000);
}

public void ClickIEContinueWebsite(){
	webDr.navigate().to("javascript:document.getElementById('overridelink').click()");
	
}
public void PerformSendkeysWithXpath(String elementName , Keys key){
	if (elementName.contains("//")){
		WebElement element = webDr.findElement(By.xpath(elementName));
		element.sendKeys(key);
	}else{
		WebElement element = getControl(elementName);
		element.sendKeys(key);
	}
	//if (key.toUpperCase().contains("ENTER")){
	
		//webDr.findElement(By.xpath(elementName)).sendKeys(key);
	//	element.sendKeys(Keys.ENTER);
	//}
	//else if(key.toUpperCase().contains("TAB")){
		//element.sendKeys(Keys.TAB);
	//}
	
	
}

public void ClickItemByJs(String elementname) {
	WebElement element = getControl(elementname);
	JavascriptExecutor js = (JavascriptExecutor) webDr;
	js.executeScript("arguments[0].click();", element);
	System.out.println("Clicked on "+elementname);
	
	//Actions actions = new Actions(webDr);
	//actions.moveToElement(element).click().build().perform();
}
public boolean isDisabled(String elementName){
	WebElement element = getControl(elementName);
	Boolean Bool =  (!element.isEnabled());
	return Bool;
}
public boolean clickInvestnow(String elementName,String Status,String Name){
String name;
String username1;
	try {
		
		String locator = getLocator(elementName);
		List<WebElement> tr_Collection = webDr.findElements(By.xpath(locator));
		System.out.println(tr_Collection.size());
		for(int j=0;j<=tr_Collection.size();j++)
		{
			for(int k=1;k<4;k++)
			{
				
				System.out.println(webDr.findElement(By.xpath(locator+"["+(j+1)+"]/td["+k+"]")).getText());
			}
			WebElement Name1=(WebElement) webDr.findElement(By.xpath(locator+"["+(j+1)+"]/td[1]"));
			//WebElement Amt=(WebElement) webDr.findElement(By.xpath(locator+"["+(j+1)+"]/td[2]"));
			WebElement stats=(WebElement) webDr.findElement(By.xpath(locator+"["+(j+1)+"]/td[3]"));
			if(stats.getText().trim().contains(Status) & Name1.getText().trim().contains(Name)) 
			{	
				WebElement reportClick=(WebElement) webDr.findElement(By.xpath(locator+"["+(j+1)+"]/td[3]/a"));
				//reportClick.click();
				JavascriptExecutor js = (JavascriptExecutor) webDr;
				js.executeScript("arguments[0].click();", reportClick);
				//				groupClick.click();
				/*BackFromiFrame();
			BackFromiFrame();*/
				return true;		
			}

		}

	
			
			
		

		return false;
	} catch (Exception e) {
		logger.handleError("Failed to Click cell object for ", elementName," ", e);
		return false;
	}
}  
public void setValueDropDown(String elementName, String value) {
	WebElement element = getControl(elementName);
	try {
		String type = element.getAttribute("type");

		if ((type.equals("text")) || type.equals("password")) {

			element.sendKeys(value);
			element.click();
			logger.trace("Typed text '" + value
					+ "' in the input element '" + elementName + "'");
			passed("setting the value for" + " " + elementName + " ",
					"value" + " " + value + " " + "should set properly",
					"value" + " " + value + " " + "entered successfully");

			return;
		}

		if (type.equals("select-one")) {
			Select selectOption = new Select(element);
			selectOption.selectByVisibleText(value);
			logger.trace("Selected  " + value + "' in " + elementName + "'");
			passed("setting the value for" + " " + elementName + " ",
					"value" + " " + value + " " + "should set properly",
					"value" + " " + value + " " + "entered successfully");

			return;
		}

		if (type.equalsIgnoreCase("Calendar")) {
			setCalendar(element, value);
			passed("setting the value for" + " " + elementName + " ",
					"value" + " " + value + " " + "should set properly",
					"value" + " " + value + " " + "entered successfully");

			return;
		}
		if (element.getTagName().equalsIgnoreCase("textarea")) {
			element.clear();
			element.sendKeys(value);
			logger.trace("Typed text '" + value
					+ "' in the input element '" + elementName + "'");
			passed("setting the value for" + " " + elementName + " ",
					"value" + " " + value + " " + "should set properly",
					"value" + " " + value + " " + "entered successfully");

			return;
		}
		if (type.equals("")) {
			element.clear();
			element.sendKeys(value);
			logger.trace("Typed text '" + value
					+ "' in the input element '" + elementName + "'");
			return;
		}
		if ((type.equals("checkbox")) || type.equals("radio")) {
			element.click();
			logger.trace("Clicked on " + elementName);
			passed("setting the value for" + " " + elementName + " ",
					"value" + " " + value + " " + "should set properly",
					"value" + " " + value + " " + "entered successfully");

			return;

		} else {
			element.click();
			element.sendKeys(value);
			element.click();
			logger.trace("Clicked on " + elementName);
			return;
		}
	} catch (Exception e) {
		failed("setting the value for" + " " + elementName + " ", "value"
				+ " " + value + " " + "should set properly",
				"Failed to set value" + " " + value);

		logger.handleError("Error while setting value ," + value
				+ " on element " + elementName, e);

	}
}


public void scrollDown(int i){
	for(int c=1;c<=i;c++){
		Actions action = new Actions(webDr);
		action.sendKeys(Keys.ARROW_DOWN).perform(); //ASSIGN the return or you lose this event.
	}
}
public void navigateToURL(String URL)
{
	try
	{
		webDr.get(URL);
	}
	catch(Exception e)
	{
		logger.handleError("Failed to navigate to the URL", URL," ", e);
	}
}
public Actions actionClass()
{

	Actions actions = null;
	try
	{
		actions = new Actions(webDr);
		return actions;
	}
	catch(Exception e)
	{
		logger.handleError("Failed to return action instance ",actions," ", e);
		return actions;
	}
}
 


public void validateStatus(String elementName,String Value,String status)
{
	String val;
	try{
	String element = getLocator(elementName);
	WebElement ele= webDr.findElement(By.xpath(element+"//small[text()='"+Value+"']"));
	if(ele!=null){
    val = webDr.findElement(By.xpath(element+"//small[text()='"+Value+"']/../../td[3]/a")).getText();
    if(val.equalsIgnoreCase(status))
    passed("expected status  "+status,"expected status"+status+" should match","actual status"+val+" passed");	
	else
		failed("expected status  "+status,"expected status "+status+" should match","actual status "+val+" failed");	
	}
	}
	catch (Exception e) {
			logger.handleError("Failed to find the element ", elementName," ", e);
		
		}

	
	
}
public void Application_sync()
{
	try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}


public static void HoverAndClick(WebDriver uidriver,WebElement elementToHover,WebElement elementToClick) {
	Actions action = new Actions(uidriver);
	action.moveToElement(elementToHover).click(elementToClick).build().perform();
}

public boolean scrollToView(String element){
	try{
		Actions action = new Actions(webDr);
		action.moveToElement(getControl(element));
		passed("Move to element", "Move to element", "Move to element passed");
		return true;
	}
	catch(Exception e){
		logger.error("Unable to scroll to element", element, e);
		return false;
	}
}

public void ClickItemByAction(String elementname) {
//	WebElement element = getControl(elementname);
//	Actions actions = new Actions(webDr);
//	actions.moveToElement(element).click().build().perform();
//	System.out.println("Clicked on "+elementname);
	
	WebElement element;
	if (elementname.contains("//")){
		 element = webDr.findElement(By.xpath(elementname));
		Actions actions = new Actions(webDr);
		actions.moveToElement(element).click().build().perform();
		System.out.println("Clicked on "+elementname);
	}else{
		 element = getControl(elementname);
		Actions actions = new Actions(webDr);
		actions.moveToElement(element).click().build().perform();
		System.out.println("Clicked on "+elementname);
	}
}

public void Highlightobj(String elementname){
	//WebElement element = getControl(elementname);
	if (checkElementPresent(elementname, 5000)) {
		
		JavascriptExecutor js = (JavascriptExecutor) webDr;
	    js.executeScript("arguments[0].style.border='2px groove green'",getControl(elementname) );

}
}


public Mouse mouseOver(String elementName) {
    try {
           
           Mouse mouse = null;
           if(elementName.contains("->")){
                 clickFromData(elementName);
           }
           else{
                 SleepUtils.sleep(TimeSlab.LOW);
           WebElement link = getControl(elementName);
           SleepUtils.sleep(TimeSlab.LOW);
           Locatable hoverItem = (Locatable) link;
           mouse = ((HasInputDevices) webDr).getMouse();
           mouse.mouseMove(hoverItem.getCoordinates());
           }
           return mouse;
           
    } catch (Exception e) {
           logger.handleError("Falied to hover on ", elementName, e);
           return null;
    }

}

public void clickFromData(String sValue) {

    Map result = null;
    String[] parts = null;
    String valueForMouseHOver= null,valueForClick = null;
    //Checks for the underscore in the sValue String.
    
    if(sValue.contains("->"))
    {
           parts = sValue.split("->");
           valueForClick = parts[parts.length - 1];
           for(int i=0;i<parts.length;i++)
           {
                 valueForMouseHOver = parts[i];
                 try
                 {
                        if(valueForMouseHOver.matches(valueForClick) || valueForMouseHOver.equals(valueForClick))
                        {
                               getControl(valueForClick).click();
                        }
                        else
                        {
                               mouseOver(valueForMouseHOver);
                               SleepUtils.sleep(TimeSlab.YIELD);
                        }
                 }
                        catch(NullPointerException e)
                        {
                                      
                        }
           }      
           
    }
    
}

public void NumOfIframes(){
	JavascriptExecutor exe = (JavascriptExecutor) webDr;
	Integer numberOfFrames = Integer.parseInt(exe.executeScript("return window.length").toString());
	System.out.println("Number of iframes on the page/iFrames are " + numberOfFrames);
}

public void RefreshBrowser(){
	webDr.navigate().refresh();
}

public boolean isEnabled(String elementName){
	WebElement element = getControl(elementName);
	Boolean Bool =  element.isEnabled();
	return Bool;
}

public boolean IsSelected(String elementName){
	WebElement element = getControl(elementName);
	Boolean Bool =  element.isSelected();
	return Bool;
}

public Date TimeStamp(){
	Timestamp timestamp = new Timestamp(System.currentTimeMillis());
	SimpleDateFormat sfdate = new SimpleDateFormat("MM/dd/yyy HH:mm:ss a");
    Date date = new Date();
    
    try {
		date = sfdate.parse(timestamp.toString());
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    return date;
    //System.out.println(sfdate.format(date) );
}

public void CompareTimeStampWithTimePostedinReports(String ElementName , String CapturedTime) throws ParseException {
	WebElement element = getControl(ElementName);
	String TimePostedFromAppln = element.getText();
	/*Following 2 lines converts the TimePostedFromAppln to MM/DD/YYYY if it is in m/d/yyyy format */
	if (TimePostedFromAppln.charAt(1) == '/') TimePostedFromAppln = "0" + TimePostedFromAppln; 
	if (TimePostedFromAppln.charAt(4) == '/') TimePostedFromAppln = TimePostedFromAppln.substring(0,3) + "0" + TimePostedFromAppln.substring(3);
	System.out.println(TimePostedFromAppln);
	System.out.println(CapturedTime);
	String[] arrTimePostedFromAppln = TimePostedFromAppln.split(" ");
	String[] arrTimeStamp = CapturedTime.split(" ");
	/*Checks if the Dates match & AM/PM matches*/
	if (arrTimePostedFromAppln[0].equals(arrTimeStamp[0]) && arrTimePostedFromAppln[2].equals(arrTimeStamp[2])){	
//		String[] arrTimePosted = arrTimePostedFromAppln[1].split(":");
//		String[] arrTimeInTimeStamp = arrTimeStamp[1].split(":");
//		int Min_Appln =  Integer.parseInt(arrTimePosted[1]);
//		int Min_ts =  Integer.parseInt(arrTimeInTimeStamp[1]);
		
		SimpleDateFormat parser = new SimpleDateFormat("HH:mm");
		Date Time_Appln = parser.parse(arrTimePostedFromAppln[1]);
		Date Time_TS = parser.parse(arrTimeStamp[1]);
		/*Checks if the hour part matches & checks if the minutes doesn't differ more than 2 mins  */
		//if ( (Integer.parseInt(arrTimePosted[0]) == Integer.parseInt(arrTimeInTimeStamp[0])) && ((Min_Appln - Min_ts)<=2) ){
		if ( (Time_Appln.getTime() - Time_TS.getTime())/ (60 * 1000) < 2 ){
			passed("Time Posted from Applcation - Timestamp","Time Posted from Applcation and  Time stamp Captured should not differ more than 2 mins","Passed:Time Posted from Applcation and  Time stamp Captured not differs more than 2 mins");
		}
		else {
			failed("Time Posted from Applcation - Timestamp","Time Posted from Applcation and  Time stamp Captured should not differ more than 2 mins","Failed:Time Posted from Applcation and  Time stamp Captured differs more than 2 mins");
		}
		
	} else {
		failed("Time Posted from Applcation - Timestamp","Time Posted from Applcation and  Time stamp Captured should not differ more than 2 mins","Failed: Time Posted from Applcation and  Time stamp Captured differs more than 2 mins");
	}

}

//public void CompareTimeStampWithTimePostedinReport(String ElementName , String CapturedTime)  {
//	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/DD/YYYY HH:MM");
//	WebElement element = getControl(ElementName);
//	String TimePostedFromAppln = element.getText();
//	/*Following 2 lines converts the TimePostedFromAppln to MM/DD/YYYY if it is in m/d/yyyy format */
//	if (TimePostedFromAppln.charAt(1) == '/') TimePostedFromAppln = "0" + TimePostedFromAppln; 
//	if (TimePostedFromAppln.charAt(4) == '/') TimePostedFromAppln = TimePostedFromAppln.substring(0,3) + "0" + TimePostedFromAppln.substring(3);
//	System.out.println(TimePostedFromAppln);
//	System.out.println(CapturedTime);
//	TimePostedFromAppln = TimePostedFromAppln.replace("CST","");
//	LocalDateTime dateTime1= LocalDateTime.parse(TimePostedFromAppln, formatter);
//	LocalDateTime dateTime2= LocalDateTime.parse(CapturedTime, formatter);
//
//
//	long diffInSeconds = java.time.Duration.between(dateTime1, dateTime2).getSeconds();
//	long diffInMinutes = java.time.Duration.between(dateTime1, dateTime2).toMinutes();
//	System.out.println(diffInMinutes);
//	System.out.println(diffInSeconds);
//	System.out.println(diffInMinutes);
//}

public boolean CompareTimeStampWithTimePostedinReport(String Xpath , String CapturedTime) throws ParseException {

	WebElement element  = webDr.findElement(By.xpath(Xpath));
//	WebElement element = getControl(Xpath);
	String TimePostedFromAppln = element.getText();
	/*Following 2 lines converts the TimePostedFromAppln to MM/DD/YYYY if it is in m/d/yyyy format */
	if (TimePostedFromAppln.charAt(1) == '/') TimePostedFromAppln = "0" + TimePostedFromAppln; 
	if (TimePostedFromAppln.charAt(4) == '/') TimePostedFromAppln = TimePostedFromAppln.substring(0,3) + "0" + TimePostedFromAppln.substring(3);
	System.out.println(TimePostedFromAppln);
	System.out.println(CapturedTime);
	String[] arrTimePostedFromAppln = TimePostedFromAppln.split(" ");
	String[] arrTimeStamp = CapturedTime.split(" ");
	/*Checks if the Dates match & AM/PM matches*/
	if (arrTimePostedFromAppln[0].equals(arrTimeStamp[0]) && arrTimePostedFromAppln[2].equals(arrTimeStamp[2])){	
//		String[] arrTimePosted = arrTimePostedFromAppln[1].split(":");
//		String[] arrTimeInTimeStamp = arrTimeStamp[1].split(":");
//		int Min_Appln =  Integer.parseInt(arrTimePosted[1]);
//		int Min_ts =  Integer.parseInt(arrTimeInTimeStamp[1]);
		
		SimpleDateFormat parser = new SimpleDateFormat("HH:mm");
		Date Time_Appln = parser.parse(arrTimePostedFromAppln[1]);
		Date Time_TS = parser.parse(arrTimeStamp[1]);
		/*Checks if the hour part matches & checks if the minutes doesn't differ more than 2 mins  */
		//if ( (Integer.parseInt(arrTimePosted[0]) == Integer.parseInt(arrTimeInTimeStamp[0])) && ((Min_Appln - Min_ts)<=2) ){
		if ( (Time_Appln.getTime() - Time_TS.getTime())/ (60 * 1000) < 2 ){
			return true;
		}
		else {
			return false;
		}
		
	} else {
		return false;
		
	}

}

public void ImplicitWait(int mS){
	webDr.manage().timeouts().implicitlyWait(mS, TimeUnit.SECONDS);	
}


public boolean CompareTimeStamp(String TimePostedFromAppln, String CapturedTime) throws ParseException{
	/*Following 2 lines converts the TimePostedFromAppln to MM/DD/YYYY if it is in m/d/yyyy format */
	if (TimePostedFromAppln.charAt(1) == '/') TimePostedFromAppln = "0" + TimePostedFromAppln; 
	if (TimePostedFromAppln.charAt(4) == '/') TimePostedFromAppln = TimePostedFromAppln.substring(0,3) + "0" + TimePostedFromAppln.substring(3);
	System.out.println(TimePostedFromAppln);
	System.out.println(CapturedTime);
	String[] arrTimePostedFromAppln = TimePostedFromAppln.split(" ");
	String[] arrTimeStamp = CapturedTime.split(" ");
	/*Checks if the Dates match & AM/PM matches*/
	if (arrTimePostedFromAppln[0].equals(arrTimeStamp[0]) && arrTimePostedFromAppln[2].equals(arrTimeStamp[2])){	
//		String[] arrTimePosted = arrTimePostedFromAppln[1].split(":");
//		String[] arrTimeInTimeStamp = arrTimeStamp[1].split(":");
//		int Min_Appln =  Integer.parseInt(arrTimePosted[1]);
//		int Min_ts =  Integer.parseInt(arrTimeInTimeStamp[1]);
		
		SimpleDateFormat parser = new SimpleDateFormat("HH:mm");
		Date Time_Appln = parser.parse(arrTimePostedFromAppln[1]);
		Date Time_TS = parser.parse(arrTimeStamp[1]);
		/*Checks if the hour part matches & checks if the minutes doesn't differ more than 2 mins  */
		//if ( (Integer.parseInt(arrTimePosted[0]) == Integer.parseInt(arrTimeInTimeStamp[0])) && ((Min_Appln - Min_ts)<=2) ){
		if ( (Time_Appln.getTime() - Time_TS.getTime())/ (60 * 1000) < 2 && (Time_Appln.getTime() - Time_TS.getTime())/ (60 * 1000) >= 0){
			passed("Time Posted from Applcation - Timestamp","Time Posted from Applcation and  Time stamp Captured should not differ more than 2 mins","Passed:Time Posted from Applcation and  Time stamp Captured not differs more than 2 mins");
			return true;
		}
		else {
			failed("Time Posted from Applcation - Timestamp","Time Posted from Applcation and  Time stamp Captured should not differ more than 2 mins","Failed:Time Posted from Applcation and  Time stamp Captured differs more than 2 mins");
			return false;
		}
		
	} else {
		failed("Time Posted from Applcation - Timestamp","Time Posted from Applcation and  Time stamp Captured should not differ more than 2 mins","Failed: Time Posted from Applcation and  Time stamp Captured differs more than 2 mins");
		return false;
	}

}

public boolean VerifyVisible(String elementname , String Input){
	WebElement element = getControl(elementname);
	boolean EleDisplayed = false;
	EleDisplayed = element.isDisplayed();
	if (element.getText().contains(Input) && EleDisplayed) {
		passed(elementname+" should be Present & Visible",elementname+" should be Present & Visible",elementname+" is present & Visible ");
		return true;
	}else{
		failed(elementname+" should be Present & Visible",elementname+" should be Present & Visible",elementname+" not present or Visible ");
	return false;
	}
}



public boolean VerifyVisible(String elementname){
	WebElement element = getControl(elementname);
	
	boolean chk = false;
	chk = element.isDisplayed();
	if (element.getLocation().x != 0 && !chk){
		//new Actions(webDr).moveToElement(element).perform();
//		((JavascriptExecutor)webDr).executeScript("window.focus();");
//		JavascriptExecutor js = (JavascriptExecutor) webDr;
//		js.executeScript("arguments[0].focus;", element);
		element.sendKeys(""); 
		chk = element.isDisplayed();

	}
	
	if (chk){
		passed(elementname+" should be Present & Visible",elementname+" should be Present & Visible",elementname+" is present & Visible ");
	}else{
		failed(elementname+" should be Present & Visible",elementname+" should be Present & Visible",elementname+" not present or Visible ");	
	}
	return chk;
}

public void VerifyDisable(String elementname , String rep){
	
}

public void ClickByXpath(String Xpath){
	WebElement Element = webDr.findElement(By.xpath(Xpath));
	Actions actions = new Actions(webDr);
	actions.moveToElement(Element).click().build().perform();
}
//public void active(String xpath) {
//	WebElement element = getControl(xpath);
////	webDr.findElement(By.active());
//	element.getLocation();
//}

public void ScrollIntoView(String DivLocator, String ElementLocator){

	WebElement Element ;
	WebElement Div;
	int count  = 0;
	if (ElementLocator.contains("//")){
		 Element = webDr.findElement(By.xpath(ElementLocator));
		 
	}else{
		 Element = getControl(ElementLocator);
	}
	
	if (DivLocator.contains("//")){
		 Div = webDr.findElement(By.xpath(DivLocator));
	}else{
		 Div = getControl(DivLocator);
	}
	

	Div.sendKeys("");
	((JavascriptExecutor)webDr).executeScript("arguments[0].scrollIntoView();", Element);
}

public String getTextFromDropDown(String elementName){
	String Value = null;
	WebElement element = getControl(elementName);
	
		String type = element.getAttribute("type");
	if (type != null){
	
			Select selectOption = new Select(element);
		WebElement option = 	selectOption.getFirstSelectedOption();
		 Value =	option.getText();
		
	}	
		
			
	
	
	
	return Value;
	
	
	}



public void ClickLink() throws InterruptedException{
	JavascriptExecutor js = (JavascriptExecutor) webDr;
	
	WebElement Tag;
	List<WebElement> Tags = webDr.findElements(By
			.tagName("a"));
	
	int numberOFTags = Tags.size();
	js.executeScript("arguments[5].click();",Tags);  
	Thread.sleep(5000);



	
	
}
//verifyText
public boolean Verify(final String elementName, int timeInSec) {

	boolean result = false;

	try {
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver webDriver) {
				WebElement element = getControl(elementName);
				if (element != null) {
					return true;
				} else {
					return false;

				}
			}
		};

		Wait<WebDriver> wait = new WebDriverWait(webDr, timeInSec);
		try {
			result = wait.until(expectation);
		} catch (Exception e) {

		}
	} catch (Exception e) {

	}
	return result;
}
//selecting the record
public boolean SelectparticularReport(String elementName, String Reportname){

	try {
		/*NumOfIframes();
	switchToiFrame0();
	switchToiFrame0();*/
		String locator = getLocator(elementName);
		List<WebElement> tr_Collection = webDr.findElements(By.xpath(locator));
		for(int j=1;j<tr_Collection.size();j++)
		{
			WebElement Packetname=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[2]"));
			WebElement Packetnamechkbx=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[1]/input"));
			if(Packetname.getText().equals("")){
				ScrollMoveIntoView(Packetnamechkbx);
				wait(3000);
				Packetname=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[2]"));
			}
			if(Packetname.getText().equalsIgnoreCase(Reportname)) 
			{	
				WebElement Packetnamechkbx1=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[1]/input"));
				if(!Packetnamechkbx1.isSelected()){
				Packetnamechkbx.click();
				wait(2000);
				}
				//				groupClick.click();
				/*BackFromiFrame();
			BackFromiFrame();*/
				return true;			
			}

		}

		return false;
	} catch (Exception e) {
		logger.handleError("Failed to find the report Packet ", elementName," ", e);
		return false;
	}
}

//verifying status of newly created record
public boolean VerifyStatus(String elementName, String Firstcolumnvalue){

	try {
		/*NumOfIframes();
	switchToiFrame0();
	switchToiFrame0();*/
		String locator = getLocator(elementName);
		List<WebElement> tr_Collection = webDr.findElements(By.xpath(locator));
		for(int j=1;j<tr_Collection.size();j++)
		{
			WebElement Packetname=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[2]"));
			
			if(Packetname.getText().trim().contains(Firstcolumnvalue)) 
			{	
				WebElement Packetnamechkbx=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[10]"));
				if(Packetnamechkbx.getText().equalsIgnoreCase("Completed")){
					return true;
				}
				else{
					return false;
				}
				//				groupClick.click();
				/*BackFromiFrame();
			BackFromiFrame();*/			
			}
		}

		return false;
	} catch (Exception e) {
		logger.handleError("Failed to find the report Packet ", elementName," ", e);
		return false;
	}
}
public void click_pv(String elementName) {
	try {		
		WebElement element=getControl_pv1(elementName);
		element.click();
		/*JavascriptExecutor js = (JavascriptExecutor) webDr;
		js.executeScript("arguments[0].click();", element);*/
		passed("click on Element "+elementName,"click on Element"+elementName+" should pass","click on Element"+elementName+" passed");
	} catch (Exception e) {
		logger.handleError("Failed to click on the element ", elementName," ", e);
	}

}
public WebElement getControl_pv1(String elementName) {
	WebElement element = null;
	int index = 1;
	final By[] byCollection = { 
			By.xpath(elementName),
			By.className(elementName), By.cssSelector(elementName),
			By.tagName(elementName), By.linkText(elementName),
			By.id(elementName),By.name(elementName),
			By.id(elementName),
			By.partialLinkText(elementName) };

	for (By by : byCollection) {
		try {
			element = webDr.findElement(by);
			if (!element.equals(null)) {
				break;
			}
		} catch (Exception e) {
			if (index == byCollection.length) {
				logger.error("Unable to find report packet ","", e);
			} else {
				index++;
				continue;
			}
		}
	}
	return element;
}
public boolean SelectReportChk(String elementName, String Firstcolumnvalue){

	try {
		/*NumOfIframes();
	switchToiFrame0();
	switchToiFrame0();*/
		String locator = getLocator(elementName);
		List<WebElement> tr_Collection = (List<WebElement>) webDr.findElements(By.xpath(locator));
		for(int j=1;j<=tr_Collection.size();j++)
		{
			WebElement Packetname=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[2]"));
			
			if(Packetname.getText().trim().contains(Firstcolumnvalue)) 
			{	
				WebElement Packetnamechkbx=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[1]"));
				Packetnamechkbx.click();
			
					return true;
				}
				//				groupClick.click();
				/*BackFromiFrame();
			BackFromiFrame();*/			
			}
		return false;
		}
 catch (Exception e) {
		logger.handleError("Failed to find the report Packet ", elementName," ", e);
		return false;
	}
}

public boolean SelectReportgrpclntChk(String elementName, String Firstcolumnvalue){

	try {
		/*NumOfIframes();
	switchToiFrame0();
	switchToiFrame0();*/
		String locator = getLocator(elementName);
		List<WebElement> tr_Collection = (List<WebElement>) webDr.findElements(By.xpath(locator));
		for(int j=1;j<=tr_Collection.size();j++)
		{
			WebElement Packetname=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[3]"));
			
			if(Packetname.getText().trim().equalsIgnoreCase(Firstcolumnvalue)) 
			{	
				WebElement Packetnamechkbx=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[1]/input"));
				Packetnamechkbx.click();
			
					return true;
				}
				//				groupClick.click();
				/*BackFromiFrame();
			BackFromiFrame();*/			
			}
		return false;
		}
 catch (Exception e) {
		logger.handleError("Failed to find the report Packet ", elementName," ", e);
		return false;
	}
}
public boolean SelectTargetreport(String elementName, String Firstcolumnvalue){

	try {
		/*NumOfIframes();
	switchToiFrame0();
	switchToiFrame0();*/
		String locator = getLocator(elementName);
		List<WebElement> tr_Collection = (List<WebElement>) webDr.findElements(By.xpath(locator));
		for(int j=2;j<tr_Collection.size();j++)
		{
			WebElement Packetname=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[2]"));
			
			if(Packetname.getText().trim().contains(Firstcolumnvalue)) 
			{	
				WebElement Packetnamechkbx=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[1]/input"));
				Packetnamechkbx.click();
			
					return true;
				}
				//				groupClick.click();
				/*BackFromiFrame();
			BackFromiFrame();*/			
			}
		return false;
		}
 catch (Exception e) {
		logger.handleError("Failed to find the report Packet ", elementName," ", e);
		return false;
	}
}
public boolean ReportSelectionpdf(String elementName, String Reportname){

	try {
		/*NumOfIframes();
	switchToiFrame0();
	switchToiFrame0();*/
		String locator = getLocator(elementName);
		List<WebElement> tr_Collection = webDr.findElements(By.xpath(locator));
		for(int j=1;j<tr_Collection.size();j++)
		{
			WebElement Packetname=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[3]"));
			WebElement Target=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[6]"));
			if(Packetname.getText().trim().contains(Reportname)) 
			{	
				WebElement Packetname1=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[3]/div/a/span"));
				//Packetname1.click();
				//JavascriptExecutor js = (JavascriptExecutor) webDr;  
				//js.executeScript("arguments[0].click();",Packetname1);
				Packetname1.click();
				return true;
				//				groupClick.click();
				/*BackFromiFrame();
			BackFromiFrame();*/			
			}
		}

		return false;
	} catch (Exception e) {
		logger.handleError("Failed to find the report Packet ", elementName," ", e);
		return false;
	}
}
	/**
	 * Overriding toString() method to return WebUIDriver format string
	 */
public String getWindowHandle(){
	String handle = webDr.getWindowHandle();
	return handle;
}
public Set<String> getWindowHandles(){
Set<String> handle= webDr.getWindowHandles();
return handle;
}
public boolean switchTopWindow(String title) {
	Set<String> availableWindows = webDr.getWindowHandles();
	String secondWinHandle;
	if (availableWindows.size() >= 1) {
		try {
			
				System.out.println("Inside Switch window ");
				availableWindows.remove(title);	
				String winHandle=availableWindows.iterator().next();
				
				 if (winHandle!=title){
				 
				 //To retrieve the handle of second window, extracting the handle which does not match to first window handle
				 
				 secondWinHandle=winHandle; //Storing handle of second window handle
				 
				//Switch control to new window
				 
				 webDr.switchTo().window(secondWinHandle);
					System.out.println("Inside Swtich window If loop:"+title);
				 }
				
					return true;
			
		} catch (Exception e) {
			logger.handleError("No child window is available to switch ", e);
		}
	}

	return false;
}
public boolean switchToparentwindow(String win) {
	try{
		
				 webDr.switchTo().window(win);
					return true;
			
		} catch (Exception e) {
			logger.handleError("No window is available to switch ", e);
		}
	return false;
}
//checkbox selection by passing values as true or false
public boolean checkbox(String element, String value){
	try{
		WebElement element1= getControl(element);
		if(value.equalsIgnoreCase("true")){
			if(!element1.isSelected()){
		JavascriptExecutor js = (JavascriptExecutor) webDr;  
		js.executeScript("arguments[0].click();",getControl(element));
		return true;
			}
		}else if(value.equalsIgnoreCase("false")){
			if(element1.isSelected()){
				JavascriptExecutor js = (JavascriptExecutor) webDr;  
				js.executeScript("arguments[0].click();",getControl(element));
				return true;
			}
		}
		return false;
	}
	catch(Exception e){
		logger.error("Unable to click element", element, e);
		return false;
	}
}
public boolean ScrollMoveIntoView(WebElement element){
	try{	
		JavascriptExecutor js = (JavascriptExecutor) webDr;  
		js.executeScript("arguments[0].scrollIntoView();",element);
		return true;
	}
	catch(Exception e){
		logger.error("Unable to click element", element, e);
		return false;
	}
}
public boolean jsClick(WebElement element){
	try{
		JavascriptExecutor js = (JavascriptExecutor) webDr;  
		js.executeScript("arguments[0].click();", element);
		return true;
	}
	catch(Exception e){
		logger.error("Unable to click element", element, e);
		return false;
	}

}

public boolean ReportValinnercolumns(String elementName, List<String> Reportname){

	try {
		/*NumOfIframes();
	switchToiFrame0();
	switchToiFrame0();*/
		String locator = getLocator(elementName);
		List<WebElement> tr_Collection = webDr.findElements(By.xpath(locator));
		//if(tr_Collection.size()==Reportname.size()){
		for(int j=1;j<tr_Collection.size();j++)
		{
			WebElement Packetname=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[2]/span"));
			//WebElement Target=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[6]"));
			innerloop:
			for(int i=0;i<Reportname.size();i++){
			if(Packetname.getText().trim().contains(Reportname.get(i))) 
			{	
				passed("ReportValinnercolumns","ReportValinnercolumns should pass","ReportValinnercolumns passed");
				break innerloop;
			}else if(Reportname.size()==(i+1)){
				failed("ReportValinnercolumns","ReportValinnercolumns should pass","ReportValinnercolumns failed");
			}
				
				//				groupClick.click();
				/*BackFromiFrame();
			BackFromiFrame();*/			
			}
		}
		return true;
		//}
		//else{
			//failed("Report validation","Report validation should pass","Report validation failed");
		//}
		//return false;
	} catch (Exception e) {
		logger.handleError("Failed to find the report Packet ", elementName," ", e);
		return false;
	}
}
//checkElementPresent function returning boolean
public boolean checkElementPresentpro(final String elementName, int timeInSec) {

	boolean result = false;
	try {
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver webDriver) {
				WebElement element = getControlpro(elementName);
				if (element != null) {
					passed("checkElementPresentpro","Element " + elementName + "should be present","Element " + elementName + " present : passed");
					return true;

				} else {
					return false;
				}
			}
		};

		Wait<WebDriver> wait = new WebDriverWait(webDr, timeInSec);
		try {
			result = wait.until(expectation);
		} catch (Exception e) {

		}
	} catch (Exception e) {

	}
	return result;
}

public boolean IsDisplayed_boolean(final String elementName, int timeInSec) {

	boolean result = false;

	try {
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver webDriver) {
				WebElement element = getControlpro(elementName);
				if (element.isDisplayed()) {
					return true;
				} else {
					return false;
				}
			}
		};

		Wait<WebDriver> wait = new WebDriverWait(webDr, timeInSec);
		try {
			result = wait.until(expectation);
			passed("IsDisplayed","Element " + elementName + "should display","Element " + elementName + " is displayed : passed");
		} catch (Exception e) {
			failed("IsDisplayed","Element " + elementName + "should display","Element " + elementName + " is displayed : failed");
		}
	} catch (Exception e) {

	}
	return result;
}

public String getfirstselectedoption(String elementName){
	String selectedoption;
	WebElement element=getControl(elementName);
	Select option=new Select(element);
	selectedoption=option.getFirstSelectedOption().getText();
	return selectedoption;
}

public boolean checkElementPresentload(final String elementName, int timeInSec) {

	boolean result = false;

	try {
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver webDriver) {
				WebElement element = getControlpro(elementName);
				if (element != null) {
					return true;
				} else {
					return false;
				}
			}
		};

		Wait<WebDriver> wait = new WebDriverWait(webDr, timeInSec);
		try {
			result = wait.until(expectation);
		} catch (Exception e) {

		}
	} catch (Exception e) {

	}
	return result;
}
public void closeTab() {
	// TODO Auto-generated method stub
	webDr.close();
}
public void setEmailNotification(String xpath) {
	try {
		WebElement from = getControl(xpath);
		
		//WebElement to = getControl(toLocator);
		Actions act = null;
		Actions actions = new Actions(webDr);
		//actions.moveToElement(from).click().doubleClick(to).build().perform();
		//moveToElement(from).click().
			act = actions.moveToElement(from).click();
			act.build().perform();
			
		act.sendKeys(Keys.DOWN).build().perform();
		act.sendKeys(Keys.DOWN).build().perform();
		act.sendKeys(Keys.ENTER).build().perform();
		
		//actions.moveToElement(to).click().build().perform();
		//dragAndDrop.perform();
	} catch (Exception e) {
		logger.handleError("Failed to drag drop elements ", 
				" , ",  " ", e);
	}
}

public void back() {
	// TODO Auto-generated method stub
	webDr.navigate().back();
}

public String getTitle() {
	return webDr.getTitle();
}
public boolean checkPassFail(boolean condition,String description){

	if (condition)
	{
		passed(description,description+" should pass",description+": Passed");
		return condition;
	} 
	else 
	{
		failed(description,description+" should pass",description+": Failed");
		return condition;
	}

}

public void writeExcelstatus(String testcasename,String columnname, String status, String sheetname, String Path) throws IOException {
	try {
		System.out.println("Im in OutputData function");
		File src = new File(Path);
		
		FileInputStream fis = new FileInputStream(src);	
		wb = new XSSFWorkbook(fis);
		//Sheet1 = wb.getSheetAt(0);
		Sheet1 = wb.getSheet(sheetname);
		int RowCount = Sheet1.getLastRowNum();
		int columncount = Sheet1.getRow(0).getPhysicalNumberOfCells();
		Map<String,Integer> head = new HashMap<String,Integer>();
		outerLoop:
		for (int j=1;j<=RowCount;j++){
			String S1= Sheet1.getRow(j).getCell(1).getStringCellValue();
			if(Sheet1.getRow(j).getCell(1).getStringCellValue().equals(testcasename)){
			for(int i=1;i<=columncount;i++){
				String S2= Sheet1.getRow(0).getCell(i).getStringCellValue();
				if(Sheet1.getRow(0).getCell(i).getStringCellValue().equals(columnname)){
							Sheet1.getRow(j).createCell(i).setCellValue(status);
							break outerLoop;
					}
					}		
				}
			}
		//}
		FileOutputStream fout = new FileOutputStream(src);	
		wb.write(fout);

	}
	catch (Exception e) {
		// TODO Auto-generated catch block
		logger.handleError("Failed while writing to excel", e);
	}
}
//getcontrol function without returning error
public WebElement getControlpro(String elementName) {
	System.out.println("Im in getControl function");
	String actualLocator = getLocator(elementName);
	WebElement element = null;
	int index = 1;
	final By[] byCollection = { 
			By.xpath(actualLocator),
			By.className(actualLocator), By.cssSelector(actualLocator),
			By.tagName(actualLocator), By.linkText(actualLocator),
			By.id(actualLocator),By.name(actualLocator),
			By.partialLinkText(actualLocator) };

	for (By by : byCollection) {
		try {
			element = webDr.findElement(by);
			if (!element.equals(null)) {
				break;
			}
		} catch (Exception e) {
			if (index == byCollection.length) {
				return element;
			} else {
				index++;
				continue;
			}
		}
	}
	return element;
}
public boolean jsClick(String element){
	try{
		JavascriptExecutor js = (JavascriptExecutor) webDr;  
		js.executeScript("arguments[0].click();", getControl(element));
		return true;
	}
	catch(Exception e){
		logger.error("Unable to click element", element, e);
		return false;
	}

}
public void writeExcelerror(String test,String strKey, String sheetname, String Path,String filtername,String filtervalue,String txtfilepath) throws IOException {
	try {
		System.out.println("Im in OutputData function");
		String errormsg="error: "+filtervalue;
		File src = new File(Path);//"C:\\CAFENEXT\\CafeNext_Selenium_Framework\\CBF_Framework\\Projects\\Prosurv_2\\Plan\\TestCases\\ProSurv CAS Daily Counts format.xlsx");
		
		FileInputStream fis = new FileInputStream(src);	
		wb = new XSSFWorkbook(fis);
		//Sheet1 = wb.getSheetAt(0);
		Sheet1 = wb.getSheet(sheetname);
		int RowCount = Sheet1.getLastRowNum();
		int columncount = Sheet1.getRow(0).getPhysicalNumberOfCells();
		Map<String,Integer> head = new HashMap<String,Integer>();
		
		outerLoop:
		for (int j=1;j<=RowCount;j++){
			String S1= Sheet1.getRow(j).getCell(0).getStringCellValue();
			if(Sheet1.getRow(j).getCell(0).getStringCellValue().equals(test)){
			for(int i=1;i<=columncount;i++){
				String S2= Sheet1.getRow(0).getCell(i).getStringCellValue();
				if(Sheet1.getRow(0).getCell(i).getStringCellValue().equals(strKey)){
							Sheet1.getRow(j).createCell(i).setCellValue(errormsg);
							break outerLoop;
					}					
					}		
				}
			if(j==RowCount){
				WriteTotxtfile(sheetname,filtername,filtervalue,txtfilepath,errormsg);
			}
			
			}
		//}
		FileOutputStream fout = new FileOutputStream(src);	
		wb.write(fout);

	}
	catch (Exception e) {
		// TODO Auto-generated catch block
		logger.handleError("Failed while writing to excel", e);
	

	}
}
public void WriteTotxtfile(String firmname,String filtername,String filtervalue,String txtfilepath,String count) {
	   //Data to write
	   String sContent = firmname+"-->"+filtername+"-->"+filtervalue+"-->"+count;
	  //FilePath
	  String sFilePath = txtfilepath; 
	   try {
	                  //Creating File object
	     File file = new File(sFilePath);
	     // if file doesn't exists, then create it
	     if (!file.exists()) {
	      file.createNewFile();
	     }
	     //Creating FileWriter object
	     //using file object we got the filePath
	     FileWriter fw = new FileWriter(file.getAbsoluteFile(),true);
	     //Creating BufferedWriter object
	     BufferedWriter bw = new BufferedWriter(fw);
	     //Writing content into file
	     bw.write(sContent);
	     //Adding new line 
	     bw.newLine();
	     bw.close();
	     System.out.println("Data is Successfully written");

	    } catch (IOException e) {
	     e.printStackTrace();
	    }
	   }
public void writeExcelUAT(String test,String strKey, String elementName,String sheetname,String OutputsheetPath,String filtername,String filtervalue,String txtfilepath) throws IOException {
	try {
		System.out.println("Im in OutputData function");
		wait(1000);
		WebElement element = getControl(elementName);
			String strElementValue = element.getText();
			String words2="0";
			if(strElementValue.contains(" ")){
			String[] words1= strElementValue.split("\\s+");
			 words2=words1[words1.length-1];
			}
			else{
				words2=strElementValue;
			}
			
		File src = new File(OutputsheetPath);//"C:\\CAFENEXT\\CafeNext_Selenium_Framework\\CBF_Framework\\Projects\\PROSURV_UAT\\Plan\\TestCases\\ProSurv CAS Daily Counts format.xlsx");
		
		FileInputStream fis = new FileInputStream(src);	
		wb = new XSSFWorkbook(fis);
		//Sheet1 = wb.getSheetAt(0);
		Sheet1 = wb.getSheet(sheetname);
		int RowCount = Sheet1.getLastRowNum();
		int columncount = Sheet1.getRow(0).getPhysicalNumberOfCells();
		Map<String,Integer> head = new HashMap<String,Integer>();
		outerLoop:
		for (int j=1;j<=RowCount;j++){
			String S1= Sheet1.getRow(j).getCell(0).getStringCellValue();
			if(Sheet1.getRow(j).getCell(0).getStringCellValue().equals(test)){
			for(int i=1;i<=columncount;i++){
				String S2= Sheet1.getRow(0).getCell(i).getStringCellValue();
				if(Sheet1.getRow(0).getCell(i).getStringCellValue().equals(strKey)){
							Sheet1.getRow(j).createCell(i).setCellValue(words2);
							break outerLoop;
					}
					}		
				}
			if(j==RowCount){
				WriteTotxtfile(sheetname,filtername,filtervalue,txtfilepath,words2);
			}
			}
		//}
		FileOutputStream fout = new FileOutputStream(src);	
		wb.write(fout);

	}
	catch (Exception e) {
		// TODO Auto-generated catch block
		logger.handleError("Failed while writing to excel", e);
	

	}
}
public boolean checkElementExists(final String elementName, int mSec) {  

    boolean result = false; 

    try { 
            ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() { 
                    public Boolean apply(WebDriver webDriver) { 
                            WebElement element = getControl(elementName); 
                            if (element != null) { 

                                    passed("Checking the presence of element:" + " " + elementName + " ", 
                                                    "element"+elementName+" should present", "element" + " "

                                                                    + elementName + " " + "is present"); 

                                    return true; 

                            } else { 
                                    failed("Checking the presence of element:" + " " + elementName + " ", 
                                                    "element"+elementName+" should present", "element" + " "

                                                                    + elementName + " " + "is not present");

                                    return false; 

                            } 
                    } 
            }; 

            Wait<WebDriver> wait = new WebDriverWait(webDr, 
                            TimeUnit.MILLISECONDS.toSeconds(mSec)); 
            try { 
                    result = wait.until(expectation); 
            } catch (Exception e) { 

            } 
    } catch (Exception e) { 

    } 
    return result; 
}
public void writeExcel(String test,String strKey, String elementName, String sheetname, String Path,String filtername,String filtervalue,String txtfilepath) throws IOException {
	try {
		System.out.println("Im in OutputData function");
		WebElement element = getControl(elementName);
			wait(1000);
			String type = element.getAttribute("type");
			String[] words=null;
			String words2="0";
			String strElementValue = element.getText();
			if(strElementValue.contains("Reviews")){
			if(strElementValue.contains(")"))
			{
				words = strElementValue.split("\\)");
			}
			if(strElementValue.contains(" ")){
			String[] words1= words[0].split("\\s+");
			 words2=words1[words1.length-1];
			}
			if(words2.contains("("))
			{
				words2=words2.replace("(","");
			}
			}
			else{
				words2=strElementValue;
			}
			
		File src = new File(Path);//"C:\\CAFENEXT\\CafeNext_Selenium_Framework\\CBF_Framework\\Projects\\Prosurv_2\\Plan\\TestCases\\ProSurv CAS Daily Counts format.xlsx");
		
		FileInputStream fis = new FileInputStream(src);	
		wb = new XSSFWorkbook(fis);
		//Sheet1 = wb.getSheetAt(0);
		Sheet1 = wb.getSheet(sheetname);
		int RowCount = Sheet1.getLastRowNum();
		int columncount = Sheet1.getRow(0).getPhysicalNumberOfCells();
		Map<String,Integer> head = new HashMap<String,Integer>();
		/*for(int i=0;i<columncount;i++){
			head.put(Sheet1.getRow(0).getCell(i).getStringCellValue(),i);
		}*/
		//System.out.println("output"+outputValues.size());
		outerLoop:
		for (int j=1;j<=RowCount;j++){
			String S1= Sheet1.getRow(j).getCell(0).getStringCellValue();
			if(Sheet1.getRow(j).getCell(0).getStringCellValue().equals(test)){
			for(int i=1;i<=columncount;i++){
				String S2= Sheet1.getRow(0).getCell(i).getStringCellValue();
				//String S1= Sheet1.getRow(j).getCell(0).getStringCellValue();
				//if(Sheet1.getRow(j).getCell(0).getStringCellValue().equals(test)){
					//for(int a=0;a<outputValues.size();a++){
						//if(head.containsKey(strKey)){
							//int col = head.get(outputValues.get(a));
				if(Sheet1.getRow(0).getCell(i).getStringCellValue().equals(strKey)){
							Sheet1.getRow(j).createCell(i).setCellValue(words2);
							break outerLoop;
					}
					}		
				}
			if(j==RowCount){
				WriteTotxtfile(sheetname,filtername,filtervalue,txtfilepath,words2);
			}
			}
		//}
		FileOutputStream fout = new FileOutputStream(src);	
		wb.write(fout);

	}
	catch (Exception e) {
		// TODO Auto-generated catch block
		logger.handleError("Failed while writing to excel", e);
	}
}
public void writeExcelA3(String test,String strKey, String sheetname, String Path,String filtername,String filtervalue,String txtfilepath) throws IOException {
	try {
		System.out.println("Im in OutputData function");
		String[] words=null;
		String[] words1;
		String words2;
		if(checkElementPresentpro("Capture.Noresult", 4)){
			words2="0";
		}
		else if(checkElementPresentpro("Capture.btnbatchgo", 1)){
			WebElement element = getControl("Capture.batchcnt");
			String batchcount= element.getText();
			String[] batchcount1 = batchcount.split("\\s+");
			String batchcount2 = batchcount1[batchcount1.length-1];
			jsClick("Capture.edtbatch");
			setValue("Capture.edtbatch",batchcount2);
			jsClick("Capture.btnbatchgo");
			wait(2000);
			checkElementPresentpro("Capture.btnbatchgo", 10);
			WebElement elementrecord = getControl("Capture.recordscnt");
			String recordcount = elementrecord.getText();
			words = recordcount.split("\\;");
			words1= words[0].split("\\s+");
			String recordcount1=words1[words1.length-1];
			long batchcountint = Long.parseLong(batchcount2);
			long recordcountint = Long.parseLong(recordcount1);
			long  total = ((batchcountint-1)*1000)+recordcountint;
			words2 = Long.toString(total);
			
		}else{
			WebElement elementrecord = getControl("Capture.recordscnt");
			String recordcount = elementrecord.getText();
			words = recordcount.split("\\;");
			words1= words[0].split("\\s+");
			String recordcount1=words1[words1.length-1];
			long recordcountint = Long.parseLong(recordcount1);
			 words2 = Long.toString(recordcountint);
		}
			wait(1000);
			
		File src = new File(Path);//"C:\\CAFENEXT\\CafeNext_Selenium_Framework\\CBF_Framework\\Projects\\Prosurv_2\\Plan\\TestCases\\ProSurv CAS Daily Counts format.xlsx");
		
		FileInputStream fis = new FileInputStream(src);	
		wb = new XSSFWorkbook(fis);
		//Sheet1 = wb.getSheetAt(0);
		Sheet1 = wb.getSheet(sheetname);
		int RowCount = Sheet1.getLastRowNum();
		int columncount = Sheet1.getRow(0).getPhysicalNumberOfCells();
		Map<String,Integer> head = new HashMap<String,Integer>();
		/*for(int i=0;i<columncount;i++){
			head.put(Sheet1.getRow(0).getCell(i).getStringCellValue(),i);
		}*/
		//System.out.println("output"+outputValues.size());
		outerLoop:
		for (int j=1;j<=RowCount;j++){
			String S1= Sheet1.getRow(j).getCell(0).getStringCellValue();
			if(Sheet1.getRow(j).getCell(0).getStringCellValue().equals(test)){
			for(int i=1;i<=columncount;i++){
				String S2= Sheet1.getRow(0).getCell(i).getStringCellValue();
				//String S1= Sheet1.getRow(j).getCell(0).getStringCellValue();
				//if(Sheet1.getRow(j).getCell(0).getStringCellValue().equals(test)){
					//for(int a=0;a<outputValues.size();a++){
						//if(head.containsKey(strKey)){
							//int col = head.get(outputValues.get(a));
				if(Sheet1.getRow(0).getCell(i).getStringCellValue().equals(strKey)){
							Sheet1.getRow(j).createCell(i).setCellValue(words2);
							break outerLoop;
					}
					}		
				}
			if(j==RowCount){
				WriteTotxtfile(sheetname,filtername,filtervalue,txtfilepath,words2);
			}
			}
		//}
		FileOutputStream fout = new FileOutputStream(src);	
		wb.write(fout);

	}
	catch (Exception e) {
		// TODO Auto-generated catch block
		logger.handleError("Failed while writing to excel", e);
	}
}
//maximize or Minimize the window
public boolean Windowmaxmin() {
	try{
		
		JavascriptExecutor executor = (JavascriptExecutor)webDr;
		executor.executeScript("document.body.style.zoom = '0.8'");
					return true;
			
		} catch (Exception e) {
			logger.handleError("", e);
		}
	return false;
}
//selecting request ID from the search results
public boolean selectreqID(String elementName, String reqID){

	try {
		String locator = getLocator(elementName);
		List<WebElement> tr_Collection = webDr.findElements(By.xpath(locator));
		for(int j=1;j<tr_Collection.size();j++)
		{
			
			WebElement requestID=(WebElement) webDr.findElement(By.xpath(locator+"["+(j+1)+"]/td[2]"));
			
			if(requestID.getText().trim().contains(reqID)) 
			{		
				JavascriptExecutor js = (JavascriptExecutor) webDr;
				js.executeScript("arguments[0].click();", requestID);
				wait(4000);
				return true;			
			}

		}
		return false;
	} catch (Exception e) {
		logger.handleError("Failed to Click cell object for ", elementName," ", e);
		return false;
	}
} 
public boolean searchstatus(String elementName, String reqID,String status){

	try {
		String locator = getLocator(elementName);
		List<WebElement> tr_Collection = webDr.findElements(By.xpath(locator));
		for(int j=1;j<tr_Collection.size();j++)
		{
			
			WebElement requestID=(WebElement) webDr.findElement(By.xpath(locator+"["+(j+1)+"]/td[2]"));
			WebElement reqstatus=(WebElement) webDr.findElement(By.xpath(locator+"["+(j+1)+"]/td[8]/span"));
			String reqids = requestID.getText();
			String reqsta = reqstatus.getText();
			if(requestID.getText().trim().contains(reqID) & reqstatus.getText().trim().contains(status)) 
			{		
				return true;			
			}

		}
		return false;
	} catch (Exception e) {
		logger.handleError("Failed to Click cell object for ", elementName," ", e);
		return false;
	}
} 
public boolean verifysigners(String elementName, LinkedList<String> reqID){

	try {
		String locator = getLocator(elementName);
		List<WebElement> tr_Collection = webDr.findElements(By.xpath(locator));
		int count=0;
		for(int j=5;j<=tr_Collection.size();j++)
		{
			
			WebElement requestID=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[2]"));
			for(int i=0;j<reqID.size();i++){	
			if(requestID.getText().trim().contains(reqID.get(i))) 
			{		
				count++;
				if(count==reqID.size()){
					return true;	
				}		
			}else if((i+1)==reqID.size()){
				return false;
			}
			}
		}
		return false;
	} catch (Exception e) {
		logger.handleError("Failed to Click cell object for ", elementName," ", e);
		return false;
	}
}


public boolean verifyingreqID(String elementName, String reqID,String Status){

	try {
		String locator = getLocator(elementName);
		List<WebElement> tr_Collection = webDr.findElements(By.xpath(locator));
		for(int j=2;j<=tr_Collection.size();j++)
		{
			WebElement requestID=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[2]"));
			WebElement request_status=(WebElement) webDr.findElement(By.xpath(locator+"["+j+"]/td[8]/span"));
			if(requestID.getText().trim().contains(reqID) & request_status.getText().trim().contains(Status)) 
			{		
				return true;			
			}

		}
		return false;
	} catch (Exception e) {
		logger.handleError("Failed to Click cell object for ", elementName," ", e);
		return false;
	}
}
public void Sync(String elementName) { 

	for (int i =0; i<=60; i++) { 

		try { 
			wait(2000); 
			if(getControl(elementName).isDisplayed()){ 
				System.out.println("element displayed");
				break; 
			} 
		} 

		catch (Exception e){ 
			logger.trace("Error caused while verifying the presence of element "  +  elementName ); 
		} 

	} 

}

public boolean checkStatusclick(String elementName,String status) 
{
	String notStarted = null;
	String lateststatus = status;
	try {

		int count = 1;
		WebElement tableElement = getWebElement(elementName);
		List<WebElement> tr_Collection = tableElement.findElements(By.xpath(".//tbody/tr[@data-row]/td[10]"));

		for (WebElement ele : tr_Collection) 
		{
			notStarted = ele.getAttribute("innerText");
			if(notStarted.contains(lateststatus))
			{
				tableElement.findElement(By.xpath(".//tbody/tr[@data-row]["+count+"]/td[1]/img")).click();
				return true;
			}
			else
			{
			count=count+2;
			}
		} 
		return false; 

	} catch (Exception e) { 
		logger.handleError("Failed to click after checking the status ", elementName," ", e); 
		return false; 
	} 

}

public void implicitWait(int mS) {

    try {

           webDr.manage().timeouts().implicitlyWait(mS, TimeUnit.MILLISECONDS);

    } catch (Exception e) {

           logger.handleError("Error in synchronization", e);

    }

} 

public boolean clickBasedOnName(String elementName, String name) 
{ 
	try { 
		String element = getLocator(elementName); 
		List<WebElement> tr_Collection = webDr.findElements(By.xpath(element)); 

		for (WebElement ele : tr_Collection) 
		{ 
			if(ele.getAttribute("innerText").toLowerCase().contains(name.toLowerCase())) 
			{ 
				ele.findElement(By.tagName("input")).click(); 
				passed("Click on element" + " " + elementName, " " + "Element" 
						+ " " + elementName + " " + "should be clicked", 
						"Element" + " " + elementName + " " 
								+ "Clicked successfully"); 
				return true; 
			} 
		} 
	} catch (Exception e) { 
		failed("Click on element", " " + elementName + " " + "Element" 
				+ " " + elementName + " " + "should be clicked", 
				"Failed to click on element" + " " + elementName); 

		logger.handleError("Failed to click on the element ", elementName," ", e); 
		return false; 
	} 
	return false; 
}

public boolean checkStatusselectCheckBox(String elementName,String status) 
{
	String notStarted = null;
	String lateststatus = status;
	try {

		int count = 1;
		WebElement tableElement = getWebElement(elementName);
		List<WebElement> tr_Collection = tableElement.findElements(By.xpath(".//tbody/tr[@data-row]/td[10]"));

		for (WebElement ele : tr_Collection) 
		{
			notStarted = ele.getAttribute("innerText");
			if(notStarted.contains(lateststatus))
			{
				tableElement.findElement(By.xpath(".//tbody/tr[@data-row]["+count+"]/td[2]/div")).click();
				return true;
			}
			else
			{
			count=count+2;
			}
		} 
		return false; 

	} catch (Exception e) { 
		logger.handleError("Failed to click after checking the status ", elementName," ", e); 
		return false; 
	} 

}

public void ApplicationSync()
{
	wait(5000);	
}

public String toString() {
		return StringUtils.mapString(this);
	}

	private static WebDriver webDr;
	private static ObjectMap objMap;
	private Browser browser;
	public TableHandler th;
	private LogUtils logger = new LogUtils(this);
	private BaseWebModuleDriver basewebmoddr;
	public boolean Verify(String elementName, String string) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	
}
