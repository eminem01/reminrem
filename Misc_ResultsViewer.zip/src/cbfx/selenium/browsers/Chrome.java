/******************************************************************************
$Id : Chrome.java 3/3/2016 7:07:42 PM
Copyright 2016-2017 IGATE GROUP OF COMPANIES. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF IGATE GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND IGATE GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
******************************************************************************/

package cbfx.selenium.browsers;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;

import cbf.utils.LogUtils;
import cbf.utils.StringUtils;

public class Chrome implements Browser {

	/**
	 * Constructor to initialise browser related parameters
	 * 
	 * @param parameters
	 * 
	 */

	public Chrome(Map parameters) {

		this.params = parameters;
	}

	/**
	 * Loads chrome driver
	 * 
	 * @return chrome driver instance
	 */

	public WebDriver openDriver() {
		System.setProperty("webdriver.chrome.driver",
				(String) params.get("browserdriver")+"chromedriver.exe");		
		try{
			chromeDriver = new ChromeDriver(chromeCapabilities());
		}catch(Exception e){
			logger.handleError("Failed to read browser details ", e);
		}
		return chromeDriver;
	}

	/**
	 * Quits chrome driver
	 * 
	 */
	public void closeDriver() {
		try {
			if (chromeDriver != null) {
				TimeUnit.SECONDS.sleep(1);
				chromeDriver.quit();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private ChromeOptions chromeOptions() {
		ChromeOptions options = new ChromeOptions();

		//To disable any extensions installed
		options.addArguments("chrome.switches","--disable-extensions");
		//To enable automation
		options.addArguments("--test-type");
		//To disable pop-up blocking features
		//options.addArguments("disable-popup-blocking");
		//To maximize browser
		options.addArguments("start-maximized");
		//To Disable any browser notifications
		options.addArguments("--disable-notifications");
		//To disable yellow strip info bar which prompts info messages
		options.addArguments("disable-infobars");
		
		return options;
	}
	
	private DesiredCapabilities chromeCapabilities() {
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		
		System.setProperty("webdriver.chrome.logfile", "chromedriver.log");

		capabilities.setCapability(CapabilityType.LOGGING_PREFS, loggingPreferences());
		capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions());
		//capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
		capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
		capabilities.setJavascriptEnabled(true);
		
		return capabilities;
	}
	
	private LoggingPreferences loggingPreferences() {
		LoggingPreferences logs = new LoggingPreferences();

		logs.enable(LogType.BROWSER, Level.ALL);
		logs.enable(LogType.CLIENT, Level.ALL);
		logs.enable(LogType.DRIVER, Level.ALL);
		logs.enable(LogType.PERFORMANCE, Level.ALL);
		logs.enable(LogType.PROFILER, Level.ALL);
		logs.enable(LogType.SERVER, Level.ALL);

		return logs;
	}

	/**
	 * Overriding toString() method to return Chrome format string
	 */
	public String toString() {
		return StringUtils.mapString(this);
	}

	private Map params;
	private WebDriver chromeDriver;
	private static LogUtils logger = new LogUtils();
}
